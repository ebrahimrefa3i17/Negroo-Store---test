const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    console.error("JWT_SECRET is not defined in environment variables! Auth middleware will not function.");
    process.exit(1);
}

const auth = (req, res, next) => {
    const authHeader = req.header('Authorization');
    const xAuthToken = req.header('x-auth-token');
    const cookieToken = req.cookies.token; // ✅ NEW: Get token from cookie

    let token;

    if (authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.split(' ')[1];
        console.log('Auth Middleware: Token found in Authorization header.');
    } else if (xAuthToken) {
        token = xAuthToken;
        console.log('Auth Middleware: Token found in x-auth-token header.');
    } else if (cookieToken) { // ✅ NEW: Check for token in cookie
        token = cookieToken;
        console.log('Auth Middleware: Token found in HTTP-only cookie.');
    }

    if (!token) {
        console.log('Auth Middleware: No token found. URL:', req.originalUrl);
        return res.status(401).json({ message: 'No token, authorization denied.' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = {
            id: decoded.id,
            email: decoded.email,
            isAdmin: decoded.isAdmin,
            name: decoded.name
        };
        console.log('Auth Middleware: Token verified for user:', req.user.email, 'isAdmin:', req.user.isAdmin, 'name:', req.user.name, 'URL:', req.originalUrl);
        next();
    } catch (err) {
        console.error('Auth Middleware: Token verification failed for URL:', req.originalUrl, 'Error:', err);
        if (err.name === 'TokenExpiredError') {
            // ✅ NEW: Clear expired cookie on server side
            res.clearCookie('token'); 
            return res.status(401).json({ message: 'Token has expired. Please log in again.' });
        } else if (err.name === 'JsonWebTokenError') {
            // ✅ NEW: Clear invalid cookie on server side
            res.clearCookie('token');
            return res.status(401).json({ message: 'Invalid token. Please log in again.' });
        }
        return res.status(401).json({ message: 'Authentication failed. Please log in again.' });
    }
};

const adminAuth = (req, res, next) => {
    console.log('AdminAuth Middleware: Initiated for URL:', req.originalUrl);
    auth(req, res, (err) => {
        if (err) {
            console.log('AdminAuth Middleware: Authentication failed by auth middleware for URL:', req.originalUrl);
            return;
        }

        console.log('AdminAuth Middleware: User after authentication:', req.user.email, 'isAdmin:', req.user.isAdmin, 'name:', req.user.name, 'for URL:', req.originalUrl);

        if (req.user && req.user.isAdmin === true) {
            console.log('AdminAuth Middleware: User is admin. Proceeding for URL:', req.originalUrl);
            next();
        } else {
            console.log('AdminAuth Middleware: User is NOT admin or req.user missing. Denying access for URL:', req.originalUrl);
            res.status(403).json({ message: 'Access denied. Administrator privileges required.' });
        }
    });
};

module.exports = { auth, adminAuth };