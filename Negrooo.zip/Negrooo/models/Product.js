const mongoose = require('mongoose');

// Define the schema for the Product
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true,
        min: 0 // Price cannot be negative
    },
    imageUrl: {
        type: String,
        required: true
    },
    imageUrls: {
        type: [String],
        default: []
    },
    category: {
        type: String,
        required: true,
        trim: true
    },
    stock: {
        type: Number,
        required: true,
        min: 0,
        default: 0
    },
    // ✅ NEW: Minimum stock threshold for alerts
    minStockThreshold: {
        type: Number,
        default: 10, // Default to 10 units for low stock alert
        min: 0
    },
    // ✅ NEW: Timestamp of the last low stock notification sent for this product
    lastLowStockNotification: {
        type: Date,
        default: null
    },
    specifications: {
        type: String,
        trim: true,
        default: 'No specifications available.'
    },
    shippingAndReturns: {
        type: String,
        trim: true,
        default: 'Standard shipping within 3-5 business days. Easy returns within 30 days of purchase.'
    },
    // ✅ NEW: Product Variants Schema
    variants: [
        {
            name: { // e.g., "Color", "Size"
                type: String,
                required: true,
                trim: true
            },
            options: [
                {
                    value: { // e.g., "Red", "Blue", "S", "M"
                        type: String,
                        required: true,
                        trim: true
                    },
                    priceAdjustment: { // Optional: how much to add/subtract from base price
                        type: Number,
                        default: 0
                    },
                    stock: { // Stock for this specific variant option
                        type: Number,
                        required: true,
                        min: 0,
                        default: 0
                    },
                    imageUrl: { // Optional: image for this specific variant option
                        type: String,
                        default: ''
                    }
                }
            ]
        }
    ],
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Create the Product model from the schema
const Product = mongoose.model('Product', productSchema);

module.exports = Product;