const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
    productId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true
    },
    name: { // Store product name at time of order
        type: String,
        required: true
    },
    price: { // Store product price at time of order
        type: Number,
        required: true
    },
    imageUrl: { // Store image URL at time of order
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true,
        min: 1
    },
    // ✅ NEW: Fields to store variant information directly in the order item
    selectedVariants: [ // Array of selected variants for this item
        {
            name: { type: String, trim: true, required: true },
            value: { type: String, trim: true, required: true }
        }
    ],
    variantImageUrl: { // The specific image URL for the selected variant combination
        type: String,
        default: ''
    },
    variantPriceAdjustment: { // The price adjustment for the selected variant combination
        type: Number,
        default: 0
    }
}, { _id: false });

const orderSchema = new mongoose.Schema({
    userId: { // This field links the order to a user (now optional for guests)
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: false // Changed from true to false for guest orders
    },
    items: [orderItemSchema], // Array of items in this order
    totalAmount: {
        type: Number,
        required: true,
        min: 0
    },
    shippingAddress: { // Shipping details for Cash on Delivery
        fullName: { type: String, required: true },
        email: { type: String, required: true },
        phone: { type: String, required: true },
        addressLine1: { type: String, required: true },
        city: { type: String, required: true },
        country: { type: String, required: true }
    },
    status: {
        type: String,
        enum: ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'],
        default: 'Pending'
    },
    paymentMethod: {
        type: String,
        enum: ['Cash on Delivery', 'Paymob Card'],
        required: true
    },
    paymobOrderId: {
        type: String,
        unique: true,
        sparse: true
    },
    paymentDetails: {
        transactionId: { type: String },
        status: { type: String }, // 'succeeded', 'failed', 'pending'
        message: { type: String }
    },
    couponUsed: { // ✅ NEW: Store coupon details if used
        code: { type: String, trim: true },
        discountType: { type: String, enum: ['percentage', 'fixed_amount'] },
        discountValue: { type: Number, min: 0 }
        // We only store essential details, not full coupon document
    },
    isEmailSent: { // ✅ NEW: To track if order confirmation email was sent
        type: Boolean,
        default: false
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const Order = mongoose.model('Order', orderSchema);

module.exports = Order;