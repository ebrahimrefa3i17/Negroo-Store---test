const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const { auth } = require('../middleware/authMiddleware'); // Import auth middleware

// Helper function to compare two arrays of selected variants
function areVariantsEqual(variants1, variants2) {
    if (!variants1 && !variants2) return true; // Both are null/undefined (no variants selected)
    if (!variants1 || !variants2 || variants1.length !== variants2.length) return false;

    // Sort variants to ensure consistent comparison order regardless of the order sent from client
    const sorter = (a, b) => {
        // ✅ MODIFIED: Use 'name' and 'value' for sorting as per Cart.js schema
        if (a.name < b.name) return -1;
        if (a.name > b.name) return 1;
        if (a.value < b.value) return -1;
        if (a.value > b.value) return 1;
        return 0;
    };
    const sortedV1 = [...variants1].sort(sorter);
    const sortedV2 = [...variants2].sort(sorter);

    for (let i = 0; i < sortedV1.length; i++) {
        // ✅ MODIFIED: Use 'name' and 'value' for comparison
        if (sortedV1[i].name !== sortedV2[i].name || sortedV1[i].value !== sortedV2[i].value) {
            return false;
        }
    }
    return true;
}


// Middleware to handle cart population (common for GET requests)
const populateCartItems = (query) => {
    // Populate with specific product fields, including variants, for frontend display and logic
    return query.populate('items.productId', 'name price imageUrl stock variants');
};

// 1. GET user's cart (http://localhost:3000/api/cart) - Requires authentication
router.get('/', auth, async (req, res) => { // Apply auth middleware here
    try {
        const cart = await populateCartItems(Cart.findOne({ userId: req.user.id }));
        if (!cart) {
            // If no cart exists for the user, return an empty cart linked to the user
            return res.json({ userId: req.user.id, items: [] });
        }
        res.json(cart);
    } catch (err) {
        console.error('Error fetching cart for user:', err); // Log the full error for developers
        res.status(500).json({ message: 'Failed to retrieve cart due to a server error.' });
    }
});

// 2. POST add item to cart (http://localhost:3000/api/cart/add) - Requires authentication
router.post('/add', auth, async (req, res) => { // Apply auth middleware here
    // clientSelectedVariants is now an array: [{ name: "Color", value: "Red" }, ...]
    const { productId, quantity, selectedVariants: clientSelectedVariants } = req.body;
    const userId = req.user.id; // Get userId from authenticated request

    if (!productId || quantity === undefined || quantity <= 0) {
        console.error("Validation failed for cart ADD. Received:", { productId, quantity, userId });
        return res.status(400).json({ message: 'Product ID and a positive quantity are required.' });
    }

    try {
        let cart = await Cart.findOne({ userId }); // Find user's cart
        const product = await Product.findById(productId);

        if (!product) {
            return res.status(404).json({ message: 'Product not found.' });
        }

        const parsedQuantity = parseInt(quantity);
        if (isNaN(parsedQuantity) || parsedQuantity <= 0) {
            return res.status(400).json({ message: 'Quantity must be a positive number.' });
        }

        let totalAvailableStock = product.stock; // Default to main product stock
        let finalImageUrl = product.imageUrl; // Default to main product image
        let finalPrice = product.price; // Default to main product price

        // NEW: Find the specific variant combination and get its stock/details
        // clientSelectedVariants is an array like [{name: "Color", value: "Red"}, ...]
        if (product.variants && product.variants.length > 0) {
            if (!Array.isArray(clientSelectedVariants) || clientSelectedVariants.length === 0) {
                return res.status(400).json({ message: 'Product has variants. Please select all required variants.' });
            }

            totalAvailableStock = Infinity; // Start high, then find minimum stock across all selected options
            let currentCombinationPriceAdjustment = 0;
            let currentCombinationImageUrl = product.imageUrl; // Start with product's main image

            for (const clientVar of clientSelectedVariants) {
                // ✅ MODIFIED: Use clientVar.name to match product's variant group name
                let foundGroup = product.variants.find(vg => vg.name === clientVar.name);
                if (!foundGroup) {
                    return res.status(400).json({ message: `Variant group '${clientVar.name}' not found for product.` });
                }
                // ✅ MODIFIED: Use clientVar.value to match product's variant option value
                let foundOption = foundGroup.options.find(opt => opt.value === clientVar.value);
                if (!foundOption) {
                    return res.status(400).json({ message: `Variant option '${clientVar.value}' not found for group '${clientVar.name}'.` });
                }

                // Update combination properties based on selected option
                totalAvailableStock = Math.min(totalAvailableStock, foundOption.stock);
                currentCombinationPriceAdjustment += foundOption.priceAdjustment;
                if (foundOption.imageUrl) {
                    currentCombinationImageUrl = foundOption.imageUrl; // Prioritize variant specific image
                }
            }

            // Assign final calculated variant details
            finalImageUrl = currentCombinationImageUrl;
            finalPrice = product.price + currentCombinationPriceAdjustment; // Final price is base + adjustment

        } else if (clientSelectedVariants && clientSelectedVariants.length > 0) {
            // Product does not have variants defined, but client sent selected variants
            return res.status(400).json({ message: 'Product does not support variants. Please remove variant selections.' });
        }


        if (totalAvailableStock < parsedQuantity) {
            const variantStr = clientSelectedVariants && clientSelectedVariants.length > 0
                ? clientSelectedVariants.map(v => `${v.name}: ${v.value}`).join(', ') // ✅ MODIFIED: use v.name, v.value
                : 'main product';
            return res.status(400).json({ message: `Not enough stock for ${product.name} (${variantStr}). Available: ${totalAvailableStock}, Requested: ${parsedQuantity}.` });
        }

        if (!cart) {
            // If no cart exists for the user, create a new one
            cart = new Cart({ userId, items: [] });
        }

        let itemIndex = -1;
        // MODIFIED: Check if product with the EXACT SAME set of variants already exists in cart
        itemIndex = cart.items.findIndex(item =>
            item.productId.toString() === productId &&
            areVariantsEqual(item.selectedVariants, clientSelectedVariants)
        );

        if (itemIndex > -1) {
            // Update quantity if product (with same variants) exists
            const newTotalQuantity = cart.items[itemIndex].quantity + parsedQuantity;
            if (totalAvailableStock < newTotalQuantity) {
                const variantStr = clientSelectedVariants && clientSelectedVariants.length > 0
                    ? clientSelectedVariants.map(v => `${v.name}: ${v.value}`).join(', ') // ✅ MODIFIED: use v.name, v.value
                    : 'main product';
                return res.status(400).json({ message: `Adding ${parsedQuantity} units of ${product.name} (${variantStr}) would exceed available stock. Max allowed: ${totalAvailableStock - cart.items[itemIndex].quantity}.` });
            }
            cart.items[itemIndex].quantity = newTotalQuantity;
            // ✅ FIX: Ensure all required denormalized fields are updated/set
            cart.items[itemIndex].name = product.name;
            cart.items[itemIndex].price = finalPrice; // ✅ MODIFIED: Use finalPrice
            cart.items[itemIndex].imageUrl = finalImageUrl; // ✅ MODIFIED: Use finalImageUrl (which is the variant-specific image)
            cart.items[itemIndex].selectedVariants = clientSelectedVariants; // ensure selected variants are correct

        } else {
            // Add new item to cart, storing denormalized data
            cart.items.push({
                productId,
                name: product.name,
                price: finalPrice, // ✅ MODIFIED: Use finalPrice
                imageUrl: finalImageUrl, // ✅ MODIFIED: Use finalImageUrl
                quantity: parsedQuantity,
                selectedVariants: clientSelectedVariants, // Store array of selected variants
            });
        }

        await cart.save();
        // Re-fetch with population to return detailed cart
        const updatedCart = await populateCartItems(Cart.findOne({ userId }));
        res.status(200).json({ message: 'Item added to cart successfully!', cart: updatedCart });

    } catch (err) {
        console.error('Error adding to cart (backend):', err); // More specific logging
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid product ID format.' });
        }
        res.status(500).json({ message: err.message || 'Failed to add item to cart due to a server error.' });
    }
});

// 3. PUT update item quantity in cart (http://localhost:3000/api/cart/update) - Requires authentication
router.put('/update', auth, async (req, res) => {
    console.log('Received PUT /api/cart/update request.');
    const { productId, quantity, selectedVariants: clientSelectedVariants } = req.body; // ✅ MODIFIED: selectedVariants is now an array
    const userId = req.user.id;

    if (!productId || quantity === undefined || quantity < 0) {
        console.error("Validation failed for cart UPDATE. Received:", { productId, quantity, userId });
        return res.status(400).json({ message: 'Product ID and a non-negative quantity are required.' });
    }

    try {
        const cart = await Cart.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ message: 'Cart not found for this user.' });
        }

        let itemIndex = -1;
        // ✅ MODIFIED: Find item by productId AND selectedVariants array
        itemIndex = cart.items.findIndex(item =>
            item.productId.toString() === productId &&
            areVariantsEqual(item.selectedVariants, clientSelectedVariants)
        );

        if (itemIndex === -1) {
            return res.status(404).json({ message: 'Product (or specific variant) not found in cart.' });
        }

        const parsedQuantity = parseInt(quantity);
        if (isNaN(parsedQuantity) || parsedQuantity < 0) {
            return res.status(400).json({ message: 'Quantity must be a non-negative number.' });
        }

        const product = await Product.findById(productId);
        if (!product) {
            // Remove item from cart if product no longer exists in database
            cart.items.splice(itemIndex, 1);
            await cart.save();
            const updatedCart = await populateCartItems(Cart.findOne({ userId }));
            return res.status(404).json({ message: 'Product not found in database and removed from your cart.', cart: updatedCart });
        }

        let totalAvailableStock = product.stock; // Default to main product stock
        let variantImageUrl = product.imageUrl;
        let variantPriceAdjustment = 0;
        let finalPrice = product.price;


        // ✅ NEW: Get stock for the specific variant combination AND update denormalized fields
        if (product.variants && product.variants.length > 0) {
            if (!Array.isArray(clientSelectedVariants) || clientSelectedVariants.length === 0) {
                return res.status(400).json({ message: 'Product has variants. Selected variants are missing for update.' });
            }

            totalAvailableStock = Infinity; // Find minimum stock across all selected options
            let currentCombinationPriceAdjustment = 0;
            let currentCombinationImageUrl = product.imageUrl;

            for (const clientVar of clientSelectedVariants) {
                // ✅ MODIFIED: Use clientVar.name and clientVar.value
                let foundGroup = product.variants.find(vg => vg.name === clientVar.name);
                if (!foundGroup) {
                    return res.status(400).json({ message: `Variant group '${clientVar.name}' not found for product.` });
                }
                let foundOption = foundGroup.options.find(opt => opt.value === clientVar.value);
                if (!foundOption) {
                    return res.status(400).json({ message: `Variant option '${clientVar.value}' not found for group '${clientVar.name}'.` });
                }
                totalAvailableStock = Math.min(totalAvailableStock, foundOption.stock);
                currentCombinationPriceAdjustment += foundOption.priceAdjustment;
                if (foundOption.imageUrl) {
                    currentCombinationImageUrl = foundOption.imageUrl;
                }
            }
            variantImageUrl = currentCombinationImageUrl;
            variantPriceAdjustment = currentCombinationPriceAdjustment;
            finalPrice = product.price + variantPriceAdjustment;

        }

        if (parsedQuantity > totalAvailableStock) {
            const variantStr = clientSelectedVariants && clientSelectedVariants.length > 0
                ? clientSelectedVariants.map(v => `${v.name}: ${v.value}`).join(', ') // ✅ MODIFIED: use v.name, v.value
                : 'main product';
            return res.status(400).json({ message: `Not enough stock for ${product.name} (${variantStr}). Available: ${totalAvailableStock}, Requested: ${parsedQuantity}.` });
        }

        if (parsedQuantity === 0) { // If quantity is zero, remove the item
            cart.items.splice(itemIndex, 1);
        } else {
            cart.items[itemIndex].quantity = parsedQuantity;
        }
        // ✅ FIX: Ensure all required denormalized fields are updated/set for existing item
        cart.items[itemIndex].name = product.name;
        cart.items[itemIndex].price = finalPrice; // ✅ MODIFIED: Use finalPrice
        cart.items[itemIndex].imageUrl = variantImageUrl; // ✅ FIX: Use variantImageUrl for the main imageUrl field
        cart.items[itemIndex].variantImageUrl = variantImageUrl; // This field also needs to be updated.
        cart.items[itemIndex].variantPriceAdjustment = variantPriceAdjustment; // ✅ MODIFIED: Use variantPriceAdjustment
        cart.items[itemIndex].selectedVariants = clientSelectedVariants; // ensure selected variants are correct


        await cart.save();
        const updatedCart = await populateCartItems(Cart.findOne({ userId }));
        res.json({ message: 'Cart updated successfully!', cart: updatedCart });

    } catch (err) {
        console.error('Error updating cart item:', err);
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid product ID format or cart ID.' });
        } else if (err.name === 'ValidationError') {
            return res.status(400).json({ message: `Validation error: ${err.message}` });
        }
        res.status(500).json({ message: err.message || 'Failed to update cart due to a server error.' });
    }
});

// 4. DELETE remove item from cart (http://localhost:3000/api/cart/remove/:productId) - Requires authentication
// MODIFIED: Now expects selectedVariants in body for precise removal
router.delete('/remove/:productId', auth, async (req, res) => {
    const { productId } = req.params;
    const { selectedVariants: clientSelectedVariants } = req.body; // selectedVariants is now an array
    const userId = req.user.id;

    try {
        const cart = await Cart.findOne({ userId });
        if (!cart) {
            return res.status(404).json({ message: 'Cart not found for this user.' });
        }

        let initialLength = cart.items.length;
        // MODIFIED: Filter items by productId AND selectedVariants array for uniqueness
        cart.items = cart.items.filter(item =>
            !(item.productId.toString() === productId &&
              areVariantsEqual(item.selectedVariants, clientSelectedVariants))
        );

        if (cart.items.length === initialLength) {
            return res.status(404).json({ message: 'Product (or specific variant combination) not found in cart to remove.' });
        }

        await cart.save();
        const updatedCart = await populateCartItems(Cart.findOne({ userId }));
        res.json({ message: 'Item removed from cart successfully!', cart: updatedCart });

    } catch (err) {
        console.error('Error removing item from cart:', err);
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid product ID format for removal.' });
        }
        res.status(500).json({ message: err.message || 'Failed to remove item from cart due to a server error.' });
    }
});

// 5. DELETE clear user's cart (http://localhost:3000/api/cart/clear) - Requires authentication
router.delete('/clear', auth, async (req, res) => {
    const userId = req.user.id;

    try {
        const cart = await Cart.findOne({ userId });
        if (!cart) {
            // إذا لم تكن هناك سلة، فإنها تعتبر فارغة بالفعل
            return res.status(200).json({ message: 'Cart is already empty or not found for this user.', cart: { userId, items: [] } });
        }

        cart.items = []; // Clear all items
        await cart.save();
        res.json({ message: 'Cart cleared successfully!', cart });

    } catch (err) {
        console.error('Error clearing cart:', err);
        res.status(500).json({ message: 'Failed to clear cart due to a server error.' });
    }
});

module.exports = router;