const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs'); // لاستخدامها عند تغيير كلمة المرور
const { auth } = require('../middleware/authMiddleware'); // لحماية هذه المسارات

// --- User Profile API Endpoints ---

// 1. GET user profile (http://localhost:3000/api/users/profile) - Protected
router.get('/profile', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select('-password -__v'); // لا ترجع كلمة المرور
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }
        res.json(user);
    } catch (err) {
        console.error('Error fetching user profile:', err);
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid user ID format.' });
        }
        res.status(500).json({ message: 'Failed to retrieve profile data due to a server error.' });
    }
});

// 2. PUT update user name (http://localhost:3000/api/users/profile) - Protected
router.put('/profile', auth, async (req, res) => {
    const { name } = req.body;
    try {
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }
        if (name) {
            user.name = name;
        } else {
            // يمكن إضافة تحقق هنا إذا كان الاسم مطلوبًا
            return res.status(400).json({ message: 'Name cannot be empty.' });
        }
        await user.save();
        res.json({ message: 'Profile updated successfully!', user: { id: user._id, name: user.name, email: user.email, isAdmin: user.isAdmin } });
    } catch (err) {
        console.error('Error updating user profile:', err);
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'ValidationError') {
            return res.status(400).json({ message: err.message }); // يعرض رسالة خطأ التحقق من Mongoose
        }
        res.status(500).json({ message: 'Failed to update profile due to a server error.' });
    }
});

// 3. PUT update user shipping address (http://localhost:3000/api/users/address) - Protected
router.put('/address', auth, async (req, res) => {
    const { shippingAddress } = req.body; // shippingAddress هو كائن كامل
    try {
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }
        
        // التحقق من أن كائن shippingAddress موجود
        if (!shippingAddress || typeof shippingAddress !== 'object') {
            return res.status(400).json({ message: 'Shipping address data is required.' });
        }

        // يمكنك إضافة تحقق إضافي هنا لحقول shippingAddress الفردية إذا كانت مطلوبة
        // for (const key of ['fullName', 'phone', 'addressLine1', 'city', 'country']) {
        //     if (!shippingAddress[key]) {
        //         return res.status(400).json({ message: `${key} in shipping address is required.` });
        //     }
        // }
        
        user.shippingAddress = shippingAddress; 
        
        await user.save();
        res.json({ message: 'Shipping address updated successfully!', user: { id: user._id, name: user.name, email: user.email, isAdmin: user.isAdmin, shippingAddress: user.shippingAddress } });
    } catch (err) {
        console.error('Error updating shipping address:', err);
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'ValidationError') {
            return res.status(400).json({ message: err.message });
        }
        res.status(500).json({ message: 'Failed to update shipping address due to a server error.' });
    }
});


// 4. PUT change user password (http://localhost:3000/api/users/change-password) - Protected
router.put('/change-password', auth, async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    try {
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ message: 'Current password and new password are required.' });
        }
        if (newPassword.length < 6) { // يجب أن يتطابق مع minlength في الموديل
            return res.status(400).json({ message: 'New password must be at least 6 characters long.' });
        }

        const isMatch = await user.comparePassword(currentPassword);
        if (!isMatch) {
            return res.status(400).json({ message: 'Incorrect current password.' });
        }

        user.password = newPassword; // سيتم hashing كلمة المرور الجديدة بواسطة middleware 'pre-save' في User model
        await user.save();

        res.json({ message: 'Password changed successfully!' });
    } catch (err) {
        console.error('Error changing password:', err);
        // ✅ رسائل خطأ أكثر تحديدا
        if (err.name === 'ValidationError') {
            return res.status(400).json({ message: err.message });
        }
        res.status(500).json({ message: 'Failed to change password due to a server error.' });
    }
});

module.exports = router;