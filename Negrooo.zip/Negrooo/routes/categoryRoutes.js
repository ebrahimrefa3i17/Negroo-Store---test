const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
// لا نحتاج لاستيراد adminAuth أو multer هنا بعد الآن، لأن مسارات الإدارة تم نقلها

// --- API Endpoints for Categories (Publicly accessible GET routes) ---

// 1. GET all categories (http://localhost:3000/api/categories)
// هذا المسار متاح للجميع (الواجهة الأمامية للمتجر)
router.get('/', async (req, res) => {
    try {
        const categories = await Category.find().sort({ name: 1 }); // فرز أبجدي
        res.json(categories);
    } catch (err) {
        console.error('Error fetching categories:', err);
        res.status(500).json({ message: 'Server error fetching categories.' });
    }
});

// 2. GET a single category by ID (http://localhost:3000/api/categories/:id)
// متاح للجميع
router.get('/:id', async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) {
            return res.status(404).json({ message: 'Category not found.' });
        }
        res.json(category);
    } catch (err) {
        console.error('Error fetching single category by ID:', err);
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid Category ID format.' });
        }
        res.status(500).json({ message: 'Server error fetching category.' });
    }
});

module.exports = router;