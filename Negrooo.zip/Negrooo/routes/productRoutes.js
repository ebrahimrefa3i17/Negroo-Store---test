const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const Order = require('../models/Order'); // ✅ NEW: Import Order model to query for bestsellers
const { auth } = require('../middleware/authMiddleware'); // For any authenticated access if needed, but main product route is public

// Get all products with search, filter, and sort capabilities
// (http://localhost:3000/api/products?search=keyword&category=categoryName&minPrice=100&maxPrice=500&sortBy=price&sortOrder=desc&limit=10&page=1&stockStatus=low&exclude=productId&variants=[{"name":"Color","value":"Red"}])
router.get('/', async (req, res) => {
    try {
        const {
            search,
            category,
            minPrice,
            maxPrice,
            sortBy,
            sortOrder,
            limit,
            page,
            stockStatus, // 'low' for low stock products
            exclude, // Product ID to exclude from results (e.g., for related products)
            variants, // NEW: Array of selected variants like [{"name":"Color","value":"Red"},{"name":"Size","value":"M"}]
            bestsellers // ✅ NEW: Flag to fetch bestsellers
        } = req.query;

        const query = {};
        let products = [];
        let totalProducts = 0;
        let currentPage = parseInt(page) || 1;
        let totalPages = 0;
        const limitNum = parseInt(limit) || 10;
        const skip = (currentPage - 1) * limitNum;


        // ✅ NEW: Handle bestsellers query
        if (bestsellers === 'true') {
            // Aggregate to find products with most sales
            // This is a more complex query using aggregation pipeline
            const bestsellerAggregation = await Order.aggregate([
                // Stage 1: Unwind the items array to deconstruct the order items
                { $unwind: '$items' },
                // Stage 2: Group by product ID and sum quantities to get total sales for each product
                {
                    $group: {
                        _id: '$items.productId',
                        totalSold: { $sum: '$items.quantity' }
                    }
                },
                // Stage 3: Sort by totalSold in descending order
                { $sort: { totalSold: -1 } },
                // Stage 4: Limit the number of bestsellers (e.g., top 10 or by requested limit)
                { $limit: limitNum },
                // Stage 5: Lookup product details from the Product collection
                {
                    $lookup: {
                        from: 'products', // The collection name for Product model
                        localField: '_id',
                        foreignField: '_id',
                        as: 'productDetails'
                    }
                },
                // Stage 6: Unwind the productDetails array (since $lookup returns an array)
                { $unwind: '$productDetails' },
                // Stage 7: Project to reshape the output to look like a product document
                {
                    $project: {
                        _id: '$productDetails._id',
                        name: '$productDetails.name',
                        description: '$productDetails.description',
                        price: '$productDetails.price',
                        imageUrl: '$productDetails.imageUrl',
                        category: '$productDetails.category',
                        stock: '$productDetails.stock',
                        variants: '$productDetails.variants',
                        totalSold: '$totalSold' // Optionally include totalSold
                    }
                }
            ]);

            products = bestsellerAggregation;
            totalProducts = products.length; // Count bestsellers found
            totalPages = Math.ceil(totalProducts / limitNum) || 1; // At least 1 page
            // Pagination logic for bestsellers is handled by the $limit stage of aggregation directly
            // No skip needed here as we want the top N
            
            return res.json({
                products,
                totalProducts,
                currentPage,
                totalPages
            });
        }


        // Normal product fetching logic (if not bestsellers)
        // Search functionality
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } }, // Case-insensitive search by name
                { description: { $regex: search, $options: 'i' } }, // Case-insensitive search by description
                { category: { $regex: search, $options: 'i' } } // Case-insensitive search by category
            ];
        }

        // Category filter
        if (category && category !== 'All') {
            query.category = category;
        }

        // Price range filter
        if (minPrice || maxPrice) {
            query.price = {};
            if (minPrice) {
                query.price.$gte = parseFloat(minPrice);
            }
            if (maxPrice) {
                query.price.$lte = parseFloat(maxPrice);
            }
        }

        // Stock Status filter (for admin or specific use cases)
        if (stockStatus === 'low') {
            if (req.user && req.user.isAdmin) { // Only allow admin to see low stock status
                 query.$expr = { $lte: ["$stock", "$minStockThreshold"] };
            } else {
                // Ignore low stock filter for regular users or default to show all if no other filters
                delete query.stockStatus;
            }
        }

        // Exclude specific product (used for related products, for example)
        if (exclude) {
            query._id = { $ne: exclude };
        }

        // NEW: Variant filtering
        if (variants) {
            let parsedVariants;
            try {
                parsedVariants = JSON.parse(variants); // variants parameter comes as a JSON string from frontend
            } catch (e) {
                console.error("Error parsing variants query parameter:", e);
                return res.status(400).json({ message: "Invalid variants parameter format." });
            }

            if (Array.isArray(parsedVariants) && parsedVariants.length > 0) {
                // To filter by variants, we need to ensure the product has ALL selected variant groups and options
                query.$and = query.$and || []; // Ensure $and exists for combining conditions

                parsedVariants.forEach(variantSelection => {
                    // Each variantSelection is like { name: "Color", value: "Red" }
                    // We need to match products that have a variant group with 'name' and within that group, an option with 'value'
                    query.$and.push({
                        "variants": {
                            "$elemMatch": {
                                "name": variantSelection.name,
                                "options": {
                                    "$elemMatch": {
                                        "value": variantSelection.value
                                    }
                                }
                            }
                        }
                    });
                });
            }
        }

        // Sorting
        const sortOptions = {};
        if (sortBy) {
            sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;
        } else {
            sortOptions.createdAt = -1; // Default sort by newest
        }

        products = await Product.find(query)
            .sort(sortOptions)
            .skip(skip)
            .limit(limitNum);

        totalProducts = await Product.countDocuments(query);
        totalPages = Math.ceil(totalProducts / limitNum);

        res.json({
            products,
            totalProducts,
            currentPage,
            totalPages
        });

    } catch (err) {
        console.error('Error fetching products:', err);
        res.status(500).json({ message: 'Server error while fetching products.' });
    }
});

// Get product by ID
router.get('/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ message: 'Product not found.' });
        }
        res.json(product);
    } catch (err) {
        console.error('Error fetching product by ID:', err);
        res.status(500).json({ message: 'Server error while fetching product.' });
    }
});

// Export the router
module.exports = router;