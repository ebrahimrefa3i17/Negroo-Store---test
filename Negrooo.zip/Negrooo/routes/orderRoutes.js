const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const { auth, adminAuth } = require('../middleware/authMiddleware'); // Keep auth for other routes, but remove for guest checkout
const crypto = require('crypto');

console.log('orderRoutes.js: Module started loading.');

module.exports = ({ axios, PAYMOB_API_KEY, PAYMOB_HMAC_SECRET, PAYMOB_INTEGRATION_ID_CARD, PAYMOB_MERCHANT_ID, PAYMOB_IFRAME_ID }) => {

console.log('orderRoutes.js: Module function executed, router being configured.');

// --- Paymob Helper Functions ---
// 1. Authentication with Paymob API
async function paymobAuth() {
    // ✅ التعديل هنا: تخطي المصادقة إذا كان PAYMOB_API_KEY غير موجود
    if (!PAYMOB_API_KEY || PAYMOB_API_KEY.length < 5) { // يمكنك تغيير الشرط حسب طول المفتاح المتوقع (مثلاً 5 أحرف كحد أدنى)
        console.warn('Paymob Auth: PAYMOB_API_KEY is missing or too short. Returning a dummy token for development.');
        return 'dummy_auth_token_for_development'; // ارجع توكن وهمي للتطوير
    }

    try {
        const response = await axios.post('https://accept.paymobsolutions.com/api/auth/tokens', {
            api_key: PAYMOB_API_KEY
        });
        return response.data.token;
    } catch (error) {
        console.error('Paymob Auth Error:', error.response ? error.response.data : error.message);
        throw new Error('Failed to authenticate with Paymob. Please check API key.');
    }
}

// 2. Register Order with Paymob
async function paymobRegisterOrder(authToken, merchantOrderId, amountCents, currency, items) {
    try {
        const response = await axios.post('https://accept.paymobsolutions.com/api/ecommerce/orders', {
            auth_token: authToken,
            delivery_needed: 'false',
            merchant_order_id: merchantOrderId,
            amount_cents: amountCents,
            currency: currency,
            items: items.map(item => ({
                name: item.name,
                amount_cents: Math.round(item.price * 100),
                description: item.name,
                quantity: item.quantity
            }))
        });
        return response.data.id; // Paymob order ID
    } catch (error) {
        console.error('Paymob Register Order Error:', error.response ? error.response.data : error.message);
        throw new Error('Failed to register order with Paymob. Check order details or Paymob API status.');
    }
}

// 3. Get Payment Key (Final Step before Redirection/iFrame)
async function paymobGetPaymentKey(authToken, amountCents, currency, paymobOrderId, integrationId, billingData, userEmail, userName) {
    try {
        const response = await axios.post('https://accept.paymobsolutions.com/api/acceptance/payment_keys', {
            auth_token: authToken,
            amount_cents: amountCents,
            expiration: 3600, // 1 hour in seconds
            order_id: paymobOrderId,
            billing_data: {
                apartment: billingData.apartment || 'NA',
                email: userEmail,
                floor: billingData.floor || 'NA',
                first_name: userName.split(' ')[0] || 'NA',
                street: billingData.addressLine1 || 'NA',
                building: billingData.building || 'NA',
                phone_number: billingData.phone,
                shipping_method: 'NA',
                postal_code: billingData.postalCode || 'NA',
                city: billingData.city,
                country: billingData.country,
                last_name: userName.split(' ').slice(1).join(' ') || 'NA',
                state: billingData.state || 'NA'
            },
            currency: currency,
            integration_id: integrationId
        });
        return response.data.token; // Payment Key
    } catch (error) {
        console.error('Paymob Get Payment Key Error:', error.response ? error.response.data : error.message);
        throw new Error('Failed to obtain payment key from Paymob. Check integration ID or billing data.');
    }
}

// ✅ NEW: POST Initiate Paymob Payment (http://localhost:3000/api/orders/pay-with-paymob) - Now supports guests
router.post('/pay-with-paymob', async (req, res) => { // Removed 'auth' middleware
    console.log('orderRoutes.js: /pay-with-paymob route HIT!');
    // orderDetails contains shippingAddress, paymentMethod, and items with variant data from frontend
    const { orderDetails } = req.body;
    const userId = req.user ? req.user.id : null; // userId is now optional
    const userEmail = req.user ? req.user.email : orderDetails.shippingAddress.email;
    const userName = req.user ? (req.user.name || orderDetails.shippingAddress.fullName) : orderDetails.shippingAddress.fullName;

    try {
        let totalAmount = 0;
        const itemsForPaymob = [];
        const orderItemsForDB = []; // This will contain all fields needed for Order model
        let sourceItems = []; // This will hold items from cart (authenticated) or orderDetails.items (guest)

        if (userId) { // Authenticated user
            // For authenticated users, re-fetch from cart to ensure data integrity
            const cart = await Cart.findOne({ userId }).populate('items.productId');
            if (!cart || cart.items.length === 0) {
                return res.status(400).json({ message: 'Your cart is empty. Please add items before initiating payment.' });
            }
            sourceItems = cart.items;
        } else { // Guest user
            // For guest users, source items come directly from the request body (orderDetails.items)
            if (!orderDetails.items || orderDetails.items.length === 0) {
                return res.status(400).json({ message: 'No items provided for guest checkout.' });
            }
            // For guest, we need to fetch full product details for stock validation (only product ID is sent from guest frontend)
            for (const clientItem of orderDetails.items) {
                const product = await Product.findById(clientItem.productId);
                if (!product) {
                    return res.status(404).json({ message: `Product with ID ${clientItem.productId} not found.` });
                }
                // Validate stock (basic check)
                if (product.stock < clientItem.quantity) {
                    return res.status(400).json({ message: `Not enough stock for ${product.name}. Available: ${product.stock}, Requested: ${clientItem.quantity}.` });
                }
                // Reconstruct sourceItem to include populated product data (similar to authenticated cart)
                sourceItems.push({
                    productId: product, // Populated product object for consistent access
                    quantity: clientItem.quantity,
                    name: clientItem.name || product.name, // Use name from client if available, else product name
                    price: clientItem.price || product.price, // Use price from client (variant adjusted) if available, else base price
                    imageUrl: clientItem.imageUrl || product.imageUrl, // Use image from client (variant specific) if available, else base image
                    selectedVariants: clientItem.selectedVariants || [],
                    variantImageUrl: clientItem.variantImageUrl || '',
                    variantPriceAdjustment: clientItem.variantPriceAdjustment || 0
                });
            }
        }

        for (const item of sourceItems) {
            const product = item.productId; // This could be a populated product object or just an ID for guest re-fetch

            // Ensure product object is available
            if (!product || typeof product !== 'object') {
                // If it's not a populated object, try to find it (should already be done for guest)
                // This scenario should ideally not be hit if pre-fetching is robust
                const fetchedProduct = await Product.findById(item.productId);
                if (!fetchedProduct) {
                    return res.status(404).json({ message: `Product with ID ${item.productId} not found during order processing.` });
                }
                product = fetchedProduct;
            }

            // Perform stock validation again with final product data
            // If product has variants, check variant specific stock for accurate validation
            let itemStockToValidate = product.stock;
            if (product.variants && product.variants.length > 0 && item.selectedVariants && item.selectedVariants.length > 0) {
                let currentVariantStock = Infinity;
                for(const selVar of item.selectedVariants) {
                    const foundGroup = product.variants.find(vg => vg.name === selVar.name);
                    if(foundGroup) {
                        const foundOption = foundGroup.options.find(opt => opt.value === selVar.value);
                        if(foundOption) {
                            currentVariantStock = Math.min(currentVariantStock, foundOption.stock);
                        }
                    }
                }
                itemStockToValidate = currentVariantStock;
            }


            if (itemStockToValidate < item.quantity) {
                return res.status(400).json({ message: `Not enough stock for ${item.name}. Available: ${itemStockToValidate}, Requested: ${item.quantity}.` });
            }

            // Calculate total amount for Paymob
            totalAmount += item.price * item.quantity;
            itemsForPaymob.push({ name: item.name, amount_cents: Math.round(item.price * 100), description: item.name, quantity: item.quantity });


            // Prepare item for database, including variant-specific details
            orderItemsForDB.push({
                productId: product._id,
                name: item.name, // Use denormalized name from cart item
                price: item.price, // Use denormalized price from cart item (variant adjusted)
                imageUrl: item.imageUrl, // Use denormalized image from cart item (variant specific)
                quantity: item.quantity,
                selectedVariants: item.selectedVariants || [], // ✅ NEW: Save selectedVariants
                variantImageUrl: item.variantImageUrl || '', // ✅ NEW: Save variantImageUrl
                variantPriceAdjustment: item.variantPriceAdjustment || 0 // ✅ NEW: Save variantPriceAdjustment
            });
        }

        const amountInCents = Math.round(totalAmount * 100);
        const currency = 'EGP';

        // 1. Authenticate
        const authToken = await paymobAuth();

        // 2. Register Order
        const merchantOrderId = userId ? `${userId}-${Date.now()}` : `guest-${Date.now()}`;
        const paymobOrderId = await paymobRegisterOrder(authToken, merchantOrderId, amountInCents, currency, itemsForPaymob);

        // 3. Get Payment Key
        const paymentKey = await paymobGetPaymentKey(
            authToken,
            amountInCents,
            currency,
            paymobOrderId,
            PAYMOB_INTEGRATION_ID_CARD,
            orderDetails.shippingAddress,
            userEmail,
            userName
        );

        // Build Paymob iFrame URL
        const paymobIframeUrl = `https://accept.paymobsolutions.com/api/acceptance/iframes/${PAYMOB_IFRAME_ID}?payment_token=${paymentKey}`;

        // Save order in your database with 'Pending' status
        const newOrder = new Order({
            userId: userId,
            items: orderItemsForDB, // Use the enriched orderItemsForDB
            totalAmount,
            shippingAddress: orderDetails.shippingAddress,
            status: 'Pending',
            paymentMethod: 'Paymob Card',
            paymobOrderId: paymobOrderId
        });
        const savedOrder = await newOrder.save();

        res.json({
            message: 'Payment initiated successfully! Redirecting to secure payment page.',
            paymentType: 'iframe',
            redirectUrl: paymobIframeUrl,
            orderId: savedOrder._id
        });

    } catch (err) {
        console.error('Error initiating Paymob payment:', err);
        res.status(500).json({ message: err.message || 'Failed to initiate online payment due to a server error.' });
    }
});


// ✅ NEW: POST Paymob Webhook Callback (http://localhost:3000/api/orders/paymob-callback)
router.post('/paymob-callback', async (req, res) => {
    console.log('orderRoutes.js: /paymob-callback route HIT!');
    console.log('Paymob Callback received query:', req.query);
    console.log('Paymob Callback received body:', req.body);

    const hmac = req.query.hmac || req.body.hmac;
    const obj = req.query.obj || req.body.obj;

    if (!obj || !hmac) {
        console.error('Paymob Callback: Missing obj or hmac in request.');
        return res.status(400).send('Missing data for HMAC verification.');
    }

    const paymobOrderId = obj.order ? obj.order.id : null;
    const transactionId = obj.id;
    const paymobOrderStatus = obj.success;
    const merchantOrderId = obj.order ? obj.order.merchant_order_id : null; // This will be 'guest-timestamp' or 'userId-timestamp'

    if (!paymobOrderId || !merchantOrderId) {
        console.error('Paymob Callback: Missing order_id or merchant_order_id in obj.');
        return res.status(400).send('Missing order IDs in Paymob object.');
    }

    // Dynamic HMAC string construction based on the actual keys and their order
    // Ensure this matches Paymob's expected HMAC calculation
    const hmacSourceString = [
        obj.amount_cents,
        obj.created_at,
        obj.currency,
        obj.error_occured,
        obj.has_parent_transaction,
        obj.id,
        obj.integration_id,
        obj.is_3d_secure,
        obj.is_auth,
        obj.is_capture,
        obj.is_card_test,
        obj.is_flagged,
        obj.is_gateway,
        obj.is_null,
        obj.is_paid,
        obj.is_refunded,
        obj.is_standalone,
        obj.is_voided,
        obj.order.id,
        obj.owner,
        obj.pending,
        obj.source_data.pan,
        obj.source_data.sub_type,
        obj.source_data.type,
        obj.success
    ].map(value => String(value)).join(''); // Ensure all values are strings before joining


    const hashed = crypto.createHmac('sha512', PAYMOB_HMAC_SECRET)
                         .update(hmacSourceString)
                         .digest('hex');

    // Verify HMAC
    if (hashed !== hmac) {
        console.warn('Paymob Callback: HMAC verification failed! Received HMAC:', hmac, 'Calculated HMAC:', hashed);
        return res.status(401).send('HMAC verification failed.');
    }

    try {
        let order = await Order.findOne({ paymobOrderId: paymobOrderId });

        if (!order) {
            console.warn('Paymob Callback: Order not found by paymobOrderId, attempting fallback with merchantOrderId:', merchantOrderId);
            // Fallback logic for merchantOrderId needs to be careful if it includes 'guest-'
            const possibleUserId = merchantOrderId.startsWith('guest-') ? null : merchantOrderId.split('-')[0];

            if (possibleUserId) { // Attempt to find by userId if it's a registered user's merchantOrderId
                // Find pending order by userId that does NOT have a paymobOrderId yet
                order = await Order.findOne({ userId: possibleUserId, paymobOrderId: { $exists: false }, status: 'Pending' });
            }

            if (order) {
                order.paymobOrderId = paymobOrderId;
                console.log('Paymob Callback: Found and updated fallback order with PaymobOrderId.');
            } else {
                console.error('Paymob Callback: Could not find any matching order (original or fallback) for merchantOrderId:', merchantOrderId);
                return res.status(404).send('Order not found in our system for processing callback.');
            }
        }


        if (paymobOrderStatus) { // Payment Succeeded
            order.status = 'Processing';
            order.paymentDetails = {
                transactionId: transactionId,
                status: 'succeeded',
                message: obj.data ? obj.data.message : 'Payment successful via Paymob.'
            };
            console.log(`Paymob Callback: Payment succeeded for order ${order._id}`);

            // ✅ CRITICAL: Only clear cart if it's an authenticated user's order
            if (order.userId) { //
                const userCart = await Cart.findOne({ userId: order.userId });
                if (userCart) {
                    userCart.items = [];
                    await userCart.save();
                    console.log(`User cart cleared for order ${order._id}.`);
                }
            } else {
                console.log(`Guest order ${order._id} - no cart to clear.`);
            }

            // Reduce stock for products. For variant products, update specific variant stock.
            for (const item of order.items) {
                const product = await Product.findById(item.productId);
                if (product) {
                    if (item.selectedVariants && item.selectedVariants.length > 0) {
                        // Find and update stock for specific variant option
                        let foundVariantOption = null;
                        for (const variantGroup of product.variants) {
                            foundVariantOption = variantGroup.options.find(opt =>
                                item.selectedVariants.some(selVar => selVar.name === variantGroup.name && selVar.value === opt.value)
                            );
                            if (foundVariantOption) {
                                break;
                            }
                        }
                        if (foundVariantOption) {
                            foundVariantOption.stock -= item.quantity;
                            console.log(`Stock updated for variant ${item.name} (${item.selectedVariants.map(v => v.value).join(', ')}). New stock: ${foundVariantOption.stock}`);
                        } else {
                            // Fallback to main product stock if variant option not found (shouldn't happen with correct data)
                            product.stock -= item.quantity;
                            console.warn(`Variant option not found for ${item.name}. Decrementing main product stock. New stock: ${product.stock}`);
                        }
                    } else {
                        // For non-variant products, update main product stock
                        product.stock -= item.quantity;
                        console.log(`Stock updated for product ${item.name}. New stock: ${product.stock}`);
                    }
                    await product.save();
                }
            }

        } else { // Payment Failed
            order.status = 'Cancelled';
            order.paymentDetails = {
                transactionId: transactionId,
                status: 'failed',
                message: obj.data ? obj.data.message : 'Payment failed via Paymob.'
            };
            console.warn(`Paymob Callback: Payment failed for order ${order._id}. Message: ${order.paymentDetails.message}`);
            // Stock restoration logic remains the same
            // This is only triggered if status changes to Cancelled.
            // In this specific path, if paymobOrderStatus is false, we always set to Cancelled.
            // The stock is restored when status is changed to Cancelled, only if it wasn't already Cancelled.
            // Since this path *sets* it to Cancelled, stock won't be restored by this specific check here.
            // Stock is only restored via PUT /:id/status if an admin changes it TO Cancelled.
            // For failed payment, stock should be restored immediately.
            for (const item of order.items) {
                const product = await Product.findById(item.productId);
                if (product) {
                    if (item.selectedVariants && item.selectedVariants.length > 0) {
                        let foundVariantOption = null;
                        for (const variantGroup of product.variants) {
                            foundVariantOption = variantGroup.options.find(opt =>
                                item.selectedVariants.some(selVar => selVar.name === variantGroup.name && selVar.value === opt.value)
                            );
                            if (foundVariantOption) {
                                break;
                            }
                        }
                        if (foundVariantOption) {
                            foundVariantOption.stock += item.quantity;
                            console.log(`Stock restored for variant ${item.name} (${item.selectedVariants.map(v => v.value).join(', ')}) after failed Paymob payment.`);
                        } else {
                            product.stock += item.quantity;
                            console.warn(`Variant option not found for ${item.name}. Restoring main product stock.`);
                        }
                    } else {
                        product.stock += item.quantity;
                        console.log(`Stock restored for product ${item.name} after failed Paymob payment.`);
                    }
                    await product.save();
                }
            }
        }
        await order.save();
        res.status(200).send('Callback received and processed.');

    } catch (err) {
        console.error('Paymob Callback Processing Error:', err);
        res.status(500).send('Server error processing callback.');
    }
});


// 1. POST Create a new order (for Cash on Delivery only) (http://localhost:3000/api/orders) - Now supports guests
router.post('/', async (req, res) => { // Removed 'auth' middleware
    // orderData contains shippingAddress, paymentMethod, and items with variant data from frontend
    const { shippingAddress, paymentMethod, items: clientItems } = req.body;
    const userId = req.user ? req.user.id : null; // userId is now optional

    if (paymentMethod !== 'Cash on Delivery') {
        return res.status(400).json({ message: 'Invalid payment method for this endpoint. Only Cash on Delivery is allowed here.' });
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.email || !shippingAddress.phone || !shippingAddress.addressLine1 || !shippingAddress.city || !shippingAddress.country) {
        return res.status(400).json({ message: 'All shipping address fields are required.' });
    }

    try {
        let totalAmount = 0;
        const orderItems = []; // This will contain all fields needed for Order model
        let sourceItems = []; // This will hold items from cart (authenticated) or clientItems (guest)

        if (userId) { // Authenticated user
            // For authenticated users, re-fetch from cart to ensure data integrity
            const cart = await Cart.findOne({ userId }).populate('items.productId');
            if (!cart || cart.items.length === 0) {
                return res.status(400).json({ message: 'Your cart is empty. Cannot create an order.' });
            }
            sourceItems = cart.items;
        } else { // Guest user
            // For guest users, source items come directly from the request body (clientItems)
            if (!clientItems || clientItems.length === 0) {
                return res.status(400).json({ message: 'No items provided for guest checkout.' });
            }
            // For guest, we need to fetch full product details for stock validation
            for (const clientItem of clientItems) {
                const product = await Product.findById(clientItem.productId);
                if (!product) {
                    return res.status(404).json({ message: `Product with ID ${clientItem.productId} not found.` });
                }
                // Validate stock (basic check)
                if (product.stock < clientItem.quantity) {
                    return res.status(400).json({ message: `Not enough stock for ${product.name}. Available: ${product.stock}, Requested: ${clientItem.quantity}.` });
                }
                // Reconstruct sourceItem to include populated product data (similar to authenticated cart)
                sourceItems.push({
                    productId: product, // Populated product object for consistent access
                    quantity: clientItem.quantity,
                    name: clientItem.name || product.name,
                    price: clientItem.price || product.price,
                    imageUrl: clientItem.imageUrl || product.imageUrl,
                    selectedVariants: clientItem.selectedVariants || [],
                    variantImageUrl: clientItem.variantImageUrl || '',
                    variantPriceAdjustment: clientItem.variantPriceAdjustment || 0
                });
            }
        }

        for (const item of sourceItems) {
            const product = item.productId; // This could be a populated product object or just an ID for guest re-fetch

            // Ensure product object is available
            if (!product || typeof product !== 'object') {
                const fetchedProduct = await Product.findById(item.productId);
                if (!fetchedProduct) {
                    return res.status(404).json({ message: `Product with ID ${item.productId} not found during order processing.` });
                }
                product = fetchedProduct;
            }

            // Perform stock validation again with final product data
            let itemStockToValidate = product.stock;
            if (product.variants && product.variants.length > 0 && item.selectedVariants && item.selectedVariants.length > 0) {
                let currentVariantStock = Infinity;
                for(const selVar of item.selectedVariants) {
                    const foundGroup = product.variants.find(vg => vg.name === selVar.name);
                    if(foundGroup) {
                        const foundOption = foundGroup.options.find(opt => opt.value === selVar.value);
                        if(foundOption) {
                            currentVariantStock = Math.min(currentVariantStock, foundOption.stock);
                        }
                    }
                }
                itemStockToValidate = currentVariantStock;
            }

            if (itemStockToValidate < item.quantity) {
                return res.status(400).json({ message: `Not enough stock for ${item.name}. Available: ${itemStockToValidate}, Requested: ${item.quantity}.` });
            }

            // Prepare item for database, including variant-specific details
            orderItems.push({
                productId: product._id,
                name: item.name, // Use denormalized name from cart item
                price: item.price, // Use denormalized price from cart item (variant adjusted)
                imageUrl: item.imageUrl, // Use denormalized image from cart item (variant specific)
                quantity: item.quantity,
                selectedVariants: item.selectedVariants || [], // ✅ NEW: Save selectedVariants
                variantImageUrl: item.variantImageUrl || '', // ✅ NEW: Save variantImageUrl
                variantPriceAdjustment: item.variantPriceAdjustment || 0 // ✅ NEW: Save variantPriceAdjustment
            });

            totalAmount += item.price * item.quantity;

            // Reduce stock for both authenticated and guest orders
            // Update variant-specific stock if applicable
            if (item.selectedVariants && item.selectedVariants.length > 0) {
                let foundVariantOption = null;
                for (const variantGroup of product.variants) {
                    foundVariantOption = variantGroup.options.find(opt =>
                        item.selectedVariants.some(selVar => selVar.name === variantGroup.name && selVar.value === opt.value)
                    );
                    if (foundVariantOption) {
                        break;
                    }
                }
                if (foundVariantOption) {
                    foundVariantOption.stock -= item.quantity;
                } else {
                    product.stock -= item.quantity; // Fallback
                }
            } else {
                product.stock -= item.quantity;
            }
            await product.save();
        }

        const newOrder = new Order({
            userId: userId,
            items: orderItems, // Use the enriched orderItems
            totalAmount,
            shippingAddress,
            paymentMethod,
            status: 'Pending'
        });

        const savedOrder = await newOrder.save();

        if (userId) { // Only clear cart if it's an authenticated user's order
            const userCart = await Cart.findOne({ userId });
            if (userCart) {
                userCart.items = [];
                await userCart.save();
                console.log(`User cart cleared for order ${savedOrder._id}.`);
            }
        } else {
            console.log(`Guest order ${savedOrder._id} placed - no cart to clear.`);
        }

        res.status(201).json({ message: 'Order placed successfully!', order: savedOrder });
    } catch (err) {
        console.error('Error creating COD order:', err);
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid Product ID or User ID format when creating order.' });
        } else if (err.name === 'ValidationError') {
            return res.status(400).json({ message: `Validation error creating order: ${err.message}` });
        }
        res.status(500).json({ message: 'Failed to create order due to a server error.' });
    }
});


// 2. GET orders for the authenticated user (http://localhost:3000/api/orders/my-orders) - Requires authentication
router.get('/my-orders', auth, async (req, res) => {
    console.log('--- GET /api/orders/my-orders initiated ---');
    try {
        console.log('User ID from token:', req.user.id);

        // Populate order items to include variant details for display
        const orders = await Order.find({ userId: req.user.id })
                                 .populate('items.productId', 'name imageUrl variants') // Populate product to access variant details if needed
                                 .sort({ createdAt: -1 });

        console.log('Orders fetched from DB:', orders.length);

        if (orders.length === 0) {
            console.log('No orders found for this user.');
        }

        res.json(orders);
        console.log('--- GET /api/orders/my-orders response sent ---');
    } catch (err) {
        console.error('Error fetching user orders (Caught in Catch Block):', err);
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid User ID format.' });
        }
        res.status(500).json({ message: 'Failed to retrieve your orders due to a server error.' });
    }
});

// 3. GET a single order by ID (for admin or user if it's their order) (http://localhost:3000/api/orders/:id)
router.get('/:id', auth, async (req, res) => {
    try {
        // Populate order items to include variant details for display
        const order = await Order.findById(req.params.id)
                                 .populate('userId', 'name email')
                                 .populate('items.productId', 'name imageUrl variants'); // Populate product to access variant details if needed
        if (!order) {
            return res.status(404).json({ message: 'Order not found.' });
        }
        // ✅ Allow admin to view any order, or user to view their own order (including guest orders if accessed via admin)
        // For guest orders, order.userId will be null, so only admin can view them via this route normally.
        // User's own orders are accessed via '/my-orders'
        if (req.user.isAdmin || (order.userId && order.userId.toString() === req.user.id)) { //
            res.json(order);
        } else {
            res.status(403).json({ message: 'Access denied. You can only view your own orders or if you are an admin.' });
        }
    } catch (err) {
        console.error('Error fetching single order:', err);
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid Order ID format.' });
        }
        res.status(500).json({ message: 'Failed to retrieve order details due to a server error.' });
    }
});


// 4. PUT Cancel a user's own order (http://localhost:3000/api/orders/cancel/:id) - Requires authentication (or admin)
router.put('/cancel/:id', auth, async (req, res) => {
    const orderId = req.params.id;
    const userId = req.user.id;

    try {
        const order = await Order.findById(orderId);
        if (!order) {
            return res.status(404).json({ message: 'Order not found.' });
        }

        // ✅ Allow admin to cancel any order, or user to cancel their own order.
        // Guests cannot cancel their orders via this route as it requires authentication.
        if (order.userId && order.userId.toString() !== userId && !req.user.isAdmin) { //
            return res.status(403).json({ message: 'Access denied. You can only cancel your own orders.' });
        }
        // If order.userId is null (guest order), only admin can cancel via this route.
        if (!order.userId && !req.user.isAdmin) { //
             return res.status(403).json({ message: 'Access denied. Only admins can cancel guest orders.' });
        }


        const cancellableStatuses = ['Pending', 'Processing'];
        if (!cancellableStatuses.includes(order.status)) {
            return res.status(400).json({ message: `Order cannot be cancelled. Current status: ${order.status}.` });
        }

        order.status = 'Cancelled';
        await order.save();

        // Restore stock for products. For variant products, update specific variant stock.
        for (const item of order.items) {
            const product = await Product.findById(item.productId);
            if (product) {
                if (item.selectedVariants && item.selectedVariants.length > 0) {
                    let foundVariantOption = null;
                    for (const variantGroup of product.variants) {
                        foundVariantOption = variantGroup.options.find(opt =>
                            item.selectedVariants.some(selVar => selVar.name === variantGroup.name && selVar.value === opt.value)
                        );
                        if (foundVariantOption) {
                            break;
                        }
                    }
                    if (foundVariantOption) {
                        foundVariantOption.stock += item.quantity;
                        console.log(`Stock restored for variant ${item.name} (${item.selectedVariants.map(v => v.value).join(', ')}) after cancellation.`);
                    } else {
                        product.stock += item.quantity; // Fallback
                        console.warn(`Variant option not found for ${item.name}. Restoring main product stock.`);
                    }
                } else {
                    product.stock += item.quantity;
                    console.log(`Stock restored for product ${item.name} after cancellation.`);
                }
                await product.save();
            }
        }

        res.json({ message: 'Order cancelled successfully!', order });
    } catch (err) {
        console.error('Error cancelling order:', err);
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid Order ID format for cancellation.' });
        }
        res.status(500).json({ message: 'Failed to cancel order due to a server error.' });
    }
});

// 5. PUT Update order status (for admin) (http://localhost:3000/api/orders/:id/status) - Requires admin authentication
router.put('/:id/status', adminAuth, async (req, res) => {
    const { status } = req.body;
    try {
        const order = await Order.findById(req.params.id);
        if (!order) {
            return res.status(404).json({ message: 'Order not found.' });
        }
        const validStatuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ message: 'Invalid status provided. Valid statuses are: ' + validStatuses.join(', ') + '.' });
        }

        // Logic to restore stock if status changes to Cancelled
        if (status === 'Cancelled' && order.status !== 'Cancelled') {
            for (const item of order.items) {
                const product = await Product.findById(item.productId);
                if (product) {
                    if (item.selectedVariants && item.selectedVariants.length > 0) {
                        let foundVariantOption = null;
                        for (const variantGroup of product.variants) {
                            foundVariantOption = variantGroup.options.find(opt =>
                                item.selectedVariants.some(selVar => selVar.name === variantGroup.name && selVar.value === opt.value)
                            );
                            if (foundVariantOption) {
                                break;
                            }
                        }
                        if (foundVariantOption) {
                            foundVariantOption.stock += item.quantity;
                        } else {
                            product.stock += item.quantity; // Fallback
                        }
                    } else {
                        product.stock += item.quantity;
                    }
                    await product.save();
                    console.log(`Stock restored for product ${item.name} due to status change to Cancelled.`);
                }
            }
        }
        // Logic to reduce stock if status changes from Cancelled to active status
        if (order.status === 'Cancelled' && status !== 'Cancelled') {
             for (const item of order.items) {
                const product = await Product.findById(item.productId);
                if (product) {
                    // Check available stock (variant specific) before reducing
                    let itemStockToValidate = product.stock;
                    if (item.selectedVariants && item.selectedVariants.length > 0) {
                        let currentVariantStock = Infinity;
                        for(const selVar of item.selectedVariants) {
                            const foundGroup = product.variants.find(vg => vg.name === selVar.name);
                            if(foundGroup) {
                                const foundOption = foundGroup.options.find(opt => opt.value === selVar.value);
                                if(foundOption) {
                                    currentVariantStock = Math.min(currentVariantStock, foundOption.stock);
                                }
                            }
                        }
                        itemStockToValidate = currentVariantStock;
                    }

                    if (itemStockToValidate < item.quantity) {
                        return res.status(400).json({ message: `Cannot change status from Cancelled to ${status}. Not enough stock for product "${item.name}". Available: ${itemStockToValidate}, Ordered: ${item.quantity}.` });
                    }

                    if (item.selectedVariants && item.selectedVariants.length > 0) {
                        let foundVariantOption = null;
                        for (const variantGroup of product.variants) {
                            foundVariantOption = variantGroup.options.find(opt =>
                                item.selectedVariants.some(selVar => selVar.name === variantGroup.name && selVar.value === opt.value)
                            );
                            if (foundVariantOption) {
                                break;
                            }
                        }
                        if (foundVariantOption) {
                            foundVariantOption.stock -= item.quantity;
                        } else {
                            product.stock -= item.quantity; // Fallback
                        }
                    } else {
                        product.stock -= item.quantity;
                    }
                    await product.save();
                    console.log(`Stock reduced for product ${item.name} due to status change from Cancelled.`);
                }
            }
        }

        order.status = status;
        await order.save();
        res.json({ message: 'Order status updated successfully!', order });
    } catch (err) {
        console.error('Error updating order status:', err);
        if (err.name === 'CastError') {
            return res.status(400).json({ message: 'Invalid Order ID format for status update.' });
        } else if (err.name === 'ValidationError') {
            return res.status(400).json({ message: `Validation error updating status: ${err.message}` });
        }
        res.status(500).json({ message: err.message || 'Failed to update order status due to a server error.' });
    }
});

console.log('orderRoutes.js: Router configuration complete, returning router.');
return router;
};