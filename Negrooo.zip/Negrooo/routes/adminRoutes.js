const express = require('express');
const router = express.Router();

console.log('Admin Routes: Loaded and active.');

// --- Admin Dashboard Home (HTML Page) ---
router.get('/', async (req, res) => {
    console.log('Admin Routes: GET / (Dashboard) requested.');
    try {
        res.render('admin/dashboard', {
            title: 'Admin Dashboard',
            activePage: 'dashboard'
        });
    } catch (error) {
        console.error('Error rendering admin dashboard HTML:', error);
        res.status(500).send('Error loading dashboard page.');
    }
});

// --- Manage Products (HTML Page) ---
router.get('/products', async (req, res) => {
    try {
        res.render('admin/products', {
            title: 'Manage Products',
            activePage: 'products'
        });
    } catch (err) {
        console.error('Error loading products for admin:', err);
        res.status(500).send('Error loading products.');
    }
});

// --- Add New Product Form (HTML Page) ---
router.get('/products/new', async (req, res) => {
    res.render('admin/productForm', {
        title: 'Add New Product',
        activePage: 'products'
    });
});

// --- Edit Product Form (HTML Page) ---
router.get('/products/edit/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        res.render('admin/productForm', {
            title: 'Edit Product',
            productId: productId,
            activePage: 'products'
        });
    } catch (err) {
        console.error('Error loading product edit page:', err);
        res.status(500).send('Error loading product edit page.');
    }
});

// --- Manage Orders (HTML Page) ---
router.get('/orders', async (req, res) => {
    try {
        res.render('admin/orders', {
            title: 'Manage Orders',
            activePage: 'orders'
        });
    } catch (err) {
        console.error('Error loading orders for admin:', err);
        res.status(500).send('Error loading orders.');
    }
});

// --- Order Details (HTML Page) ---
router.get('/orders/:id', async (req, res) => {
    try {
        const orderId = req.params.id;
        res.render('admin/orderDetails', {
            title: 'Order Details',
            orderId: orderId,
            activePage: 'orders'
        });
    } catch (err) {
        console.error('Error rendering order details page:', err);
        res.status(500).send('Error loading order details page.');
    }
});

// --- Manage Categories (HTML Page) ---
router.get('/categories', async (req, res) => {
    try {
        res.render('admin/categories', {
            title: 'Manage Categories',
            activePage: 'categories'
        });
    } catch (err) {
        console.error('Error loading categories for admin:', err);
        res.status(500).send('Error loading categories page.');
    }
});

// --- Add New Category Form (HTML Page) ---
router.get('/categories/new', async (req, res) => {
    res.render('admin/categoryForm', {
        title: 'Add New Category',
        activePage: 'categories'
    });
});

// --- Edit Category Form (HTML Page) ---
router.get('/categories/edit/:id', async (req, res) => {
    try {
        const categoryId = req.params.id;
        res.render('admin/categoryForm', {
            title: 'Edit Category',
            categoryId: categoryId,
            activePage: 'categories'
        });
    } catch (err) {
        console.error('Error loading category edit page:', err);
        res.status(500).send('Error loading category edit page.');
    }
});

// --- Manage Users (HTML Page) ---
router.get('/users', async (req, res) => {
    try {
        res.render('admin/users', {
            title: 'Manage Users',
            activePage: 'users'
        });
    } catch (err) {
        console.error('Error loading users management page:', err);
        res.status(500).send('Error loading users management page.');
    }
});

// ✅ Manage Reviews (HTML Page)
router.get('/reviews', async (req, res) => {
    try {
        res.render('admin/reviews', {
            title: 'Manage Reviews',
            activePage: 'reviews'
        });
    } catch (err) {
        console.error('Error loading reviews management page:', err);
        res.status(500).send('Error loading reviews management page.');
    }
});

// ✅ NEW: Manage Coupons (HTML Page)
const { adminAuth } = require('../middleware/authMiddleware'); // Import adminAuth middleware
router.get('/coupons', adminAuth, (req, res) => {
    res.render('admin/coupons', {
        title: 'Manage Coupons',
        activePage: 'coupons'
    });
});


module.exports = router;