require('dotenv').config(); // Load environment variables from .env file

// --- Debugging Logs (يمكن حذفها لاحقاً) ---
console.log('--- Dotenv loaded ---');
// console.log('Process ENV JWT_SECRET:', process.env.JWT_SECRET);
console.log('Process ENV PORT:', process.env.PORT);
// --- نهاية أسطر التتبع ---

const express = require('express');
const app = express();
const mongoose = require('mongoose');
const compression = require('compression'); // For Gzip compression
const helmet = require('helmet'); // For security headers
const cookieParser = require('cookie-parser'); // ✅ NEW: Import cookie-parser
const PORT = process.env.PORT || 3000; // Use PORT from .env, or default to 3000
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;

const User = require('./models/User');
const Review = require('./models/Review');
const Category = require('./models/Category');
const Notification = require('./models/Notification');
const multer = require('multer');
const path = require('path');
const axios = require('axios'); // تأكد من استيراده إذا كنت تستخدم Paymob

const PAYMOB_API_KEY = process.env.PAYMOB_API_KEY;
const PAYMOB_HMAC_SECRET = process.env.PAYMOB_HMAC_SECRET;
const PAYMOB_INTEGRATION_ID_CARD = process.env.PAYMOB_INTEGRATION_ID_CARD;
const PAYMOB_MERCHANT_ID = process.env.PAYMOB_MERCHANT_ID;
const PAYMOB_IFRAME_ID = process.env.PAYMOB_IFRAME_ID;


// Configure EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', './views');

// Import ALL Routes (APIs and Admin)
const productRoutes = require('./routes/productRoutes');
const cartRoutes = require('./routes/cartRoutes');
const adminRoutes = require('./routes/adminRoutes');
const authRoutes = require('./routes/authRoutes');
const adminApiRoutes = require('./routes/adminApiRoutes');
const reviewRoutes = require('./routes/reviewRoutes');
const wishlistRoutes = require('./routes/wishlistRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const userRoutes = require('./routes/userRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const couponRoutes = require('./routes/couponRoutes'); // ✅ NEW: Import coupon routes

const { auth, adminAuth } = require('./middleware/authMiddleware');

const MONGODB_URI = process.env.MONGODB_URI;

mongoose.connect(MONGODB_URI)
    .then(() => {
        console.log('Connected to MongoDB Atlas!');
    })
    .catch((error) => {
        console.error('MongoDB connection error:', error);
        process.exit(1);
    });

// --- Multer Configuration for file uploads (Product Images/Videos) ---
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        let destFolder = 'public/uploads/';
        if (file.fieldname === 'mainImage' || file.fieldname === 'additionalImages') {
            destFolder += 'products/';
        } else if (file.fieldname === 'categoryImage') {
            destFolder += 'categories/';
        } else if (file.fieldname.startsWith('variantImage_')) { // ✅ NEW: Handle variant images
            destFolder += 'products/variants/'; // Store variant images in a subfolder
        }
        const fullDestPath = path.join(__dirname, destFolder);
        // ✅ سجل جديد: مسار الوجهة
        console.log(`Multer: Destination set to ${fullDestPath} for field ${file.fieldname}.`);
        if (!require('fs').existsSync(fullDestPath)) {
            console.log(`Multer: Creating destination directory: ${fullDestPath}`); // ✅ سجل جديد
            require('fs').mkdirSync(fullDestPath, { recursive: true });
        }
        cb(null, destFolder);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const fileExtension = path.extname(file.originalname);
        let newFilename;
        if (file.fieldname.startsWith('variantImage_')) { // ✅ NEW: Differentiate variant image filenames
            // Use the original fieldname for context, but ensure uniqueness
            newFilename = `${file.fieldname}-${uniqueSuffix}${fileExtension}`;
        } else {
            newFilename = `${file.fieldname}-${uniqueSuffix}${fileExtension}`;
        }
        console.log(`Multer: Saving file as ${newFilename} for field ${file.fieldname}.`); // ✅ سجل جديد
        cb(null, newFilename);
    }
});

const fileFilter = (req, file, cb) => {
    console.log(`Multer: Filtering file ${file.originalname} with mimetype ${file.mimetype}.`); // ✅ سجل جديد
    if (file.mimetype.startsWith('image/') || file.mimetype.startsWith('video/')) {
        cb(null, true);
    } else {
        console.warn(`Multer: Rejected file ${file.originalname} due to unsupported mimetype.`); // ✅ سجل تحذير
        cb(new Error('Only image and video files are allowed!'), false);
    }
};

const upload = multer({ storage: storage, fileFilter: fileFilter, limits: { fileSize: 50 * 1024 * 1024 } }); // 50MB limit


// --- Body Parsing Middlewares ---
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser()); // ✅ NEW: Use cookie-parser middleware

// --- Security Middlewares ---
app.use(
    helmet.contentSecurityPolicy({
        directives: {
            'script-src': ["'self'", "https://cdn.jsdelivr.net", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
            // ✅ التعديل هنا: إضافة التجزئة (hash) للسماح بتنفيذ الكود المضمن المؤقت
            'script-src-elem': ["'self'", "https://cdn.jsdelivr.net", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com", "'sha256-D0tY4q6sTBgx6KfBz49OxdG6/d9hSbGg2Rjcug+XMZk='"],
            'img-src': [
                "'self'",
                "data:",
                "https://images.unsplash.com",
                "https://via.placeholder.com",
                APP_URL ,
                "blob:"
            ],
            'media-src': [
                "'self'",
                APP_URL,
                "blob:"
            ],
           'style-src': ["'self'", "https://cdn.jsdelivr.net", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com", "'unsafe-inline'"],
            'style-src-elem': ["'self'", "https://cdn.jsdelivr.net", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com", "'unsafe-inline'"],
            'connect-src': ["'self'", APP_URL, "https://accept.paymobsolutions.com", "https://api.paymob.com"],
            'font-src': ["'self'", "https://fonts.gstatic.com", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
            'object-src': ["'none'"],
            'worker-src': ["'self'"],
            'frame-src': ["'self'", "https://accept.paymobsolutions.com"],
        },
    })
);
app.use(helmet.crossOriginResourcePolicy({ policy: "cross-origin" }));
app.use(compression());

// --- Custom logging middleware (يمكن حذفها لاحقاً) ---
app.use((req, res, next) => {
    // console.log('*** Request received:', req.method, req.originalUrl); // يمكن تفعيل هذا للتتبع
    // if (req.body && Object.keys(req.body).length > 0) {
    //     console.log('*** Parsed Request Body:', req.body);
    // } else if (req.method === 'POST' || req.method === 'PUT' || req.method === 'DELETE') {
    //     console.log('*** Empty Request Body for:', req.originalUrl);
    // }
    next();
});

// --- IMPORTANT: Define ALL API Routes FIRST ---
// ✅ تم تمرير axios ومتغيرات Paymob إلى orderRoutes
const orderRoutes = require('./routes/orderRoutes')({ axios, PAYMOB_API_KEY, PAYMOB_HMAC_SECRET, PAYMOB_INTEGRATION_ID_CARD, PAYMOB_MERCHANT_ID, PAYMOB_IFRAME_ID });

app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/wishlist', wishlistRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/users', userRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/coupons', couponRoutes); // ✅ NEW: Use coupon routes

// مسارات Admin API التي تستقبل رفع الملفات
// ✅ هذا هو المكان الذي يتم فيه تطبيق Multer middleware
app.use('/api/admin', adminAuth, (req, res, next) => {
    console.log('Multer Middleware: Applying upload.fields for /api/admin route.'); // ✅ سجل جديد
    const fieldsToUpload = [
        { name: 'mainImage', maxCount: 1 },
        { name: 'additionalImages', maxCount: 10 },
        { name: 'categoryImage', maxCount: 1 }
    ];

    // ✅ NEW: Dynamically add fields for variant images (assuming a max number for robustness)
    // We'll allow up to 5 variant groups, each with up to 10 options, each having 1 image.
    // This creates fields like 'variantImage_groupIndex_optionIndex'.
    for (let g = 0; g < 5; g++) { // Max 5 variant groups
        for (let o = 0; o < 10; o++) { // Max 10 options per group
            fieldsToUpload.push({ name: `variantImage_${g}_${o}`, maxCount: 1 });
        }
    }

    upload.fields(fieldsToUpload)(req, res, (err) => {
        if (err) {
            console.error('Multer Middleware: Error during upload processing:', err); // ✅ سجل الخطأ
            if (err instanceof multer.MulterError) {
                return res.status(400).json({ message: 'File upload error: ' + err.message });
            } else {
                return res.status(500).json({ message: 'An unknown file upload error occurred: ' + err.message });
            }
        }
        console.log('Multer Middleware: File upload processed. Proceeding to adminApiRoutes.'); // ✅ سجل جديد
        next();
    });
}, adminApiRoutes);


// --- Admin Panel HTML Page Routes ---
app.use('/admin', adminRoutes);

// --- Serve static files from the 'public' directory ---
app.use(express.static('public'));

// Example API endpoint for testing
app.get('/api/hello', (req, res) => {
    res.json({ message: 'Hello from the backend!' });
});

// --- Handle 404 Not Found for any other requests (Fallback) ---
// ✅ Middleware لمعالجة الأخطاء بشكل عام
app.use((err, req, res, next) => {
    console.error('Global Error Handler: Detected an error!', err); // ✅ سجل جديد
    if (res.headersSent) { // إذا تم إرسال الـ headers بالفعل
        return next(err); // مرر الخطأ إلى Express ليقوم بمعالجته الافتراضية
    }

    if (err instanceof multer.MulterError) {
        console.error('Global Error Handler: Multer Error caught:', err.message);
        return res.status(400).json({ message: 'File upload error: ' + err.message });
    } else if (err.message === 'File too large') { // مثال على خطأ حجم الملف
        console.error('Global Error Handler: File too large error caught.');
        return res.status(413).json({ message: 'File too large.' });
    } else if (err) {
        console.error('Global Error Handler: General Error caught:', err.message);
        return res.status(500).json({ message: 'Internal server error: ' + err.message });
    }
    next(); // إذا لم يكن خطأ، مرر الطلب
});

// ✅ 404 handler (يجب أن يكون في النهاية بعد كل الـ routes)
app.use((req, res, next) => {
    res.status(404).send('Sorry, can\'t find that!');
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});