// public/js/main.js

// Define global functions first
window.updateCartCount = async () => { // Made async as it might fetch
    const cartItemCountSpan = document.getElementById('cart-item-count');
    if (!cartItemCountSpan) return;

    if (typeof window.getCartItemCount === 'function') {
        // If logged in, fetch from API. Otherwise, get from local window.cartItems.
        if (window.isLoggedIn()) {
            try {
                const response = await fetch('http://localhost:3000/api/cart', {
                    headers: window.getAuthHeaders()
                });
                const data = await response.json();
                if (response.ok) {
                    window.cartItems = data.items; // Keep window.cartItems updated
                    const totalItems = data.items.reduce((sum, item) => sum + item.quantity, 0);
                    cartItemCountSpan.textContent = totalItems;
                    window.updateMiniCart(data); // Pass full cart object
                } else {
                    console.error('Failed to fetch cart for count in updateCartCount (main.js):', data.message);
                    cartItemCountSpan.textContent = '0';
                    window.updateMiniCart(null);
                }
            } catch (error) {
                console.error('Error fetching cart count in updateCartCount (main.js):', error);
                cartItemCountSpan.textContent = '0';
                window.updateMiniCart(null);
            }
        } else {
            // For guest users, rely on local window.cartItems which should be loaded by loadCart
            if (typeof window.loadCart === 'function') {
                await window.loadCart(); // Ensure guest cart is loaded
            }
            cartItemCountSpan.textContent = window.getCartItemCount();
            if (typeof window.getCartItems === 'function' && typeof window.updateMiniCart === 'function') {
                window.updateMiniCart({ items: window.getCartItems() });
            } else {
                window.updateMiniCart(null);
            }
        }
    } else {
        console.warn('window.getCartItemCount is not defined in main.js. Cart count might not update.');
    }
};

window.updateNavbar = async () => {
    const navLoginLink = document.getElementById('nav-login-link');
    const navRegisterLink = document.getElementById('nav-register-link');
    const navMyOrdersLink = document.getElementById('nav-myorders-link');
    const navLogoutLink = document.getElementById('nav-logout-link');
    const adminDashboardLink = document.getElementById('admin-dashboard-link');
    const navWishlistLink = document.getElementById('nav-wishlist-link');
    const navProfileLink = document.getElementById('nav-profile-link');
    const navNotificationsLink = document.getElementById('nav-notifications-link');

    if (window.isLoggedIn()) {
        try {
            const currentUser = window.getCurrentUser();
            let userFetched = null;

            const response = await fetch('http://localhost:3000/api/users/profile', {
                headers: window.getAuthHeaders()
            });

            if (response.ok) {
                userFetched = await response.json();
                localStorage.setItem('user', JSON.stringify(userFetched));
            } else {
                console.error('Failed to fetch current user data from profile API. Logging out.', await response.json());
                window.logoutUser();
                return;
            }

            if (navLoginLink) navLoginLink.style.display = 'none';
            if (navRegisterLink) navRegisterLink.style.display = 'none';
            if (navProfileLink) navProfileLink.style.display = 'list-item';
            if (navWishlistLink) navWishlistLink.style.display = 'list-item';
            if (navNotificationsLink) navNotificationsLink.style.display = 'list-item';
            if (navMyOrdersLink) navMyOrdersLink.style.display = 'list-item'; // Added visibility for My Orders

            if (userFetched && userFetched.isAdmin) { // Use userFetched for isAdmin check
                if (adminDashboardLink) adminDashboardLink.style.display = 'list-item';
            } else {
                if (adminDashboardLink) adminDashboardLink.style.display = 'none';
            }

            if (navLogoutLink) {
                if (window.location.pathname.includes('user-dashboard.html')) {
                    navLogoutLink.style.display = 'none';
                } else {
                    navLogoutLink.style.display = 'list-item';
                }
            }

            window.updateCartCount();
            window.updateNotificationCount();

        } catch (error) {
            console.error('Error fetching current user for navbar update. Logging out.', error);
            window.logoutUser();
        }
    } else {
        if (navLoginLink) navLoginLink.style.display = 'list-item';
        if (navRegisterLink) navRegisterLink.style.display = 'list-item';
        if (navProfileLink) navProfileLink.style.display = 'none';
        if (navWishlistLink) navWishlistLink.style.display = 'none';
        if (navNotificationsLink) navNotificationsLink.style.display = 'none';
        if (adminDashboardLink) adminDashboardLink.style.display = 'none';
        if (navLogoutLink) navLogoutLink.style.display = 'none';
        if (navMyOrdersLink) navMyOrdersLink.style.display = 'none'; // Added visibility for My Orders

        if (document.getElementById('cart-item-count')) document.getElementById('cart-item-count').textContent = '0';
        if (window.updateMiniCart) window.updateMiniCart(null);
        if (document.getElementById('notification-count')) document.getElementById('notification-count').textContent = '0';
        if (document.getElementById('notification-count')) document.getElementById('notification-count').style.display = 'none';
    }

    const logoutButtonFromNav = document.getElementById('logout-button');
    if (logoutButtonFromNav) {
        logoutButtonFromNav.removeEventListener('click', window.logoutUser);
        logoutButtonFromNav.addEventListener('click', window.logoutUser);
    }
    if (typeof window.populateCategoriesDropdown === 'function') {
        window.populateCategoriesDropdown();
    } else {
        console.warn('window.populateCategoriesDropdown is not defined in main.js. Categories dropdown might not populate.');
    }
};

// MODIFIED: fetchProducts function now accepts filters and handles pagination
window.fetchProducts = async (filters = {}) => {
    const productsContainer = document.getElementById('products-container');
    // For bestsellers section, we need to pass a specific container
    const targetContainerId = filters.targetContainerId || 'products-container';
    const currentProductsContainer = document.getElementById(targetContainerId);


    if (!currentProductsContainer) {
        console.log(`Product container element #${targetContainerId} not found. Skipping product fetch.`);
        return;
    }

    currentProductsContainer.innerHTML = '<div class="col-12 text-center"><p class="text-muted">Loading products...</p></div>';
    try {
        let url = new URL('http://localhost:3000/api/products'); // Use URL object for easier param management

        // Set URL search parameters from filters
        const currentUrl = new URL(window.location.href); // Get current URL to update browser history
        for (const key in filters) {
            // Skip targetContainerId as it's not a backend filter
            if (key === 'targetContainerId') continue;

            if (filters[key] !== '' && filters[key] !== 'All' && filters[key] !== undefined && filters[key] !== null) { // More robust check
                // For variant filters, convert array to JSON string
                if (key === 'variants' && Array.isArray(filters[key])) {
                    url.searchParams.set(key, JSON.stringify(filters[key]));
                    currentUrl.searchParams.set(key, JSON.stringify(filters[key]));
                } else {
                    url.searchParams.set(key, filters[key]);
                    currentUrl.searchParams.set(key, filters[key]);
                }
            } else {
                url.searchParams.delete(key);
                currentUrl.searchParams.delete(key);
            }
        }
        // Only update URL if on products.html or if it's a specific product fetch for index.html (main products section)
        // Do not update URL for bestsellers section as it's a sub-fetch.
        if (window.location.pathname.includes('products.html') || (window.location.pathname === '/' && targetContainerId === 'products-container')) {
            window.history.replaceState({}, '', currentUrl.toString()); // Update browser URL
        }


        // Fetch products using the constructed URL
        console.log("Fetching products from URL:", url.toString());
        const response = await fetch(url.toString(), { // Use url.toString()
            headers: window.getAuthHeaders()
        });
        const data = await response.json(); // Parse JSON even if response.ok is false, to get error message
        if (!response.ok) {
            throw new Error(data.message || `HTTP error! status: ${response.status}`);
        }
        const products = data.products;
        const totalPages = data.totalPages;
        const currentPage = data.currentPage;

        // Pass the correct container ID to displayProducts
        window.displayProducts(products, targetContainerId); // Pass products and container ID
        
        // Render pagination only for products.html (or if specifically requested)
        if (targetContainerId === 'products-container' && window.location.pathname.includes('products.html')) {
            renderPagination(totalPages, currentPage); // Render pagination controls
        }

        // Populate variant filters if on products.html or index.html and container exists
        const variantFiltersContainer = document.getElementById('variantFiltersContainer');
        if (variantFiltersContainer) { // Only attempt to populate if the container exists
             window.populateVariantFilters(products); // Call to populate variant filters based on fetched products
        }

    } catch (error) {
        console.error('Error fetching products for frontend:', error);
        currentProductsContainer.innerHTML = `<div class="col-12 text-center"><p class="text-danger">Failed to load products: ${error.message}</p></div>`;
        window.showToast(`Failed to load products: ${error.message}`, 'danger');
    }
};

// NEW: Function to render pagination controls
function renderPagination(totalPages, currentPage) {
    const productsPagination = document.getElementById('products-pagination');
    if (!productsPagination) return; // Pagination may not exist on index.html
    productsPagination.innerHTML = ''; // Clear previous pagination

    if (totalPages <= 1) return; // No pagination needed for 1 or fewer pages

    const createPaginationItem = (pageNumber, text, isActive = false, isDisabled = false) => {
        const li = document.createElement('li');
        li.className = `page-item ${isActive ? 'active' : ''} ${isDisabled ? 'disabled' : ''}`;
        const a = document.createElement('a');
        a.className = 'page-link';
        a.href = '#';
        a.textContent = text;
        a.addEventListener('click', (e) => {
            e.preventDefault();
            if (!isDisabled && !isActive) {
                window.applyProductFilters(pageNumber); // Apply filters for the selected page
            }
        });
        li.appendChild(a);
        return li;
    };

    // Previous button
    productsPagination.appendChild(createPaginationItem(currentPage - 1, 'Previous', false, currentPage === 1));

    // Page numbers
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, currentPage + 2);

    if (startPage > 1) {
        productsPagination.appendChild(createPaginationItem(1, '1'));
        if (startPage > 2) {
            productsPagination.appendChild(createPaginationItem(null, '...', false, true));
        }
    }

    for (let i = startPage; i <= endPage; i++) {
        productsPagination.appendChild(createPaginationItem(i, i.toString(), i === currentPage));
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            productsPagination.appendChild(createPaginationItem(null, '...', false, true));
        }
        productsPagination.appendChild(createPaginationItem(totalPages, totalPages.toString()));
    }

    // Next button
    productsPagination.appendChild(createPaginationItem(currentPage + 1, 'Next', false, currentPage === totalPages));
}

// Modified populateCategoriesDropdown to accept a targetDropdown element
window.populateCategoriesDropdown = async (targetDropdown = null) => {
    const categoriesDropdownNavbar = document.getElementById('categories-dropdown'); // Navbar dropdown

    // Ensure we have at least one target for population
    if (!categoriesDropdownNavbar && !targetDropdown) {
        console.log("No category dropdown elements found. Skipping population.");
        return;
    }

    let categories = [];
    const cachedCategories = localStorage.getItem('categories_cache');
    if (cachedCategories) {
        const { data, timestamp } = JSON.parse(cachedCategories);
        const cacheDuration = 1000 * 60 * 60; // 1 hour in milliseconds
        if (Date.now() - timestamp < cacheDuration) {
            categories = data;
            console.log('Categories loaded from cache.');
        } else {
            console.log('Categories cache expired.');
        }
    }

    if (categories.length === 0) {
        try {
            const response = await fetch('http://localhost:3000/api/categories', {
                headers: window.getAuthHeaders()
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }
            categories = data; // Assuming data is the array of categories
            localStorage.setItem('categories_cache', JSON.stringify({ data: categories, timestamp: Date.now() }));
            console.log('Categories fetched from API and cached.');

        }
     catch (error) {
            console.error('Error fetching categories for dropdown:', error);
            if (categoriesDropdownNavbar) {
                const listItem = document.createElement('li');
                listItem.innerHTML = '<a class="dropdown-item" href="#">Error loading categories</a>';
                categoriesDropdownNavbar.innerHTML = '';
                categoriesDropdownNavbar.appendChild(listItem);
            }
            if (targetDropdown) { // For filter sidebar dropdown
                targetDropdown.innerHTML = '<option value="All">Error loading categories</option>';
                targetDropdown.disabled = true;
            }
            window.showToast(`Failed to load categories for dropdown: ${error.message}`, 'danger');
            return;
        }
    }

    // Populate Navbar Dropdown
    if (categoriesDropdownNavbar) {
        categoriesDropdownNavbar.innerHTML = '';
        if (categories.length === 0) {
            const listItem = document.createElement('li');
            listItem.innerHTML = '<a class="dropdown-item" href="#">No Categories</a>';
            categoriesDropdownNavbar.appendChild(listItem);
        } else {
            categories.forEach(category => {
                const listItem = document.createElement('li');
                listItem.innerHTML = `<a class="dropdown-item" href="products.html?category=${encodeURIComponent(category.name)}">${category.name}</a>`;
                categoriesDropdownNavbar.appendChild(listItem);
            });
        }
        console.log(`Successfully populated categories navbar dropdown with ${categories.length} items.`);
    }

    // Populate Filter Sidebar Dropdown
    if (targetDropdown) { // If a targetDropdown element was passed (for filter sidebar)
        targetDropdown.innerHTML = '<option value="All">All Categories</option>';
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.name;
            option.textContent = category.name;
            targetDropdown.appendChild(option);
        });
        // Set selected value based on URL params if products.html is loaded directly with category filter
        const urlParams = new URLSearchParams(window.location.search);
        const categoryFromUrl = urlParams.get('category');
        if (categoryFromUrl) {
            targetDropdown.value = categoryFromUrl;
        }
        console.log(`Successfully populated categories filter dropdown with ${categories.length} items.`);
    }
};


window.fetchAndDisplayCategories = async (limit = null) => {
    // Query elements inside the function to ensure DOM readiness
    const featuredCategoriesContainer = document.getElementById('featured-categories-container');
    const allCategoriesContainer = document.getElementById('all-categories-container');

    const containerToUse = limit ? featuredCategoriesContainer : allCategoriesContainer;

    if (!containerToUse) {
        console.log("Categories container element not found. Skipping category display.");
        return;
    }

    containerToUse.innerHTML = `<div class="col-12 text-center text-muted">Loading ${limit ? 'featured ' : 'all '}categories...</div>`;

    const cachedCategories = localStorage.getItem('categories_cache');
    let categories = [];

    if (cachedCategories) {
        categories = JSON.parse(cachedCategories).data;
    }

    if (categories.length === 0) {
        try {
            const response = await fetch('http://localhost:3000/api/categories', {
                headers: window.getAuthHeaders()
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }
            categories = data; // Assuming data is the array of categories
            localStorage.setItem('categories_cache', JSON.stringify({ data: categories, timestamp: Date.now() }));
        } catch (error) {
            console.error('Error fetching categories:', error);
            containerToUse.innerHTML = `<div class="col-12 text-center text-danger">Failed to load categories: ${error.message}</div>`;
            window.showToast(`Failed to load categories: ${error.message}`, 'danger');
            return;
        }
    }

    if (limit) {
        categories = categories.slice(0, limit);
    }

    window.displayCategories(categories, containerToUse);
};

window.displayCategories = (categories, container) => {
    container.innerHTML = '';
    if (!Array.isArray(categories) || categories.length === 0) { // Defensive check
        container.innerHTML = '<div class="col-12 text-center text-muted">No categories available yet.</div>';
        return;
    }

    categories.forEach(category => {
        const categoryCard = document.createElement('div');
        if (container.id === 'featured-categories-container') {
            categoryCard.classList.add('col-md-4', 'col-lg-4', 'mb-4');
        } else if (container.id === 'all-categories-container') {
            categoryCard.classList.add('col-md-4', 'col-lg-3', 'mb-4');
        }

        categoryCard.innerHTML = `
            <a href="products.html?category=${encodeURIComponent(category.name)}" class="card category-card">
                <img src="${category.imageUrl || '/images/placeholder-category.jpg'}" class="card-img-top category-card-image" alt="${category.name}">
            </a>
            <div class="card-body category-card-body">
                <h5 class="card-title category-card-title">${category.name}</h5>
            </div>
        `;
        container.appendChild(categoryCard);
    });
};


window.displayProducts = (products, containerId = 'products-container') => { // Accept container ID
    const productsContainer = document.getElementById(containerId);
    if (!productsContainer) return;

    productsContainer.innerHTML = '';
    // ✅ FIX: Add defensive check to ensure products is an array before calling forEach
    if (!Array.isArray(products) || products.length === 0) {
        productsContainer.innerHTML = '<div class="col-12 text-center"><p class="text-muted">No products available matching your criteria.</p></div>';
        return;
    }

    products.forEach(product => {
        // Build variant display for product card
        let variantDisplayHtml = '';
        if (product.variants && product.variants.length > 0) {
            // Collect all unique variant group names
            const variantGroupNames = product.variants.map(group => group.name);
            if (variantGroupNames.length > 0) {
                // Display names of available variant groups (e.g., "Color, Size")
                variantDisplayHtml = `<p class="card-text text-muted mb-0"><small>Available in: ${variantGroupNames.join(', ')}</small></p>`;
            } else {
                // Fallback if variants array is structured but no names or options found
                variantDisplayHtml = `<p class="card-text text-muted mb-0"><small>Multiple Options Available</small></p>`;
            }
        }


        const productCard = document.createElement('div');
        productCard.classList.add('col-md-4', 'mb-4');
        productCard.innerHTML = `
            <div class="card h-100 product-card-custom">
                <a href="product-detail.html?id=${product._id}" class="product-card-link">
                    <img src="${product.imageUrl || '/images/placeholder-product.jpg'}" class="card-img-top product-card-image" alt="${product.name}">
                </a>
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title product-card-title">
                        <a href="product-detail.html?id=${product._id}" class="text-decoration-none text-dark">${product.name}</a>
                    </h5>
                    <p class="card-text text-muted product-card-category">${product.category}</p>
                    <p class="card-text product-card-description">${product.description.substring(0, 70)}...</p>
                    ${variantDisplayHtml} <div class="mt-auto d-flex justify-content-between align-items-center pt-2">
                        <h4 class="product-price-display">EGP${product.price.toFixed(2)}</h4>
                        <button class="btn btn-success add-to-cart-btn" data-product-id="${product._id}" data-product-name="${product.name}">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `;
        productsContainer.appendChild(productCard);
    });

    productsContainer.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', async (event) => {
            const productId = event.target.dataset.productId;
            // Removed redundant logic for logged in vs guest, now delegated to window.addToCart
            if (typeof window.addToCart === 'function') {
                await window.addToCart(productId, 1);
            } else {
                console.error('window.addToCart is not defined. Cannot add to cart.');
                window.showToast('Error: Cart functions not available. Please refresh the page.', 'danger');
            }
        });
    });
};


window.handleLoginFormSubmit = async (event) => {
    event.preventDefault();

    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    const email = emailInput.value;
    const password = passwordInput.value;

    try {
        const response = await fetch('http://localhost:3000/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            window.showToast(data.message, 'success');
            window.updateNavbar();

            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);
        } else {
            window.showToast(data.message || 'Login failed. Please check your credentials.', 'danger');
        }
    }
     catch (error) {
        console.error('Login error:', error);
        window.showToast('An error occurred during login. Please try again.', 'danger');
    }
};

window.handleRegisterFormSubmit = async (event) => {
    event.preventDefault();

    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    const name = nameInput.value;
    const email = emailInput.value;
    const password = passwordInput.value;

    try {
        const response = await fetch('http://localhost:3000/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            window.showToast(data.message, 'success');
            window.updateNavbar();

            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);
        } else {
            window.showToast(data.message || 'Registration failed. Please try again.', 'danger');
        }
    } catch (error) {
        console.error('Registration error:', error);
        window.showToast('An error occurred during registration. Please try again.', 'danger');
    }
};


// Run functions on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    // Queries elements that exist on most/all pages
    const openMiniCartBtn = document.getElementById('open-mini-cart-btn');
    const closeMiniCartBtn = document.getElementById('close-mini-cart-btn');
    const miniCartOverlay = document.getElementById('mini-cart-overlay');
    const miniCartItemsContainer = document.getElementById('mini-cart-items-container');
    const miniCartTotalSpan = document.getElementById('mini-cart-total');

    // Filter elements - Query them here as they are specific to products.html (can be null on other pages)
    const searchInput = document.getElementById('searchInput');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    const categoryFilter = document.getElementById('categoryFilter');
    const priceRangeFilter = document.getElementById('priceRangeFilter');
    const sortFilter = document.getElementById('sortFilter');
    const applyFiltersBtn = document.getElementById('applyFiltersBtn');
    const clearFiltersBtn = document.getElementById('clearFiltersBtn');
    const productsPagination = document.getElementById('products-pagination');


    // Event listeners for mini-cart
    if (openMiniCartBtn) {
        openMiniCartBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            if (typeof window.openMiniCart === 'function') {
                await window.openMiniCart();
            } else {
                console.error('window.openMiniCart is not defined. Mini cart might not open.');
            }
        });
    }
    if (closeMiniCartBtn) {
        closeMiniCartBtn.addEventListener('click', window.closeMiniCart);
    }
    if (miniCartOverlay) {
        miniCartOverlay.addEventListener('click', window.closeMiniCart);
    }

    // --- Start Mini-Cart Event Delegation ---
    if (miniCartItemsContainer) {
        miniCartItemsContainer.addEventListener('click', async (event) => {
            if (event.target.classList.contains('quantity-btn-mini-cart') || event.target.closest('.quantity-btn-mini-cart')) {
                const button = event.target.closest('.quantity-btn-mini-cart');
                const productId = button.dataset.productId;
                const itemDiv = button.closest('.mini-cart-item');
                const quantityInput = itemDiv.querySelector('.item-quantity-input-mini-cart');
                let currentQuantity = parseInt(quantityInput.value);
                const maxStock = parseInt(quantityInput.dataset.maxStock);

                const selectedVariants = button.dataset.selectedVariants ? JSON.parse(button.dataset.selectedVariants) : []; // Default to empty array

                if (button.dataset.action === 'decrease') {
                    if (currentQuantity > 1) {
                        currentQuantity--;
                    } else {
                        if (window.showToast) window.showToast('Minimum quantity is 1. Click X to delete item.', 'info');
                        return;
                    }
                } else if (button.dataset.action === 'increase') {
                    if (currentQuantity < maxStock) {
                        currentQuantity++;
                    } else {
                        if (window.showToast) window.showToast(`Max stock for this product is ${maxStock}.`, 'warning');
                        return;
                    }
                }

                quantityInput.value = currentQuantity;

                if (typeof window.updateCartItemQuantity === 'function') {
                    await window.updateCartItemQuantity(productId, currentQuantity, selectedVariants);
                } else {
                    console.error('window.updateCartItemQuantity is not defined in main.js. Cart quantity might not update.');
                    if (window.showToast) window.showToast('Error: Cart functions not available. Please refresh the page.', 'danger');
                }

            } else if (event.target.classList.contains('mini-cart-remove-btn') || event.target.closest('.mini-cart-remove-btn')) {
                const removeButton = event.target.closest('.mini-cart-remove-btn');
                const productId = removeButton.dataset.productId;

                const selectedVariants = removeButton.dataset.selectedVariants
                    ? JSON.parse(removeButton.dataset.selectedVariants)
                    : []; // Default to empty array

                if (window.confirm && window.confirm('Are you sure you want to remove this item from your cart?')) {
                    if (typeof window.removeFromCart === 'function') {
                        await window.removeFromCart(productId, selectedVariants);
                    } else {
                        console.error('window.removeFromCart is not defined in main.js. Item might not be removed.');
                        if (window.showToast) window.showToast('Error: Cart functions not available. Please refresh the page.', 'danger');
                    }
                }
            }
        });

        miniCartItemsContainer.addEventListener('input', async (event) => {
            if (event.target.classList.contains('item-quantity-input-mini-cart')) {
                const productId = event.target.dataset.productId;
                let newQuantity = parseInt(event.target.value);
                const maxStock = parseInt(event.target.dataset.maxStock);

                // التعديل الأساسي هنا: جلب selectedVariants من dataset الخاص بالعنصر event.target
                const selectedVariants = event.target.dataset.selectedVariants
                    ? JSON.parse(event.target.dataset.selectedVariants)
                    : []; // Default to empty array

                if (isNaN(newQuantity) || newQuantity < 1) {
                    newQuantity = 1; // Default to 1 if invalid input
                }
                if (newQuantity > maxStock) {
                    newQuantity = maxStock;
                    if (window.showToast) window.showToast(`Max stock for this product is ${maxStock}.`, 'warning');
                }
                event.target.value = newQuantity; // Update input value to corrected quantity
                if (typeof window.updateCartItemQuantity === 'function') {
                    await window.updateCartItemQuantity(productId, newQuantity, selectedVariants);
                } else {
                    console.error('window.updateCartItemQuantity is not defined in main.js. Cart quantity might not update.');
                    if (window.showToast) window.showToast('Error: Cart functions not available. Please refresh the page.', 'danger');
                }
            }
        });
    }
    // --- End Mini-Cart Event Delegation ---


    // Initial setup for specific pages
    if (window.location.pathname.includes('products.html')) {
        const urlParams = new URLSearchParams(window.location.search);
        const initialFilters = {
            search: urlParams.get('search') || '',
            category: urlParams.get('category') || 'All',
            minPrice: urlParams.get('minPrice') || '',
            maxPrice: urlParams.get('maxPrice') || '',
            sort: urlParams.get('sort') || '',
            page: urlParams.get('page') || '1'
        };

        // Populate filter inputs with initial values from URL
        if (searchInput) {
            searchInput.value = initialFilters.search;
            // Add event listener for live search (optional, but good for UX)
            // searchInput.addEventListener('input', () => window.applyProductFilters());
        }
        if (categoryFilter) categoryFilter.value = initialFilters.category;
        // Price inputs
        const minPriceInput = document.getElementById('minPriceInput');
        const maxPriceInput = document.getElementById('maxPriceInput');
        if (minPriceInput) minPriceInput.value = initialFilters.minPrice;
        if (maxPriceInput) maxPriceInput.value = initialFilters.maxPrice;

        if (sortFilter) sortFilter.value = initialFilters.sort;

        // Initial fetch of products with filters for products.html
        window.fetchProducts(initialFilters);

    } else if (window.location.pathname === '/' || window.location.pathname.includes('index.html')) {
        // Logic for index.html
        if (typeof window.fetchAndDisplayCategories === 'function') {
            window.fetchAndDisplayCategories(6); // Displays 6 featured categories
        } else {
            console.warn('window.fetchAndDisplayCategories is not defined. Featured categories might not load.');
        }

        // ✅ NEW: Call to fetch products for "Our Latest & Greatest" section on index.html
        const productsContainerIndex = document.getElementById('products-container'); // Get the products container in index.html
        if (productsContainerIndex) { // Only fetch if the container exists
            // Fetch latest 9 products for "Our Latest & Greatest" section on index.html
            // Adjust limit or sort based on what "Latest & Greatest" should imply
            window.fetchProducts({ limit: 9, sortBy: 'createdAt', sortOrder: 'desc', page: 1, targetContainerId: 'products-container' });
        } else {
            console.warn("products-container not found on index.html. Cannot fetch products for main page.");
        }

        // ✅ NEW: Call to fetch products for "Bestsellers" section on index.html
        const bestsellersContainer = document.getElementById('bestsellers-container'); // Get the bestsellers container in index.html
        if (bestsellersContainer) {
            // Fetch top 9 bestsellers
            window.fetchProducts({ limit: 9, bestsellers: true, targetContainerId: 'bestsellers-container' });
        } else {
            console.warn("bestsellers-container not found on index.html. Cannot fetch bestsellers.");
        }


    } else if (window.location.pathname.includes('categories.html')) {
        if (typeof window.fetchAndDisplayCategories === 'function') {
            window.fetchAndDisplayCategories();
        } else {
            console.warn('window.fetchAndDisplayCategories is not defined. All categories might not load.');
        }
    }

    // Filter button listeners (specific to products.html, apply only if elements exist)
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', () => {
            window.applyProductFilters();
        });
    }

    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            if (categoryFilter) categoryFilter.value = 'All';
            // Clear price inputs
            const minPriceInput = document.getElementById('minPriceInput');
            const maxPriceInput = document.getElementById('maxPriceInput');
            if (minPriceInput) minPriceInput.value = '';
            if (maxPriceInput) maxPriceInput.value = '';
            // Clear variant checkboxes (will be handled by populateVariantFilters when it re-renders)
            document.querySelectorAll('.variant-checkbox').forEach(checkbox => checkbox.checked = false);

            if (sortFilter) sortFilter.value = '';

            const url = new URL(window.location.href);
            url.searchParams.delete('category');
            url.searchParams.delete('search');
            url.searchParams.delete('minPrice');
            url.searchParams.delete('maxPrice');
            url.searchParams.delete('sort');
            url.searchParams.delete('page');
            url.searchParams.delete('variants'); // NEW: Clear variants from URL
            window.history.replaceState({}, document.title, url.toString());

            window.fetchProducts({});
        });
    }

    if(clearSearchBtn) {
        clearSearchBtn.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            window.applyProductFilters();
        });
    }

    // NEW: Function to apply filters (called by button click or pagination)
    window.applyProductFilters = (page = 1) => {
        const minPriceInput = document.getElementById('minPriceInput');
        const maxPriceInput = document.getElementById('maxPriceInput');
        const variantCheckboxes = document.querySelectorAll('.variant-checkbox:checked'); // Get all checked variant checkboxes

        const filters = {
            search: searchInput ? searchInput.value : '',
            category: categoryFilter ? categoryFilter.value : 'All',
            minPrice: minPriceInput ? parseFloat(minPriceInput.value) || undefined : undefined,
            maxPrice: maxPriceInput ? parseFloat(maxPriceInput.value) || undefined : undefined,
            sort: sortFilter ? sortFilter.value : '',
            page: page,
            variants: [] // Initialize variants array
        };

        // Populate selected variants
        variantCheckboxes.forEach(checkbox => {
            filters.variants.push({
                name: checkbox.dataset.variantName, // 'Color', 'Size'
                value: checkbox.value // 'Red', 'M'
            });
        });

        // If no variants selected, ensure the 'variants' filter is not sent
        if (filters.variants.length === 0) {
            delete filters.variants;
        }

        window.fetchProducts(filters);
    };


    const loginForm = document.getElementById('login-form');
    if (loginForm && typeof window.handleLoginFormSubmit === 'function') {
        loginForm.addEventListener('submit', window.handleLoginFormSubmit);
    } else if (loginForm) {
        console.warn('Login form found, but window.handleLoginFormSubmit is not defined.');
    }

    const registerForm = document.getElementById('register-form');
    if (registerForm && typeof window.handleRegisterFormSubmit === 'function') {
        registerForm.addEventListener('submit', window.handleRegisterFormSubmit);
    } else if (registerForm) {
        console.warn('Register form found, but window.handleRegisterFormSubmit is not defined.');
    }

    window.updateNavbar(); // Ensure navbar updates on all pages

    // Initial population of categories dropdown (for filter sidebar)
    // This is specific to products.html, and categoryFilter will be null on other pages.
    if (categoryFilter) {
        window.populateCategoriesDropdown(categoryFilter);
    }
});


// NEW: Function to populate variant filters dynamically
window.populateVariantFilters = (products) => {
    const variantFiltersContainer = document.getElementById('variantFiltersContainer');
    if (!variantFiltersContainer) return;

    variantFiltersContainer.innerHTML = ''; // Clear previous filters

    // Extract all unique variant groups and their options from the current set of products
    const uniqueVariantGroups = new Map(); // Map: { "Color": { "Red": true, "Blue": true }, "Size": { "S": true, "M": true } }

    if (Array.isArray(products)) { // Ensure products is an array
        products.forEach(product => {
            if (product.variants && Array.isArray(product.variants)) {
                product.variants.forEach(group => {
                    if (!uniqueVariantGroups.has(group.name)) {
                        uniqueVariantGroups.set(group.name, new Map());
                    }
                    group.options.forEach(option => {
                        uniqueVariantGroups.get(group.name).set(option.value, true);
                    });
                });
            }
        });
    }

    // Render filter UI for each unique variant group
    uniqueVariantGroups.forEach((optionsMap, groupName) => {
        const variantGroupDiv = document.createElement('div');
        variantGroupDiv.classList.add('mb-3');
        let optionsHtml = '';

        optionsMap.forEach((value, optionValue) => {
            const checkboxId = `variant-${groupName}-${optionValue.replace(/\s/g, '-')}`; // Create a unique ID
            optionsHtml += `
                <div class="form-check">
                    <input class="form-check-input variant-checkbox" type="checkbox"
                           data-variant-name="${groupName}" value="${optionValue}" id="${checkboxId}">
                    <label class="form-check-label" for="${checkboxId}">${optionValue}</label>
                </div>
            `;
        });

        variantGroupDiv.innerHTML = `
            <label class="form-label fw-bold">${groupName}:</label>
            ${optionsHtml}
        `;
        variantFiltersContainer.appendChild(variantGroupDiv);
    });

    // Re-apply previously selected variant filters from URL if any
    const urlParams = new URLSearchParams(window.location.search);
    const variantsParam = urlParams.get('variants');
    if (variantsParam) {
        try {
            const selectedVariantsFromUrl = JSON.parse(variantsParam);
            selectedVariantsFromUrl.forEach(selVar => {
                const checkboxId = `variant-${selVar.name}-${selVar.value.replace(/\s/g, '-')}`;
                const checkbox = document.getElementById(checkboxId);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        } catch (e) {
            console.error("Error parsing variants from URL:", e);
        }
    }
};