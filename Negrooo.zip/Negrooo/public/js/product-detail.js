document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    const loadingMessage = document.getElementById('loading-message');
    const errorMessage = document.getElementById('error-message');
    const productDetailContent = document.getElementById('product-detail-content');

    const productMainImage = document.getElementById('product-main-image');
    const mainImageWrapper = document.getElementById('main-image-wrapper');
    const thumbnailGallery = document.getElementById('thumbnail-gallery');
    const productName = document.getElementById('product-name');
    const productPrice = document.getElementById('product-price');
    const productShortDescription = document.getElementById('product-short-description');
    const productLongDescription = document.getElementById('product-long-description');
    const productCategory = document.getElementById('product-category');
    const productStock = document.getElementById('product-stock');
    const quantityInput = document.getElementById('quantity');
    const addToCartDetailBtn = document.getElementById('add-to-cart-detail-btn');
    const decreaseQuantityBtn = document.getElementById('decrease-quantity-btn');
    const increaseQuantityBtn = document.getElementById('increase-quantity-btn');
    const addToWishlistBtn = document.getElementById('add-to-wishlist-btn');
    const buyNowBtn = document.getElementById('buy-now-btn');

    const productSpecsDisplay = document.getElementById('product-specs');
    // ✅ FIXED: Corrected element ID to 'product-shipping-returns' to match HTML
    const productShippingReturnsDisplay = document.getElementById('product-shipping-returns');

    const ratingSummary = document.getElementById('rating-summary');
    const avgStarsSpan = document.getElementById('avg-stars');
    const reviewsCountSpan = document.getElementById('reviews-count');
    const addReviewForm = document.getElementById('add-review-form');
    const ratingInput = document.getElementById('rating-input');
    const selectedRatingInput = document.getElementById('selected-rating');
    const commentInput = document.getElementById('comment');
    const reviewsListContainer = document.getElementById('reviews-list-container');
    const reviewFormMessage = document.getElementById('review-form-message');

    const relatedProductsSection = document.getElementById('related-products-section');
    const relatedProductsContainer = document.getElementById('related-products-container');

    const shareFacebookBtn = document.getElementById('share-facebook-btn');
    const shareTwitterBtn = document.getElementById('share-twitter-btn');
    const shareWhatsappBtn = document.getElementById('share-whatsapp-btn');

    // ✅ NEW: Variant-related elements and state
    const productVariantsSection = document.getElementById('product-variants-section');
    let currentProductData = null; // Store fetched product data
    let selectedVariantsMap = {}; // Stores { groupName: optionValue, ... } for current selection from UI
    let currentCalculatedVariantDetails = { // Stores combined details for selected variant combination
        totalAvailableStock: 0,
        combinedPriceAdjustment: 0,
        combinedImageUrl: ''
    };


    if (!productId) {
        loadingMessage.style.display = 'none';
        errorMessage.textContent = 'Product ID not found in URL.';
        errorMessage.style.display = 'block';
        return;
    }

    // وظيفة لجلب تفاصيل المنتج
    async function fetchProductDetails(id) {
        loadingMessage.style.display = 'block';
        errorMessage.style.display = 'none';
        productDetailContent.style.display = 'none';
        relatedProductsSection.style.display = 'none';
        reviewsListContainer.innerHTML = '<p class="text-center text-muted mt-4">Loading reviews...</p>';

        try {
            const response = await fetch(`http://localhost:3000/api/products/${id}`);
            if (!response.ok) {
                let errorData = await response.json(); // Try to parse error data
                throw new Error(errorData.message || `Failed to fetch product details. Status: ${response.status}`);
            }
            const product = await response.json();

            if (!product) {
                throw new Error('Product not found or invalid ID.');
            }
            currentProductData = product; // Store product data globally

            // Populate static product info
            productName.textContent = product.name || 'N/A'; // Defensive check
            productShortDescription.textContent = (product.description && product.description.substring(0, 150) + '...') || 'No description available.'; // Defensive check
            productLongDescription.innerHTML = product.description || 'No description available.'; // Defensive check
            productCategory.textContent = product.category || 'Uncategorized'; // Defensive check

            if (productSpecsDisplay) productSpecsDisplay.innerHTML = (product.specifications || 'No specifications available.').replace(/\n/g, '<br>');
            // Using the corrected ID
            if (productShippingReturnsDisplay) productShippingReturnsDisplay.innerHTML = (product.shippingAndReturns || 'Standard shipping and returns information.').replace(/\n/g, '<br>');


            // ✅ NEW: Render variant selectors if variants exist
            if (product.variants && product.variants.length > 0) {
                productVariantsSection.style.display = 'block';
                renderVariantSelectors(product.variants);
                // Initialize selectedVariantsMap with default (first option of each group)
                product.variants.forEach(group => {
                    if (group.options && group.options.length > 0) {
                        selectedVariantsMap[group.name] = group.options[0].value;
                    }
                });
                updateProductDisplayBasedOnVariants(); // Initial display update based on default selections
            } else {
                // If no variants, display base product price and stock
                productVariantsSection.style.display = 'none'; // Hide variants section
                productMainImage.src = product.imageUrl || '/images/placeholder.jpg'; // Defensive check
                productPrice.textContent = `EGP${(product.price || 0).toFixed(2)}`; // Defensive check
                productStock.textContent = (product.stock > 0 ? product.stock : 'Out of Stock') || 'N/A'; // Defensive check
                quantityInput.max = product.stock || 0;
                if (product.stock === 0) {
                    addToCartDetailBtn.disabled = true;
                    addToCartDetailBtn.textContent = 'Out of Stock';
                    buyNowBtn.disabled = true;
                }
                updateQuantityButtons(parseInt(quantityInput.value), product.stock);
            }

            // Create thumbnail gallery - now includes variant images
            updateThumbnailGallery(product);

            // Activate zoom effect
            mainImageWrapper.addEventListener('mousemove', (e) => {
                const { left, top, width, height } = mainImageWrapper.getBoundingClientRect();
                const x = (e.clientX - left) / width * 100;
                const y = (e.clientY - top) / height * 100;
                productMainImage.style.transformOrigin = `${x}% ${y}%`;
            });
            mainImageWrapper.addEventListener('mouseenter', () => {
                productMainImage.style.transform = 'scale(1.5)';
            });
            mainImageWrapper.addEventListener('mouseleave', () => {
                productMainImage.style.transform = 'scale(1)';
                productMainImage.style.transformOrigin = 'center center';
            });


            loadingMessage.style.display = 'none';
            productDetailContent.style.display = 'flex';

            fetchRelatedProducts(productId);
            fetchAndDisplayReviews(productId);
            checkWishlistStatus(productId);
            // updateQuantityButtons is called by updateProductDisplayBasedOnVariants now

            // Social share buttons
            const productShareUrl = window.location.href;
            const productShareText = `Check out this amazing product: ${product.name || 'Product'} at The Light & Wire Store!`; // Defensive check for name

            if (shareFacebookBtn) {
                shareFacebookBtn.onclick = () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(productShareUrl)}`, '_blank');
            }
            if (shareTwitterBtn) {
                shareTwitterBtn.onclick = () => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(productShareUrl)}&text=${encodeURIComponent(productShareText)}`, '_blank');
            }
            if (shareWhatsappBtn) {
                shareWhatsappBtn.onclick = () => window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(productShareText + ' ' + productShareUrl)}`, '_blank');
            }
        } catch (error) {
            console.error('Error fetching product details:', error);
            loadingMessage.style.display = 'none';
            errorMessage.textContent = `Error: ${error.message}`;
            errorMessage.style.display = 'block';
            window.showToast(`Failed to load product: ${error.message}`, 'danger');
        }
    }

    // ✅ NEW: Function to render variant selectors
    function renderVariantSelectors(variants) {
        productVariantsSection.innerHTML = ''; // Clear previous selectors

        variants.forEach((group, index) => {
            if (!group.options || group.options.length === 0) return; // Skip empty groups

            const variantGroupDiv = document.createElement('div');
            variantGroupDiv.classList.add('mb-3');
            variantGroupDiv.innerHTML = `
                <label for="variant-select-${index}" class="form-label me-3 fw-bold fs-5">${group.name}:</label>
                <select class="form-select variant-select" id="variant-select-${index}" data-group-name="${group.name}">
                    ${group.options.map(option => `<option value="${option.value}">${option.value}</option>`).join('')}
                </select>
            `;
            productVariantsSection.appendChild(variantGroupDiv);

            // Add event listener to each variant selector
            const selectElement = variantGroupDiv.querySelector('.variant-select');
            selectElement.addEventListener('change', updateProductDisplayBasedOnVariants);

            // Set default selected value for each dropdown
            if (selectedVariantsMap[group.name]) {
                selectElement.value = selectedVariantsMap[group.name];
            } else if (group.options.length > 0) {
                selectedVariantsMap[group.name] = group.options[0].value; // Default to first option
            }
        });
    }

    // ✅ NEW: Function to update product display based on selected variants
    function updateProductDisplayBasedOnVariants() {
        // Update selectedVariantsMap object from all selectors
        productVariantsSection.querySelectorAll('.variant-select').forEach(select => {
            selectedVariantsMap[select.dataset.groupName] = select.value;
        });

        // Calculate combined properties for the selected variant combination
        currentCalculatedVariantDetails.totalAvailableStock = Infinity;
        currentCalculatedVariantDetails.combinedPriceAdjustment = 0;
        currentCalculatedVariantDetails.combinedImageUrl = currentProductData.imageUrl; // Default to main product image

        let allSelectionsAreValid = true;

        const selectedVariantOptionObjects = []; // Array to hold actual option objects for calculating total stock/price/image

        // Iterate through each variant group defined in the product
        for (const group of currentProductData.variants) {
            const selectedOptionValueForGroup = selectedVariantsMap[group.name];
            if (selectedOptionValueForGroup) {
                const foundOption = group.options.find(option => option.value === selectedOptionValueForGroup);
                if (foundOption) {
                    selectedVariantOptionObjects.push(foundOption); // Add the found option object
                    // Update combination properties
                    currentCalculatedVariantDetails.totalAvailableStock = Math.min(currentCalculatedVariantDetails.totalAvailableStock, foundOption.stock);
                    currentCalculatedVariantDetails.combinedPriceAdjustment += foundOption.priceAdjustment;
                    if (foundOption.imageUrl) {
                        currentCalculatedVariantDetails.combinedImageUrl = foundOption.imageUrl; // Prioritize variant specific image
                    }
                } else {
                    allSelectionsAreValid = false; // A selected option value was not found in product data
                    break;
                }
            } else {
                allSelectionsAreValid = false; // A variant group was not selected
                break;
            }
        }

        if (allSelectionsAreValid && currentProductData.variants.length > 0) {
            // Update image based on combined variant image
            productMainImage.src = currentCalculatedVariantDetails.combinedImageUrl || currentProductData.imageUrl || '/images/placeholder.jpg'; // More defensive
            // Update thumbnail active state
            updateThumbnailActiveState(currentCalculatedVariantDetails.combinedImageUrl);

            // Update price
            const newPrice = currentProductData.price + currentCalculatedVariantDetails.combinedPriceAdjustment;
            productPrice.textContent = `EGP${newPrice.toFixed(2)}`;

            // Update stock
            productStock.textContent = currentCalculatedVariantDetails.totalAvailableStock > 0 ? currentCalculatedVariantDetails.totalAvailableStock : 'Out of Stock';
            quantityInput.max = currentCalculatedVariantDetails.totalAvailableStock;

            // Enable/disable add to cart/buy now buttons based on variant stock
            const isAvailable = currentCalculatedVariantDetails.totalAvailableStock > 0;
            addToCartDetailBtn.disabled = !isAvailable;
            addToCartDetailBtn.innerHTML = isAvailable ? '<i class="fas fa-cart-plus me-2"></i> Add to Cart' : 'Out of Stock';
            buyNowBtn.disabled = !isAvailable;

        } else {
            // Fallback to base product info if no variants or invalid selection
            productMainImage.src = currentProductData.imageUrl || '/images/placeholder.jpg'; // Defensive
            updateThumbnailActiveState(currentProductData.imageUrl);
            productPrice.textContent = `EGP${(currentProductData.price || 0).toFixed(2)}`; // Defensive
            productStock.textContent = (currentProductData.stock > 0 ? currentProductData.stock : 'Out of Stock') || 'N/A'; // Defensive
            quantityInput.max = currentProductData.stock || 0;
            
            const isAvailable = currentProductData.stock > 0;
            addToCartDetailBtn.disabled = !isAvailable;
            addToCartDetailBtn.innerHTML = isAvailable ? '<i class="fas fa-cart-plus me-2"></i> Add to Cart' : 'Out of Stock';
            buyNowBtn.disabled = !isAvailable;
            
            // If variants exist but selection is incomplete/invalid, show warning
            if (currentProductData.variants && currentProductData.variants.length > 0) {
                window.showToast('Please select all variant options.', 'warning');
            }
        }

        // Ensure quantity input value doesn't exceed new max stock
        let currentQuantity = parseInt(quantityInput.value);
        let maxStock = parseInt(quantityInput.max);

        if (isNaN(currentQuantity) || currentQuantity <= 0) {
            currentQuantity = 1;
        }
        if (currentQuantity > maxStock) {
            currentQuantity = maxStock > 0 ? maxStock : 1; // Default to 1 if max is 0
        }
        if (maxStock === 0) {
            currentQuantity = 0;
        }
        quantityInput.value = currentQuantity;
        updateQuantityButtons(currentQuantity, maxStock);
    }

    // Helper to update active thumbnail
    function updateThumbnailActiveState(imageUrl) {
        thumbnailGallery.querySelectorAll('.thumbnail-image').forEach(img => img.classList.remove('active-thumbnail'));
        const matchingThumb = thumbnailGallery.querySelector(`img[src="${imageUrl}"]`);
        if (matchingThumb) {
            matchingThumb.classList.add('active-thumbnail');
        }
    }

    // Helper to regenerate thumbnail gallery (called initially and maybe on variant image change)
    function updateThumbnailGallery(product) {
        thumbnailGallery.innerHTML = '';
        const allImageUrls = [product.imageUrl || '/images/placeholder.jpg', ...(product.imageUrls || [])]; // Defensive for product.imageUrl
        // Add variant images to thumbnails if present
        product.variants.forEach(group => {
            group.options.forEach(option => {
                if (option.imageUrl && !allImageUrls.includes(option.imageUrl)) {
                    allImageUrls.push(option.imageUrl);
                }
            });
        });

        allImageUrls.forEach(url => {
            const thumbImg = document.createElement('img');
            thumbImg.src = url;
            thumbImg.alt = product.name || 'Product Image'; // Defensive for product.name
            thumbImg.classList.add('img-fluid', 'rounded', 'thumbnail-image');
            // Do not set active here, it's handled by updateProductDisplayBasedOnVariants
            thumbImg.addEventListener('click', () => {
                productMainImage.src = url;
                // Keep active thumbnail logic here
                thumbnailGallery.querySelectorAll('.thumbnail-image').forEach(img => img.classList.remove('active-thumbnail'));
                thumbImg.classList.add('active-thumbnail');
                // IMPORTANT: If clicking on a variant thumbnail, this should trigger variant selection.
                // Or, if just showing images, then it's fine.
                // For now, it just changes main image.
            });
            thumbnailGallery.appendChild(thumbImg);
        });
        // Set initial active state based on main product image (or default variant image)
        updateThumbnailActiveState(currentProductData.imageUrl || '/images/placeholder.jpg'); // Defensive
    }

    // ✅ MODIFIED: Helper function to get the currently selected variant combination as an array
    //             Now uses 'name' and 'value' as per Cart.js schema
    function getSelectedVariantsAsArray() {
        const selected = [];
        for (const groupName in selectedVariantsMap) {
            selected.push({
                name: groupName,    // ✅ تم التعديل ليطابق "name" في السكيما
                value: selectedVariantsMap[groupName] // ✅ تم التعديل ليطابق "value" في السكيما
            });
        }
        // التأكد من ترتيب ثابت للمقارنة في الواجهة الخلفية (اختياري لكن ممارسة جيدة)
        return selected.sort((a, b) => a.name.localeCompare(b.name) || a.value.localeCompare(b.value));
    }

    // Update quantity buttons (min/max)
    function updateQuantityButtons(currentQty, maxQty) {
        quantityInput.value = currentQty;
        quantityInput.min = maxQty > 0 ? 1 : 0; // Minimum 1 if stock available, else 0
        quantityInput.max = maxQty;

        decreaseQuantityBtn.disabled = currentQty <= (maxQty > 0 ? 1 : 0);
        increaseQuantityBtn.disabled = currentQty >= maxQty;

        if (maxQty === 0) {
            quantityInput.value = 0;
            decreaseQuantityBtn.disabled = true;
            increaseQuantityBtn.disabled = true;
        }
    }


    decreaseQuantityBtn.addEventListener('click', () => {
        let currentValue = parseInt(quantityInput.value);
        if (currentValue > parseInt(quantityInput.min)) {
            quantityInput.value = currentValue - 1;
            updateQuantityButtons(parseInt(quantityInput.value), parseInt(quantityInput.max));
        }
    });

    increaseQuantityBtn.addEventListener('click', () => {
        let currentValue = parseInt(quantityInput.value);
        if (currentValue < parseInt(quantityInput.max)) {
            quantityInput.value = currentValue + 1;
            updateQuantityButtons(parseInt(quantityInput.value), parseInt(quantityInput.max));
        }
    });

    quantityInput.addEventListener('change', () => {
        let currentValue = parseInt(quantityInput.value);
        let maxAllowed = parseInt(quantityInput.max);
        let minAllowed = parseInt(quantityInput.min);

        if (isNaN(currentValue) || currentValue < minAllowed) {
            quantityInput.value = minAllowed;
        } else if (currentValue > maxAllowed) {
            quantityInput.value = maxAllowed;
        }
        updateQuantityButtons(parseInt(quantityInput.value), parseInt(quantityInput.max));
    });

    // Add to cart functionality
    addToCartDetailBtn.addEventListener('click', async () => {
        const quantity = parseInt(quantityInput.value);
        if (quantity <= 0 || isNaN(quantity)) {
            window.showToast('Please enter a valid quantity.', 'warning');
            return;
        }

        if (currentProductData.variants && currentProductData.variants.length > 0) {
            const selected = getSelectedVariantsAsArray();
            if (selected.length !== currentProductData.variants.length) {
                window.showToast('Please select all variant options before adding to cart.', 'warning');
                return;
            }
            // Pass the selectedVariants array
            await window.addToCart(currentProductData._id, quantity, selected);
        } else {
            // No variants, pass null for selectedVariants
            await window.addToCart(currentProductData._id, quantity, null);
        }
    });

    // Buy now functionality
    buyNowBtn.addEventListener('click', async () => {
        const quantity = parseInt(quantityInput.value);
        if (quantity <= 0 || isNaN(quantity)) {
            window.showToast('Please enter a valid quantity.', 'warning');
            return;
        }

        if (currentProductData.variants && currentProductData.variants.length > 0) {
            const selected = getSelectedVariantsAsArray();
            if (selected.length !== currentProductData.variants.length) {
                window.showToast('Please select all variant options before buying.', 'warning');
                return;
            }
            // For "Buy Now", we usually add to cart and then redirect to checkout
            await window.addToCart(currentProductData._id, quantity, selected);
        } else {
            await window.addToCart(currentProductData._id, quantity, null);
        }
        // Redirect to checkout after adding to cart
        setTimeout(() => {
            window.location.href = 'checkout.html';
        }, 500);
    });

    // Wishlist functionality
    // (Existing code for wishlist, ensure it doesn't break with variants)
    async function checkWishlistStatus(prodId) {
        // ✅ MODIFIED: Use window.isLoggedIn() instead of window.isAuthenticated()
        if (!window.isLoggedIn()) {
            addToWishlistBtn.style.display = 'none';
            return;
        }
        addToWishlistBtn.style.display = 'inline-block'; // Show if authenticated
        try {
            const response = await fetch(`http://localhost:3000/api/wishlist`, { // Changed to GET all wishlist items
                headers: window.getAuthHeaders()
            });
            if (!response.ok) {
                throw new Error('Failed to fetch wishlist.');
            }
            const wishlistItems = await response.json();
            const inWishlist = wishlistItems.some(item => item._id === prodId); // Check if product ID is in wishlist

            if (inWishlist) {
                addToWishlistBtn.innerHTML = '<i class="fas fa-heart"></i> Remove from Wishlist';
                addToWishlistBtn.classList.add('btn-danger');
                addToWishlistBtn.classList.remove('btn-outline-primary');
                addToWishlistBtn.dataset.inWishlist = 'true';
            } else {
                addToWishlistBtn.innerHTML = '<i class="far fa-heart"></i> Add to Wishlist';
                addToWishlistBtn.classList.add('btn-outline-primary');
                addToWishlistBtn.classList.remove('btn-danger');
                addToWishlistBtn.dataset.inWishlist = 'false';
            }
        } catch (error) {
            console.error('Error checking wishlist status:', error);
            window.showToast('Failed to check wishlist status.', 'danger');
        }
    }

    if (addToWishlistBtn) {
        addToWishlistBtn.addEventListener('click', async () => {
            // ✅ MODIFIED: Use window.isLoggedIn() instead of window.isAuthenticated()
            if (!window.isLoggedIn()) {
                window.showToast('Please log in to manage your wishlist.', 'info');
                return;
            }
            try {
                const isCurrentlyInWishlist = addToWishlistBtn.dataset.inWishlist === 'true';
                let response;

                if (isCurrentlyInWishlist) {
                    response = await fetch(`http://localhost:3000/api/wishlist/${productId}`, { // Correct DELETE route
                        method: 'DELETE',
                        headers: window.getAuthHeaders()
                    });
                } else {
                    response = await fetch('http://localhost:3000/api/wishlist', {
                        method: 'POST',
                        headers: { ...window.getAuthHeaders(), 'Content-Type': 'application/json' },
                        body: JSON.stringify({ productId })
                    });
                }

                if (!response.ok) {
                    let errorData = { message: 'Failed to update wishlist due to unknown error.' };
                    try {
                        errorData = await response.json();
                    } catch (jsonError) {
                        console.error("Failed to parse JSON error response for update wishlist:", jsonError);
                    }
                    throw new Error(errorData.message || 'Failed to update wishlist.');
                }

                window.showToast(isCurrentlyInWishlist ? 'Removed from wishlist!' : 'Added to wishlist!', 'success');
                checkWishlistStatus(productId); // Re-check status after action
            } catch (error) {
                console.error('Error updating wishlist:', error);
                window.showToast(`Failed to update wishlist: ${error.message}`, 'danger');
            }
        });
    }


    // Reviews functionality
    ratingInput.addEventListener('click', (event) => {
        let rating = 0;
        const clickedStar = event.target.closest('.fa-star');
        if (clickedStar) {
            rating = parseInt(clickedStar.dataset.rating);
        }
        selectedRatingInput.value = rating;
        ratingInput.querySelectorAll('.fa-star').forEach(star => {
            const starRating = parseInt(star.dataset.rating);
            if (starRating <= rating) {
                star.classList.remove('far');
                star.classList.add('fas');
            } else {
                star.classList.remove('fas');
                star.classList.add('far');
            }
        });
    });

    addReviewForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        // ✅ MODIFIED: Use window.isLoggedIn() instead of window.isAuthenticated()
        if (!window.isLoggedIn()) {
            reviewFormMessage.textContent = 'Please log in to submit a review.';
            reviewFormMessage.className = 'alert alert-warning';
            reviewFormMessage.style.display = 'block';
            return;
        }

        const rating = parseInt(selectedRatingInput.value);
        const comment = commentInput.value.trim();

        if (rating === 0) {
            reviewFormMessage.textContent = 'Please select a rating.';
            reviewFormMessage.className = 'alert alert-warning';
            reviewFormMessage.style.display = 'block';
            return;
        }

        try {
            const response = await fetch(`http://localhost:3000/api/reviews`, { // Changed to POST /api/reviews
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    ...window.getAuthHeaders()
                },
                body: JSON.stringify({ productId, rating, comment })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Failed to submit review.');
            }

            reviewFormMessage.textContent = data.message || 'Review submitted successfully! It will be visible after approval.';
            reviewFormMessage.className = 'alert alert-success';
            reviewFormMessage.style.display = 'block';

            // Clear form
            selectedRatingInput.value = 0;
            commentInput.value = '';
            ratingInput.querySelectorAll('.fa-star').forEach(star => {
                star.classList.remove('fas');
                star.classList.add('far');
            });

            // Re-fetch reviews to update the list (reviews will only show if approved)
            fetchAndDisplayReviews(productId);

        } catch (error) {
            console.error('Error submitting review:', error);
            reviewFormMessage.textContent = `Error: ${error.message}`;
            reviewFormMessage.className = 'alert alert-danger';
            reviewFormMessage.style.display = 'block';
        }
    });

    async function fetchAndDisplayReviews(prodId) {
        try {
            const response = await fetch(`http://localhost:3000/api/reviews/product/${prodId}`);
            if (!response.ok) {
                throw new Error('Failed to fetch reviews.');
            }
            const data = await response.json();
            const reviews = data.reviews;
            const averageRating = data.averageRating;
            const totalReviews = data.totalReviews;

            // Update rating summary
            avgStarsSpan.innerHTML = renderStars(averageRating);
            reviewsCountSpan.textContent = ` (${totalReviews} Reviews)`;

            reviewsListContainer.innerHTML = ''; // Clear previous reviews

            if (reviews.length === 0) {
                reviewsListContainer.innerHTML = '<p class="text-center text-muted mt-4">No reviews yet. Be the first to review this product!</p>';
                return;
            }

            reviews.forEach(review => {
                const reviewCard = document.createElement('div');
                reviewCard.classList.add('card', 'mb-3', 'shadow-sm', 'review-card');
                reviewCard.innerHTML = `
                    <div class="card-body">
                        <h5 class="card-title">${review.userId.name}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">${new Date(review.createdAt).toLocaleDateString()}</h6>
                        <div class="rating-stars">${renderStars(review.rating)}</div>
                        <p class="card-text">${review.comment}</p>
                    </div>
                `;
                reviewsListContainer.appendChild(reviewCard);
            });

        } catch (error) {
            console.error('Error fetching and displaying reviews:', error);
            reviewsListContainer.innerHTML = `<p class="text-center text-danger mt-4">Failed to load reviews: ${error.message}</p>`;
        }
    }

    function renderStars(rating) {
        let starsHtml = '';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                starsHtml += '<i class="fas fa-star text-warning"></i>'; // Filled star
            } else if (i - 0.5 === rating) {
                 starsHtml += '<i class="fas fa-star-half-alt text-warning"></i>'; // Half star
            }
            else {
                starsHtml += '<i class="far fa-star text-warning"></i>'; // Empty star
            }
        }
        return starsHtml;
    }

    // Related Products functionality
    async function fetchRelatedProducts(currentProductId) {
        relatedProductsContainer.innerHTML = '<div class="col-12 text-center text-muted">Loading related products...</div>';
        // ✅ NEW: Add defensive check for currentProductData being null/undefined before accessing its properties
        if (!currentProductData) {
            console.warn('Cannot fetch related products: currentProductData is null or undefined.');
            relatedProductsContainer.innerHTML = '<div class="col-12 text-center text-muted">Product data not loaded for related products.</div>';
            relatedProductsSection.style.display = 'block';
            return;
        }

        try {
            // ✅ MODIFIED: Add more robust defensive check for currentProductData and its category
            let category = '';
            if (!currentProductData.category || typeof currentProductData.category !== 'string' || currentProductData.category.length === 0) {
                console.warn('Cannot fetch related products: currentProductData.category is invalid, undefined, or empty.');
                relatedProductsContainer.innerHTML = '<div class="col-12 text-center text-muted">Category not available for related products.</div>';
                relatedProductsSection.style.display = 'block';
                return; // Exit if category is not valid or empty
            }
            category = currentProductData.category;


            const response = await fetch(`http://localhost:3000/api/products?limit=4&exclude=${currentProductId}&category=${category}`);
            if (!response.ok) {
                throw new Error('Failed to fetch related products.');
            }
            const data = await response.json();
            const products = data.products;

            relatedProductsContainer.innerHTML = ''; // Clear loading message

            if (products.length === 0) {
                relatedProductsContainer.innerHTML = '<div class="col-12 text-center text-muted">No related products found.</div>';
                return;
            }

            products.forEach(product => {
                const productCol = document.createElement('div');
                productCol.classList.add('col');
                // ✅ NEW: Add defensive checks for product properties before rendering
                const productNameHtml = product.name || 'Unknown Product';
                const productImageUrl = product.imageUrl || '/images/placeholder.jpg';
                const productPriceHtml = (product.price !== undefined && product.price !== null) ? product.price.toFixed(2) : 'N/A';


                productCol.innerHTML = `
                    <div class="card product-card h-100 shadow-sm">
                        <img src="${productImageUrl}" class="card-img-top product-card-image" alt="${productNameHtml}">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-truncate">${productNameHtml}</h5>
                            <p class="card-text text-primary fw-bold mb-auto">EGP${productPriceHtml}</p>
                            <a href="product-detail.html?id=${product._id}" class="btn btn-primary btn-sm mt-3">View Details</a>
                        </div>
                    </div>
                `;
                relatedProductsContainer.appendChild(productCol);
            });

            relatedProductsSection.style.display = 'block'; // Show section if products found

        } catch (error) {
            console.error('Error fetching related products:', error);
            relatedProductsContainer.innerHTML = `<div class="col-12 text-center text-danger">Failed to load related products: ${error.message}</div>`;
        }
    }

    // استدعاء جلب تفاصيل المنتج عند تحميل الصفحة
    fetchProductDetails(productId);
});