document.addEventListener('DOMContentLoaded', async () => {
    const wishlistItemsContainer = document.getElementById('wishlist-items-container');

    // Redirect to login if user is not logged in
    if (!window.isLoggedIn()) {
        window.showToast('Please log in to view your wishlist.', 'info');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        return;
    }

    // Function to fetch and display wishlist items
    async function fetchWishlist() {
        wishlistItemsContainer.innerHTML = '<p class="text-center text-muted py-5">Loading your wishlist...</p>';

        try {
            const response = await fetch('http://localhost:3000/api/wishlist', {
                headers: window.getAuthHeaders()
            });

            if (!response.ok) {
                let errorData = { message: 'Failed to fetch wishlist due to unknown error.' };
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    console.error("Failed to parse JSON error response for wishlist fetch:", jsonError);
                }
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            const wishlist = await response.json();
            displayWishlist(wishlist);

        } catch (error) {
            console.error('Error fetching wishlist:', error);
            wishlistItemsContainer.innerHTML = `<p class="text-center text-danger py-5">Failed to load wishlist: ${error.message}</p>`;
            window.showToast(`Failed to load wishlist: ${error.message}`, 'danger');
        }
    }

    // Function to display wishlist items in the HTML
    function displayWishlist(wishlist) {
        wishlistItemsContainer.innerHTML = '';

        if (!wishlist || wishlist.length === 0) {
            wishlistItemsContainer.innerHTML = `
                <div class="text-center py-5">
                    <i class="far fa-heart fa-5x text-muted mb-3"></i>
                    <p class="fs-4 text-muted">Your wishlist is empty.</p>
                    <a href="index.html" class="btn btn-primary btn-lg mt-3"><i class="fas fa-shopping-bag me-2"></i>Start Shopping</a>
                </div>
            `;
            return;
        }

        wishlist.forEach(product => {
            const itemDiv = document.createElement('div');
            itemDiv.classList.add('wishlist-item', 'd-flex', 'align-items-center', 'py-3', 'border-bottom');
            itemDiv.dataset.productId = product._id;

            itemDiv.innerHTML = `
                <div class="flex-shrink-0 me-3">
                    <img src="${product.imageUrl}" alt="${product.name}" class="rounded cart-item-image">
                </div>
                <div class="flex-grow-1">
                    <h5 class="mb-1 text-primary"><a href="product-detail.html?id=${product._id}" class="text-decoration-none text-primary">${product.name}</a></h5>
                    <p class="text-muted mb-0">${product.category}</p>
                    <p class="fw-bold mb-0">Price: EGP${product.price.toFixed(2)}</p>
                </div>
                <div class="d-flex align-items-center">
                    <button class="btn btn-success btn-sm add-to-cart-from-wishlist-btn" data-product-id="${product._id}" data-product-name="${product.name}">
                        <i class="fas fa-cart-plus"></i> Add to Cart
                    </button>
                    <button class="btn btn-danger btn-sm remove-from-wishlist-btn ms-2" data-product-id="${product._id}">
                        <i class="fas fa-trash-alt"></i> Remove
                    </button>
                </div>
            `;
            wishlistItemsContainer.appendChild(itemDiv);
        });

        // Add event listeners for buttons
        wishlistItemsContainer.querySelectorAll('.add-to-cart-from-wishlist-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const productId = event.target.dataset.productId;
                const productName = event.target.dataset.productName;
                await addToCart(productId, 1, productName);
            });
        });

        wishlistItemsContainer.querySelectorAll('.remove-from-wishlist-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const productId = event.target.dataset.productId;
                await removeProductFromWishlist(productId);
            });
        });
    }

    // Function to add item to cart (re-used from main.js principles)
    async function addToCart(productId, quantity, productName) {
        if (!window.isLoggedIn()) {
            window.showToast('Please log in to add items to your cart.', 'info');
            setTimeout(() => { window.location.href = 'login.html'; }, 1500);
            return;
        }

        try {
            const response = await fetch('http://localhost:3000/api/cart/add', {
                method: 'POST',
                // ✅ إضافة Content-Type هنا
                headers: { ...window.getAuthHeaders(), 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId, quantity })
            });

            if (!response.ok) {
                let errorData = { message: 'Failed to add item to cart due to unknown error.' };
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    console.error("Failed to parse JSON error response for add to cart:", jsonError);
                }
                throw new Error(errorData.message || `Failed to add ${productName} to cart.`);
            }

            const result = await response.json();
            window.showToast(`${productName} added to cart!`, 'success');
            
            if (typeof window.updateCartCount === 'function') {
                window.updateCartCount();
            } else {
                console.warn("window.updateCartCount is not defined. Cart count might not update.");
            }
            if (typeof window.openMiniCart === 'function') {
                 window.openMiniCart();
            } else {
                console.warn("window.openMiniCart is not defined. Mini cart might not open.");
            }


        } catch (error) {
            console.error('Error adding to cart from wishlist:', error);
            window.showToast(`Failed to add ${productName} to cart: ${error.message}`, 'danger');
        }
    }

    // Function to remove item from wishlist
    async function removeProductFromWishlist(productId) {
        if (!window.confirm('Are you sure you want to remove this item from your wishlist?')) return;

        try {
            const response = await fetch(`http://localhost:3000/api/wishlist/${productId}`, {
                method: 'DELETE',
                headers: window.getAuthHeaders() // DELETE requests usually don't need Content-Type for body, as no body is sent
            });

            if (!response.ok) {
                let errorData = { message: 'Failed to remove item from wishlist due to unknown error.' };
                try {
                    errorData = await response.json();
                } catch (jsonError) {
                    console.error("Failed to parse JSON error response for remove from wishlist:", jsonError);
                }
                throw new Error(errorData.message || 'Failed to remove item from wishlist.');
            }

            window.showToast('Item removed from wishlist!', 'success');
            fetchWishlist();
            if (window.checkWishlistStatus) {
                 const currentProductId = new URLSearchParams(window.location.search).get('id');
                 if (currentProductId === productId) {
                    window.checkWishlistStatus(productId);
                 }
            }

        } catch (error) {
            console.error('Error removing from wishlist:', error);
            window.showToast(`Failed to remove item: ${error.message}`, 'danger');
        }
    }

    // Initial fetch of wishlist items when the page loads
    fetchWishlist();
});