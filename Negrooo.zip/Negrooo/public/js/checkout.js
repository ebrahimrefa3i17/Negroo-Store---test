// public/js/checkout.js
// Removed imports: All shared functions are now global via window.
// import { clearCart, getCartItems, loadCart, saveGuestCart } from './cart.js';
// import { showToast } = './toast.js';

document.addEventListener('DOMContentLoaded', async () => {
    const orderSummaryDiv = document.getElementById('order-summary');
    const orderTotalSpan = document.getElementById('order-total');
    const placeOrderBtn = document.getElementById('place-order-btn');
    const shippingForm = document.getElementById('shipping-form');
    const paymentMethodRadios = document.querySelectorAll('input[name="paymentMethod"]');
    const paymobFieldsDiv = document.getElementById('paymob-payment-fields');

    let currentCartItems = [];
    let paymobRedirectUrl = null;
    let appliedCouponData = null; // NEW: Store applied coupon data


    // Pre-fill user's email and shipping address if logged in
    const currentUser = window.getCurrentUser();
    if (window.isLoggedIn() && currentUser) {
        const emailInput = document.getElementById('email');
        if (emailInput) {
            emailInput.value = currentUser.email || '';
            emailInput.readOnly = true;
        }
        if (currentUser.shippingAddress) {
            document.getElementById('fullName').value = currentUser.shippingAddress.fullName || '';
            document.getElementById('phone').value = currentUser.shippingAddress.phone || '';
            document.getElementById('addressLine1').value = currentUser.shippingAddress.addressLine1 || '';
            document.getElementById('city').value = currentUser.shippingAddress.city || '';
            document.getElementById('country').value = currentUser.shippingAddress.country || 'Egypt';
        }
    } else {
        const emailInput = document.getElementById('email');
        if (emailInput) {
            emailInput.readOnly = false;
        }
    }

    // Function to fetch cart contents and display order summary
    async function fetchCartAndDisplaySummary() {
        orderSummaryDiv.innerHTML = '<p class="text-center text-muted py-3">Loading cart items...</p>';
        placeOrderBtn.disabled = true;

        try {
            if (window.isLoggedIn()) {
                const response = await fetch('http://localhost:3000/api/cart', {
                    headers: window.getAuthHeaders()
                });
                if (!response.ok) {
                    let errorData = { message: 'Failed to fetch cart for checkout due to unknown error.' };
                    try {
                        errorData = await response.json();
                    } catch (jsonError) {
                        console.error("Failed to parse JSON error response for cart fetch:", jsonError);
                    }
                    throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
                }
                const cart = await response.json();
                currentCartItems = cart.items;
            } else {
                currentCartItems = window.getCartItems(); // Corrected: use window.getCartItems()
            }

            orderSummaryDiv.innerHTML = '';
            let subtotal = 0; // Renamed for clarity with discounts
            let discountAmount = 0;

            if (!currentCartItems || currentCartItems.length === 0) {
                orderSummaryDiv.innerHTML = `
                    <div class="text-center py-5">
                        <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
                        <p class="fs-5 text-muted">Your cart is empty. Please add items before checking out.</p>
                        <a href="index.html" class="btn btn-primary mt-3"><i class="fas fa-shopping-bag me-2"></i>Start Shopping</a>
                    </div>
                `;
                placeOrderBtn.disabled = true;
                orderTotalSpan.textContent = 'EGP 0.00';
                return;
            } else {
                placeOrderBtn.disabled = false;
            }

            currentCartItems.forEach(item => {
                // Use the denormalized fields from the cart item, which should include variant adjustments
                // For logged-in users, item.productId is populated. For guests, item itself is the product data.
                const productData = item.productId && typeof item.productId === 'object' ? item.productId : item;

                // Use denormalized name, price, and imageUrl directly from the item, as they are already variant-adjusted
                const productName = item.name;
                const itemDisplayPrice = item.price;
                const itemDisplayImage = item.imageUrl;
                const productId = productData._id || item.productId; // productId is still used for linking if needed

                const itemTotal = itemDisplayPrice * item.quantity;
                subtotal += itemTotal; // Sum to subtotal

                // Build variant display string using 'name' and 'value' as per Cart.js schema
                const variantDisplay = item.selectedVariants && item.selectedVariants.length > 0
                    ? ` (${item.selectedVariants.map(v => `${v.name}: ${v.value}`).join(', ')})` // ✅ MODIFIED: Use v.name and v.value
                    : '';

                const itemDiv = document.createElement('div');
                itemDiv.classList.add('order-summary-item-detail', 'd-flex', 'align-items-center', 'mb-2', 'py-2');
                itemDiv.innerHTML = `
                    <div class="flex-shrink-0 me-3">
                        <img src="${itemDisplayImage || '/images/placeholder.jpg'}" alt="${productName}${variantDisplay}" class="rounded checkout-item-image">
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-0 text-dark">${productName}${variantDisplay}</h6>
                        <small class="text-muted">${item.quantity} x EGP${itemDisplayPrice.toFixed(2)}</small>
                    </div>
                    <div class="fw-bold">EGP${itemTotal.toFixed(2)}</div>
                `;
                orderSummaryDiv.appendChild(itemDiv);
            });

            // NEW: Apply coupon logic for checkout summary
            appliedCouponData = JSON.parse(localStorage.getItem('appliedCoupon') || 'null');
            if (appliedCouponData && subtotal >= appliedCouponData.minOrderAmount) {
                if (appliedCouponData.discountType === 'percentage') {
                    discountAmount = subtotal * (appliedCouponData.discountValue / 100);
                    if (appliedCouponData.maxDiscountAmount && discountAmount > appliedCouponData.maxDiscountAmount) {
                        discountAmount = appliedCouponData.maxDiscountAmount;
                    }
                } else if (appliedCouponData.discountType === 'fixed_amount') {
                    discountAmount = appliedCouponData.discountValue;
                }
                if (discountAmount > subtotal) discountAmount = subtotal; // Discount cannot exceed subtotal

                const discountDiv = document.createElement('div');
                discountDiv.classList.add('d-flex', 'justify-content-between', 'fs-6', 'fw-bold', 'text-success', 'mt-2', 'py-2', 'border-top');
                discountDiv.innerHTML = `
                    <span>Coupon Discount (${appliedCouponData.code}):</span>
                    <span>-EGP${discountAmount.toFixed(2)}</span>
                `;
                orderSummaryDiv.appendChild(discountDiv);
            } else {
                appliedCouponData = null; // Invalidate coupon if conditions not met
                localStorage.removeItem('appliedCoupon');
            }

            const finalTotal = subtotal - discountAmount;
            orderTotalSpan.textContent = `EGP${finalTotal.toFixed(2)}`;

            const selectedPaymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value;
            if (selectedPaymentMethod === 'Paymob Card') {
                await initiatePaymobPayment();
            }

            if (window.updateCartCount) {
                window.updateCartCount();
            }

        } catch (error) {
            console.error('Error fetching cart for checkout:', error);
            orderSummaryDiv.innerHTML = '<p class="text-center text-danger py-3">Failed to load cart summary. Please try again later.</p>';
            orderTotalSpan.textContent = 'EGP 0.00';
            placeOrderBtn.disabled = true;
            window.showToast(`Failed to load cart summary: ${error.message}`, 'danger');
        }
    }

    async function initiatePaymobPayment() {
        const totalAmount = parseFloat(orderTotalSpan.textContent.replace('EGP', ''));
        if (totalAmount <= 0) {
            window.showToast('Cart total must be greater than zero for online payment.', 'warning');
            placeOrderBtn.disabled = true;
            return;
        }

        const shippingAddress = {
            fullName: document.getElementById('fullName').value.trim(),
            email: document.getElementById('email').value.trim(),
            phone: document.getElementById('phone').value.trim(),
            addressLine1: document.getElementById('addressLine1').value.trim(),
            city: document.getElementById('city').value.trim(),
            country: document.getElementById('country').value.trim()
        };

        if (!shippingAddress.fullName || !shippingAddress.email || !shippingAddress.phone || !shippingAddress.addressLine1 || !shippingAddress.city || !shippingAddress.country) {
            window.showToast('Please fill in all shipping information fields before proceeding to payment.', 'warning');
            placeOrderBtn.disabled = true;
            return;
        }

        placeOrderBtn.disabled = true;
        placeOrderBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Redirecting to Paymob...';

        try {
            const orderDetailsToSend = {
                shippingAddress,
                paymentMethod: 'Paymob Card',
                items: currentCartItems.map(item => ({
                    productId: item.productId && item.productId._id ? item.productId._id : item.productId,
                    quantity: item.quantity,
                    // ✅ Pass selectedVariants, variantImageUrl, variantPriceAdjustment to backend
                    selectedVariants: item.selectedVariants || [],
                    variantImageUrl: item.imageUrl || '', // Use item.imageUrl which is already variant-adjusted
                    variantPriceAdjustment: item.variantPriceAdjustment || 0, // This is expected from Cart model
                    name: item.name, // Pass denormalized name
                    price: item.price // Pass denormalized price (variant-adjusted)
                })),
                // NEW: Include coupon data if applied
                coupon: appliedCouponData ? {
                    code: appliedCouponData.code,
                    discountType: appliedCouponData.discountType,
                    discountValue: appliedCouponData.discountValue,
                    minOrderAmount: appliedCouponData.minOrderAmount,
                    maxDiscountAmount: appliedCouponData.maxDiscountAmount
                } : undefined,
                totalAmount: totalAmount // Pass calculated total amount after discount
            };

            const response = await fetch('http://localhost:3000/api/orders/pay-with-paymob', {
                method: 'POST',
                headers: window.getAuthHeaders(),
                body: JSON.stringify(orderDetailsToSend) // Send full orderDetailsToSend
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Failed to initiate Paymob payment.');
            }

            paymobRedirectUrl = data.redirectUrl;
            window.showToast('Redirecting to secure payment page...', 'info');

            if (paymobFieldsDiv) {
                paymobFieldsDiv.innerHTML = `<iframe src="${paymobRedirectUrl}" style="width:100%; height:400px; border:none; margin-top:20px;"></iframe>`;
                paymobFieldsDiv.style.display = 'block';
                placeOrderBtn.style.display = 'none';
            } else {
                window.location.href = paymobRedirectUrl;
            }

        } catch (error) {
            console.error('Error initiating Paymob payment:', error);
            window.showToast(`Payment initiation failed: ${error.message}`, 'danger');
            placeOrderBtn.disabled = false;
            placeOrderBtn.innerHTML = 'Place Order <i class="fas fa-check-circle ms-2"></i>';
        }
    }


    paymentMethodRadios.forEach(radio => {
        radio.addEventListener('change', async (event) => {
            const selectedMethod = event.target.value;
            if (selectedMethod === 'Paymob Card') {
                if (paymobFieldsDiv) paymobFieldsDiv.style.display = 'block';
                await initiatePaymobPayment();
            } else {
                if (paymobFieldsDiv) paymobFieldsDiv.style.display = 'none';
                paymobFieldsDiv.innerHTML = '';
                paymobRedirectUrl = null;
                placeOrderBtn.innerHTML = 'Place Order <i class="fas fa-check-circle ms-2"></i>';
                placeOrderBtn.disabled = false;
                placeOrderBtn.style.display = 'block';
            }
        });
    });


    placeOrderBtn.addEventListener('click', async (event) => {
        event.preventDefault();

        const fullName = document.getElementById('fullName').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const addressLine1 = document.getElementById('addressLine1').value.trim();
        const city = document.getElementById('city').value.trim();
        const country = document.getElementById('country').value.trim();
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value;

        if (!fullName || !email || !phone || !addressLine1 || !city || !country) {
            window.showToast('Please fill in all shipping information fields.', 'warning');
            return;
        }
        if (currentCartItems.length === 0) {
            window.showToast('Your cart is empty. Please add items to your cart before placing an order.', 'warning');
            return;
        }
        if (!paymentMethod) {
            window.showToast('Please select a payment method.', 'warning');
            return;
        }

        const shippingAddress = {
            fullName,
            email,
            phone,
            addressLine1,
            city,
            country
        };

        if (paymentMethod === 'Paymob Card' && paymobRedirectUrl) {
            if (placeOrderBtn.style.display !== 'none') {
                 window.location.href = paymobRedirectUrl;
                 return;
            } else {
                window.showToast('Please complete your payment in the Paymob window/iframe.', 'info');
                return;
            }
        }

        placeOrderBtn.disabled = true;
        placeOrderBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Placing Order...';

        try {
            const orderData = {
                shippingAddress,
                items: currentCartItems.map(item => ({
                    productId: item.productId && item.productId._id ? item.productId._id : item.productId,
                    quantity: item.quantity,
                    // ✅ Pass selectedVariants, variantImageUrl, variantPriceAdjustment to backend
                    selectedVariants: item.selectedVariants || [],
                    variantImageUrl: item.imageUrl || '', // Use item.imageUrl which is already variant-adjusted
                    variantPriceAdjustment: item.variantPriceAdjustment || 0, // This is expected from Cart model
                    name: item.name, // Pass denormalized name
                    price: item.price // Pass denormalized price (variant-adjusted)
                })),
                paymentMethod,
                // NEW: Include coupon data if applied
                coupon: appliedCouponData ? {
                    code: appliedCouponData.code,
                    discountType: appliedCouponData.discountType,
                    discountValue: appliedCouponData.discountValue,
                    minOrderAmount: appliedCouponData.minOrderAmount,
                    maxDiscountAmount: appliedCouponData.maxDiscountAmount
                } : undefined,
                totalAmount: parseFloat(orderTotalSpan.textContent.replace('EGP', '')) // Final total after discount
            };

            const response = await fetch('http://localhost:3000/api/orders', {
                method: 'POST',
                headers: window.getAuthHeaders(),
                body: JSON.stringify(orderData)
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Order placement failed: Unknown error.');
            }

            window.showToast(data.message + ` Your Order ID: ${data.order._id}`, 'success');

            await window.clearCart(); // This will also clear appliedCoupon from localStorage

            if (window.updateCartCount) {
                window.updateCartCount();
            }

            setTimeout(() => {
                if (window.isLoggedIn()) {
                    window.location.href = `order-confirmation.html?orderId=${data.order._id}`;
                } else {
                    localStorage.setItem('guestOrderIdForConfirmation', data.order._id);
                    window.location.href = `order-confirmation.html?guest=true&orderId=${data.order._id}`;
                }
            }, 1500);

        } catch (error) {
            console.error('Order placement error:', error);
            window.showToast(`Order placement failed: ${error.message}`, 'danger');
            placeOrderBtn.disabled = false;
            placeOrderBtn.innerHTML = 'Place Order <i class="fas fa-check-circle ms-2"></i>';
        }
    });

    await window.loadCart(); // Ensure cart is loaded before initial display and use global loadCart

    fetchCartAndDisplaySummary(); // Initial fetch when checkout page loads
});