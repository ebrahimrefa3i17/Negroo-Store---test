document.addEventListener('DOMContentLoaded', async () => {
    const ordersListDiv = document.getElementById('orders-list');

    // Redirect to login if user is not logged in
    if (!window.isLoggedIn()) {
        window.showToast('Please log in to view your orders.', 'info');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        return;
    }

    // Function to fetch and display user's orders
    async function fetchMyOrders() {
        ordersListDiv.innerHTML = '<p class="empty-orders text-center text-muted py-5">Loading your orders...</p>';
        try {
            // ✅ هذا هو الكود المفقود الذي يجب إضافته
            const response = await fetch('http://localhost:3000/api/orders/my-orders', {
                headers: window.getAuthHeaders()
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to fetch orders.'); // تم التصحيح هنا
            }

            const orders = await response.json();
            displayOrders(orders);

        } catch (error) {
            console.error('Error fetching my orders:', error);
            ordersListDiv.innerHTML = `<p class="empty-orders text-center text-danger py-5">Failed to load orders: ${error.message}</p>`;
            window.showToast(`Failed to load orders: ${error.message}`, 'danger');
        }
    }

    // Function to display orders in the HTML
    function displayOrders(orders) {
        ordersListDiv.innerHTML = '';
        if (orders.length === 0) {
            ordersListDiv.innerHTML = `
                <div class="text-center py-5">
                    <i class="fas fa-box-open fa-5x text-muted mb-3"></i>
                    <p class="fs-4 text-muted">You have not placed any orders yet.</p>
                    <a href="index.html" class="btn btn-primary btn-lg mt-3"><i class="fas fa-shopping-bag me-2"></i>Start Shopping</a>
                </div>
            `;
            return;
        }

        orders.forEach(order => {
            const orderCard = document.createElement('div');
            orderCard.classList.add('order-card', 'mb-4', 'p-3', 'shadow-sm', 'bg-white');

            let itemsHtml = '';
            let totalItems = 0;
            // يجب التأكد من أن item.productId موجود وأنه كائن صالح
            // لأننا في الـ backend قمنا بتعليق populate، فإن item.productId سيكون مجرد ObjectId
            // لذلك، سنعتمد هنا على البيانات التي تم تخزينها مباشرة في Order model (name, price, imageUrl)
            // والتي أضفتها في Order.js (name, price, imageUrl في orderItemSchema)
            order.items.forEach(item => {
                // نستخدم item.name, item.imageUrl, item.price مباشرة لأنها مخزنة في OrderItemSchema
                itemsHtml += `
                    <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                        <span class="d-flex align-items-center">
                            <img src="${item.imageUrl}" alt="${item.name}" class="rounded me-2 my-order-item-image">
                            <a href="product-detail.html?id=${item.productId}" class="text-decoration-none text-dark">${item.name}</a> (x${item.quantity})
                        </span>
                        <span>EGP${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `;
                totalItems += item.quantity;
            });

            orderCard.innerHTML = `
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-primary mb-0">Order ID: <small class="text-muted fw-normal">${order._id}</small></h4>
                    <span class="status-badge status-${order.status}">${order.status}</span>
                </div>
                <p class="mb-1"><strong>Order Date:</strong> ${new Date(order.createdAt).toLocaleDateString()}</p>
                <p class="mb-3"><strong>Payment Method:</strong> ${order.paymentMethod}</p>
                
                <h5 class="mb-2 text-primary">Items in this Order (${totalItems} items):</h5>
                <div class="mb-3">
                    ${itemsHtml}
                </div>
                
                <div class="d-flex justify-content-between align-items-center fw-bold fs-5 pt-2 border-top">
                    <span>Total Amount:</span>
                    <span class="text-success">EGP${order.totalAmount.toFixed(2)}</span>
                </div>
                
                <h5 class="mt-4 mb-2 text-primary">Shipping To:</h5>
                <p class="mb-1">${order.shippingAddress.fullName}</p>
                <p class="mb-1">${order.shippingAddress.addressLine1}</p>
                <p class="mb-1">${order.shippingAddress.city}, ${order.shippingAddress.country}</p>
                <p>Phone: ${order.shippingAddress.phone}</p>

                <div class="mt-3 text-end">
                    ${order.status === 'Pending' || order.status === 'Processing' ? 
                        `<button class="btn btn-danger cancel-order-btn" data-order-id="${order._id}">
                            <i class="fas fa-times-circle me-2"></i>Cancel Order
                        </button>`
                        : `<span class="text-muted fst-italic">Order cannot be cancelled at this stage.</span>`
                    }
                </div>
            `;
            ordersListDiv.appendChild(orderCard);
        });

        // Add event listeners for cancel buttons
        ordersListDiv.querySelectorAll('.cancel-order-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const orderId = event.target.dataset.orderId;
                if (confirm(`Are you sure you want to cancel order ${orderId}? This action cannot be undone.`)) {
                    await cancelOrder(orderId);
                }
            });
        });
    }

    // Function to cancel an order
    async function cancelOrder(orderId) {
        try {
            const response = await fetch(`http://localhost:3000/api/orders/cancel/${orderId}`, {
                method: 'PUT', // Use PUT for updating status
                headers: window.getAuthHeaders()
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'Failed to cancel order.'); // تم التصحيح هنا
            }

            window.showToast(data.message, 'success');
            fetchMyOrders(); // Re-fetch orders to update the list
        } catch (error) {
            console.error('Error cancelling order:', error);
            window.showToast(`Error cancelling order: ${error.message}`, 'danger');
        }
    }

    // Initial fetch of orders when the page loads
    fetchMyOrders();

    // Update Navbar and cart count on page load
    if (window.updateNavbar) window.updateNavbar(); 
    if (window.updateCartCount) window.updateCartCount(); 
});