// public/js/notifications.js
document.addEventListener('DOMContentLoaded', async () => {
    const notificationsListContainer = document.getElementById('notifications-list-container');
    const notificationCountSpan = document.getElementById('notification-count');

    if (!notificationsListContainer) {
        console.log("Notifications container not found. Skipping notifications script execution.");
        return;
    }

    if (!window.isLoggedIn()) {
        window.showToast('Please log in to view your notifications.', 'info');
        return;
    }

    async function fetchAndDisplayNotifications() {
        notificationsListContainer.innerHTML = '<p class="text-center text-muted py-5">Loading your notifications...</p>';
        
        // ✅ تم تصحيح استخدام apiUrl
        const url = 'http://localhost:3000/api/notifications'; 
        
        try {
            const response = await fetch(url, { // استخدام 'url' مباشرة
                headers: window.getAuthHeaders()
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `Failed to load notifications: HTTP status ${response.status}`);
            }

            const notifications = await response.json();
            displayNotifications(notifications);

            const unreadCount = notifications.filter(n => !n.read).length;
            if (notificationCountSpan) {
                notificationCountSpan.textContent = unreadCount;
                notificationCountSpan.style.display = unreadCount > 0 ? 'inline-block' : 'none';
            }

        } catch (error) {
            console.error('Error fetching notifications:', error);
            notificationsListContainer.innerHTML = `<p class="text-center text-danger py-5">Failed to load notifications: ${error.message}</p>`;
            window.showToast(`Failed to load notifications: ${error.message}`, 'danger');
        }
    }

    function displayNotifications(notifications) {
        notificationsListContainer.innerHTML = '';

        if (notifications.length === 0) {
            notificationsListContainer.innerHTML = `
                <div class="text-center py-5">
                    <i class="fas fa-bell fa-5x text-muted mb-3"></i>
                    <p class="fs-4 text-muted">You have no notifications.</p>
                </div>
            `;
            return;
        }

        notifications.forEach(notification => {
            const notificationDiv = document.createElement('div');
            notificationDiv.classList.add('card', 'mb-3', 'shadow-sm', 'p-3');
            notificationDiv.classList.add(notification.read ? 'bg-light' : 'bg-white', 'border-primary');

            let linkHtml = '';
            if (notification.link) {
                linkHtml = `<a href="${notification.link}" class="btn btn-sm btn-outline-primary mt-2">View Details</a>`;
            }

            notificationDiv.innerHTML = `
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h5 class="mb-1 ${notification.read ? 'text-muted' : 'text-dark'}">${notification.message}</h5>
                        <small class="text-muted">${new Date(notification.createdAt).toLocaleString()}</small>
                    </div>
                    <div>
                        ${!notification.read ? `
                            <button class="btn btn-sm btn-outline-success mark-read-btn" data-notification-id="${notification._id}"><i class="fas fa-check"></i> Mark as Read</button>
                        ` : ''}
                        <button class="btn btn-sm btn-outline-danger delete-notification-btn ms-2" data-notification-id="${notification._id}"><i class="fas fa-trash-alt"></i> Delete</button>
                    </div>
                </div>
                ${linkHtml}
            `;
            notificationsListContainer.appendChild(notificationDiv);
        });

        notificationsListContainer.querySelectorAll('.mark-read-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const notificationId = event.target.dataset.notificationId;
                await markNotificationAsRead(notificationId);
            });
        });

        notificationsListContainer.querySelectorAll('.delete-notification-btn').forEach(button => {
            button.addEventListener('click', async (event) => {
                const notificationId = event.target.dataset.notificationId;
                if (confirm('Are you sure you want to delete this notification?')) {
                    await deleteNotification(notificationId);
                }
            });
        });
    }

    function getStarHtml(rating) { // دالة مساعدة موجودة في admin-reviews.js، لكن يمكن أن تكون هنا أيضاً
        let starsHtml = '';
        const fullStars = Math.floor(rating);
        const halfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

        for (let i = 0; i < fullStars; i++) {
            starsHtml += '<i class="fas fa-star text-warning"></i>';
        }
        if (halfStar) {
            starsHtml += '<i class="fas fa-star-half-alt text-warning"></i>';
        }
        for (let i = 0; i < emptyStars; i++) {
            starsHtml += '<i class="far fa-star text-warning"></i>';
        }
        return starsHtml;
    }


    async function markNotificationAsRead(notificationId) {
        try {
            const response = await fetch(`http://localhost:3000/api/notifications/${notificationId}/read`, {
                method: 'PUT',
                headers: window.getAuthHeaders()
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Failed to mark notification as read.');
            }
            window.showToast('Notification marked as read!', 'success');
            fetchAndDisplayNotifications();
        } catch (error) {
            console.error('Error marking notification as read:', error);
            window.showToast(`Failed to mark as read: ${error.message}`, 'danger');
        }
    }

    async function deleteNotification(notificationId) {
        try {
            const response = await fetch(`http://localhost:3000/api/notifications/${notificationId}`, {
                method: 'DELETE',
                headers: window.getAuthHeaders()
            });
            const data = await response.json();
            if (!response.ok) {
                throw new Error(data.message || 'Failed to delete notification.');
            }
            window.showToast('Notification deleted successfully!', 'success');
            fetchAndDisplayNotifications();
        } catch (error) {
            console.error('Error deleting notification:', error);
            window.showToast(`Failed to delete notification: ${error.message}`, 'danger');
        }
    }

    window.fetchAndDisplayNotifications = fetchAndDisplayNotifications; // جعل الدالة متاحة عالمياً
});