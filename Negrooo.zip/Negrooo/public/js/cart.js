// public/js/cart.js

window.cartItems = [];
console.log('Cart.js loaded. Initial window.cartItems:', window.cartItems);

// Helper function to compare two arrays of selected variants
// This is crucial for identifying unique cart items when multiple variant groups are selected.
function areVariantsEqual(variants1, variants2) {
    if (!variants1 && !variants2) return true; // Both are null/undefined (no variants selected)
    if (!variants1 || !variants2 || variants1.length !== variants2.length) return false;

    // Sort variants to ensure consistent comparison order regardless of the order sent from client
    const sorter = (a, b) => {
        if (a.name < b.name) return -1;
        if (a.name > b.name) return 1;
        if (a.value < b.value) return -1;
        if (a.value > b.value) return 1;
        return 0;
    };
    const sortedV1 = [...variants1].sort(sorter);
    const sortedV2 = [...variants2].sort(sorter);

    for (let i = 0; i < sortedV1.length; i++) {
        if (sortedV1[i].name !== sortedV2[i].name || sortedV1[i].value !== sortedV2[i].value) {
            return false;
        }
    }
    return true;
}


window.loadCart = async () => {
    const cartItemsContainer = document.getElementById('cart-items-container');
    const checkoutButton = document.getElementById('checkout-button');

    if (cartItemsContainer) {
        cartItemsContainer.innerHTML = '<p class="text-center text-muted py-5">Loading your cart...</p>';
    }
    if (checkoutButton) {
        checkoutButton.disabled = true;
    }

    if (window.isLoggedIn()) {
        try {
            const response = await fetch('/api/cart', {
                method: 'GET',
                headers: window.getAuthHeaders()
            });
            const data = await response.json();
            if (response.ok) {
                window.cartItems = data.items;
                console.log('Cart loaded from API:', window.cartItems);
            } else {
                console.error('Failed to load cart from API:', data.message);
                // Fallback to guest cart if API fails, but user is logged in (shouldn't happen normally)
                window.cartItems = JSON.parse(localStorage.getItem('guestCart') || '[]');
            }
        } catch (error) {
            console.error('Error loading cart from API:', error);
            // Fallback to guest cart on network error
            window.cartItems = JSON.parse(localStorage.getItem('guestCart') || '[]');
        }
    } else {
        // For guest users, load from localStorage
        window.cartItems = JSON.parse(localStorage.getItem('guestCart') || '[]');
        console.log('Guest cart loaded from localStorage:', window.cartItems);
    }
    updateCartUI(); // This will now also handle coupon display
    
    if (checkoutButton && window.cartItems.length > 0) {
        checkoutButton.disabled = false;
    } else if (checkoutButton) {
        checkoutButton.disabled = true;
    }
    console.log('loadCart finished. window.cartItems now:', window.cartItems);
};

window.saveGuestCart = () => {
    localStorage.setItem('guestCart', JSON.stringify(window.cartItems));
};

window.clearCart = async () => {
    window.cartItems = [];
    if (window.isLoggedIn()) {
        try {
            const response = await fetch('http://localhost:3000/api/cart/clear', { // Added full URL
                method: 'DELETE',
                headers: window.getAuthHeaders()
            });
            if (response.ok) {
                console.log('Backend cart cleared.');
                window.showToast('Your cart has been cleared.', 'success'); // Toast here for backend clear
            } else {
                const errorData = await response.json();
                console.error('Failed to clear backend cart:', errorData.message);
                window.showToast('Failed to clear backend cart.', 'error');
            }
        } catch (error) {
            console.error('Error clearing backend cart:', error);
            window.showToast('Network error clearing backend cart.', 'error');
        }
    } else {
        window.saveGuestCart();
        window.showToast('Your cart has been cleared locally.', 'success'); // Toast for guest clear
    }
    // Clear any applied coupon when cart is cleared
    localStorage.removeItem('appliedCoupon'); 
    updateCartUI();
    // Removed redundant window.showToast('Your cart has been cleared.', 'success'); from outside if/else
};

window.getCartItemCount = () => {
    return window.cartItems.reduce((total, item) => total + item.quantity, 0);
};

window.getCartItems = () => {
    return window.cartItems;
};


// MODIFIED: window.addToCart now accepts selectedVariants array
window.addToCart = async (productId, quantity = 1, selectedVariants = []) => {
    console.log('addToCart called. ProductId:', productId, 'Quantity:', quantity, 'Variants:', selectedVariants);

    const productResponse = await fetch(`http://localhost:3000/api/products/${productId}`);
    const productData = await productResponse.json();

    if (!productResponse.ok) {
        window.showToast(productData.message || 'Failed to get product details.', 'error');
        console.error('Failed to get product details:', productData);
        return;
    }

    // حساب بيانات الـ variant
    let variantImageUrl = productData.imageUrl;
    let variantPriceAdjustment = 0;
    let finalPrice = productData.price; // Start with base price

    if (productData.variants && productData.variants.length > 0) {
        if (!selectedVariants || selectedVariants.length === 0) {
            window.showToast('Please select all required variants.', 'warning');
            return;
        }

        let tempCombinedPriceAdjustment = 0; // Use temp for calculation
        let tempCombinedImageUrl = productData.imageUrl; // Use temp for calculation

        for (const clientVar of selectedVariants) {
            const foundGroup = productData.variants.find(vg => vg.name === clientVar.name); // Corrected from groupName
            if (!foundGroup) continue;

            const foundOption = foundGroup.options.find(opt => opt.value === clientVar.value); // Corrected from optionValue
            if (!foundOption) continue;

            tempCombinedPriceAdjustment += foundOption.priceAdjustment || 0;
            if (foundOption.imageUrl) {
                tempCombinedImageUrl = foundOption.imageUrl;
            }
        }
        variantPriceAdjustment = tempCombinedPriceAdjustment; // Assign to outer scope var
        variantImageUrl = tempCombinedImageUrl;             // Assign to outer scope var
        finalPrice = productData.price + variantPriceAdjustment; // Calculate final price based on adjustments

    }

    // تحويل selectedVariants للشكل المتوقع من الـ backend
    // Note: The selectedVariants passed from product-detail.js should already be in {name, value} format
    // This mapping might be redundant if frontend already sends it correctly, but acts as a safeguard.
    const normalizedVariants = selectedVariants.map(v => ({
        name: v.name, // Use 'name' to match Cart.js schema
        value: v.value // Use 'value' to match Cart.js schema
    }));

    if (window.isLoggedIn()) {
        try {
            const itemToSend = {
                productId,
                quantity,
                name: productData.name, // Use base product name
                price: finalPrice, // ✅ Use calculated finalPrice
                imageUrl: variantImageUrl, // ✅ Use calculated variantImageUrl
                selectedVariants: normalizedVariants // Use normalized variants
            };

            const response = await fetch('http://localhost:3000/api/cart/add', {
                method: 'POST',
                headers: { ...window.getAuthHeaders(), 'Content-Type': 'application/json' },
                body: JSON.stringify(itemToSend)
            });

            const data = await response.json();
            if (response.ok) {
                window.cartItems = data.cart.items;
                window.showToast('Product added to cart!', 'success');
                console.log('Product added to backend cart:', data);
            } else {
                window.showToast(data.message || 'Failed to add product to cart.', 'error');
                console.error('Failed to add to backend cart:', data);
            }
        } catch (error) {
            window.showToast('Network error adding to cart.', 'error');
            console.error('Error adding to backend cart:', error);
        }
    } else {
        // 🛒 Guest logic (كودك القديم مع تعديلات طفيفة)
        let existingItem = null;
        if (selectedVariants && selectedVariants.length > 0) {
            existingItem = window.cartItems.find(item =>
                item.productId === productId &&
                areVariantsEqual(item.selectedVariants, selectedVariants)
            );
        } else {
            existingItem = window.cartItems.find(item =>
                item.productId === productId && (!item.selectedVariants || item.selectedVariants.length === 0)
            );
        }

        let totalAvailableStock = productData.stock;
        if (productData.variants && productData.variants.length > 0) {
            totalAvailableStock = Infinity;
            for (const clientVar of selectedVariants) {
                const foundGroup = productData.variants.find(vg => vg.name === clientVar.name); // Corrected from groupName
                if (!foundGroup) continue;
                const foundOption = foundGroup.options.find(opt => opt.value === clientVar.value); // Corrected from optionValue
                if (!foundOption) continue;
                totalAvailableStock = Math.min(totalAvailableStock, foundOption.stock);
            }
        }

        if (existingItem) {
            const newTotalQuantity = existingItem.quantity + quantity;
            if (totalAvailableStock < newTotalQuantity) {
                window.showToast(`Adding ${quantity} units would exceed available stock. Max allowed: ${totalAvailableStock - existingItem.quantity}.`, 'warning');
                return;
            }

            existingItem.quantity = newTotalQuantity;
            existingItem.name = productData.name;
            existingItem.price = finalPrice; // ✅ Use calculated finalPrice for existing item
            existingItem.imageUrl = variantImageUrl; // ✅ Use calculated variantImageUrl for existing item
            existingItem.selectedVariants = normalizedVariants; // Store normalized variants
            // No need for variantImageUrl and variantPriceAdjustment as separate fields if 'price' and 'imageUrl' are adjusted directly

            window.showToast('Product quantity updated in cart!', 'success');
        } else {
            if (totalAvailableStock < quantity) {
                window.showToast(`Not enough stock for ${productData.name}. Available: ${totalAvailableStock}, Requested: ${quantity}.`, 'warning');
                return;
            }

            window.cartItems.push({
                productId,
                name: productData.name,
                price: finalPrice, // ✅ Use calculated finalPrice for new item
                imageUrl: variantImageUrl, // ✅ Use calculated variantImageUrl for new item
                quantity,
                stock: totalAvailableStock, // Store total available stock for guest cart validation
                selectedVariants: normalizedVariants, // Store normalized variants
                // No need for variantImageUrl and variantPriceAdjustment as separate fields if 'price' and 'imageUrl' are adjusted directly
            });

            window.showToast('Product added to cart!', 'success');
        }

        window.saveGuestCart();
        console.log('Product added to guest cart:', window.cartItems);
    }
    // Clear any applied coupon as cart content changed
    localStorage.removeItem('appliedCoupon'); 
    updateCartUI();
    window.updateCartCount();
};

// MODIFIED: window.removeFromCart now accepts selectedVariants array
window.removeFromCart = async (productId, selectedVariants = []) => {
    if (window.isLoggedIn()) {
        try {
            // Send selectedVariants in the body for accurate removal
            const normalizedVariants = selectedVariants.map(v => ({
                name: v.name,
                value: v.value
            }));
            const response = await fetch(`http://localhost:3000/api/cart/remove/${productId}`, {
                method: 'DELETE',
                headers: { ...window.getAuthHeaders(), 'Content-Type': 'application/json' },
                body: JSON.stringify({ selectedVariants: normalizedVariants }) // Pass normalized selectedVariants
            });
            const data = await response.json();
            if (response.ok) {
                window.cartItems = data.cart.items;
                window.showToast('Product removed from cart.', 'success');
            } else {
                window.showToast(data.message || 'Failed to remove product.', 'error');
            }
        } catch (error) {
            window.showToast('Network error removing from cart.', 'error');
            console.error('Error removing from cart:', error);
        }
    } else {
        // Guest cart logic for variants
        const initialLength = window.cartItems.length;
        window.cartItems = window.cartItems.filter(item =>
            !(item.productId === productId && areVariantsEqual(item.selectedVariants, selectedVariants))
        );
        if (window.cartItems.length < initialLength) {
            window.saveGuestCart();
            window.showToast('Product removed from cart.', 'success');
        } else {
            window.showToast('Product not found in guest cart.', 'info');
        }
    }
    // Clear any applied coupon as cart content changed
    localStorage.removeItem('appliedCoupon'); 
    updateCartUI();
    window.updateCartCount();
};

// MODIFIED: window.updateCartItemQuantity now accepts selectedVariants array
window.updateCartItemQuantity = async (productId, newQuantity, selectedVariants = []) => {
    if (newQuantity < 1) {
        return window.removeFromCart(productId, selectedVariants);
    }

    const productResponse = await fetch(`http://localhost:3000/api/products/${productId}`);
    const productData = await productResponse.json();

    if (!productResponse.ok) {
        window.showToast(productData.message || 'Failed to get product details for cart validation.', 'error');
        console.error('Failed to get product details for cart validation:', productData);
        return;
    }

    // Recalculate final price and image based on product data and selected variants
    let totalAvailableStock = productData.stock;
    let finalImageUrl = productData.imageUrl;
    let finalPrice = productData.price;

    if (productData.variants && productData.variants.length > 0) {
        if (!selectedVariants || selectedVariants.length === 0) {
            window.showToast('Variant selection missing for cart item update.', 'error');
            return;
        }

        let tempCombinedPriceAdjustment = 0;
        let tempCombinedImageUrl = productData.imageUrl;

        for (const clientVar of selectedVariants) {
            const foundGroup = productData.variants.find(vg => vg.name === clientVar.name); // Corrected from groupName
            if (!foundGroup) continue; // Should ideally not happen if data is consistent

            const foundOption = foundGroup.options.find(opt => opt.value === clientVar.value); // Corrected from optionValue
            if (!foundOption) continue; // Should ideally not happen

            totalAvailableStock = Math.min(totalAvailableStock, foundOption.stock);
            tempCombinedPriceAdjustment += foundOption.priceAdjustment || 0;
            if (foundOption.imageUrl) {
                tempCombinedImageUrl = foundOption.imageUrl;
            }
        }
        finalImageUrl = tempCombinedImageUrl;
        finalPrice = productData.price + tempCombinedPriceAdjustment;
    }

    if (newQuantity > totalAvailableStock) {
        window.showToast(`Max stock for this product is ${totalAvailableStock}.`, 'warning');
        newQuantity = totalAvailableStock; // Adjust quantity to max available
    }
    if (newQuantity <= 0) { // If after adjustment, it's 0 or less, remove item
        return window.removeFromCart(productId, selectedVariants);
    }


    if (window.isLoggedIn()) {
        try {
            const normalizedVariants = selectedVariants.map(v => ({
                name: v.name,
                value: v.value
            }));
            const response = await fetch('http://localhost:3000/api/cart/update', {
                method: 'PUT',
                headers: { ...window.getAuthHeaders(), 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    productId: productId,
                    quantity: newQuantity,
                    selectedVariants: normalizedVariants,
                    name: productData.name, // Pass updated name
                    price: finalPrice, // ✅ Pass calculated finalPrice
                    imageUrl: finalImageUrl // ✅ Pass calculated finalImageUrl
                })
            });
            const data = await response.json();
            if (response.ok) {
                window.cartItems = data.cart.items;
                window.showToast('Cart quantity updated.', 'success');
            } else {
                window.showToast(data.message || 'Failed to update quantity.', 'error');
            }
        } catch (error) {
            window.showToast('Network error updating cart quantity.', 'error');
            console.error('Error updating cart quantity:', error);
        }
    } else {
        // Guest cart logic for variants
        let item = null;
        if (selectedVariants && selectedVariants.length > 0) {
            item = window.cartItems.find(ci => ci.productId === productId && areVariantsEqual(ci.selectedVariants, selectedVariants));
        } else {
            item = window.cartItems.find(ci => ci.productId === productId && (!ci.selectedVariants || ci.selectedVariants.length === 0));
        }

        if (item) {
            item.quantity = newQuantity;
            item.name = productData.name;
            item.price = finalPrice; // ✅ Update with calculated finalPrice
            item.imageUrl = finalImageUrl; // ✅ Update with calculated finalImageUrl
            item.selectedVariants = selectedVariants;
            // No need for variantImageUrl and variantPriceAdjustment as separate fields if 'price' and 'imageUrl' are adjusted directly

            window.saveGuestCart();
            window.showToast('Cart quantity updated.', 'success');
        } else {
            window.showToast('Product not found in guest cart for quantity update.', 'info');
        }
    }
    // Clear any applied coupon as cart content changed
    localStorage.removeItem('appliedCoupon'); 
    updateCartUI();
    window.updateCartCount();
};

function updateCartUI() {
    const cartItemsContainer = document.getElementById('cart-items-container');
    const cartTotalElement = document.getElementById('cart-total');
    const cartCountSpan = document.getElementById('cart-item-count'); // This is for the mini-cart count in main.js
    const couponCodeInput = document.getElementById('couponCodeInput');
    const applyCouponBtn = document.getElementById('applyCouponBtn');
    const couponMessage = document.getElementById('couponMessage');
    const discountRow = document.getElementById('discountRow');
    const cartDiscountElement = document.getElementById('cart-discount');
    const finalTotalRow = document.getElementById('finalTotalRow');
    const cartFinalTotalElement = document.getElementById('cart-final-total');


    let subtotal = 0; // Renamed total to subtotal for clarity with discount
    let itemCount = 0;

    if (cartItemsContainer) {
        cartItemsContainer.innerHTML = ''; // Clear previous items
    }

    if (window.cartItems.length === 0) {
        if (cartItemsContainer) {
            cartItemsContainer.innerHTML = `
                <div class="text-center py-5">
                    <i class="fas fa-shopping-cart fa-5x text-muted mb-3"></i>
                    <p class="fs-4 text-muted">Your cart is empty.</p>
                    <a href="index.html" class="btn btn-primary btn-lg mt-3"><i class="fas fa-shopping-bag me-2"></i>Start Shopping</a>
                </div>
            `;
        }
        // Hide coupon/discount sections if cart is empty
        if (couponCodeInput) couponCodeInput.value = '';
        if (couponMessage) couponMessage.classList.add('d-none');
        if (discountRow) discountRow.style.display = 'none';
        if (finalTotalRow) finalTotalRow.style.display = 'none';
        
    } else {
        window.cartItems.forEach(item => {
            // Correctly get product data for display.
            // When cart is loaded from API, item.productId is populated.
            // When guest cart, item directly contains product details.
            const productForDisplay = item.productId && typeof item.productId === 'object' ? item.productId : item;

            const productId = productForDisplay._id || item.productId; // Use _id from populated product, or item's productId
            const productName = productForDisplay.name;

            // Use item.price and item.imageUrl directly, as they should already be adjusted for variants
            const itemDisplayPrice = item.price; // This should already be the final adjusted price
            const itemDisplayImage = item.imageUrl; // This should already be the final adjusted image

            // Get the actual stock for the specific variant combination if applicable (from populated product data)
            let itemMaxStock = productForDisplay.stock || 999; // Default to main product stock or high number if not available
            if (productForDisplay.variants && productForDisplay.variants.length > 0 && item.selectedVariants && item.selectedVariants.length > 0) {
                itemMaxStock = Infinity;
                for (const cartItemVar of item.selectedVariants) {
                    const group = productForDisplay.variants.find(vg => vg.name === cartItemVar.name); // Corrected from groupName
                    if (group) {
                        const option = group.options.find(opt => opt.value === cartItemVar.value); // Corrected from optionValue
                        if (option) {
                            itemMaxStock = Math.min(itemMaxStock, option.stock);
                        }
                    }
                }
            } else if (productForDisplay.variants && productForDisplay.variants.length > 0 && (!item.selectedVariants || item.selectedVariants.length === 0)) {
                // This case means a product with variants was added without selection (shouldn't happen with proper validation)
                // Default to 0 stock to prevent issues
                itemMaxStock = 0;
            }


            const itemTotal = itemDisplayPrice * item.quantity;
            subtotal += itemTotal; // Sum to subtotal
            itemCount += item.quantity;

            if (cartItemsContainer) {
                const cartItemDiv = document.createElement('div');
                cartItemDiv.className = 'cart-item d-flex align-items-center py-3 border-bottom';
                // Store selected variants as a JSON string in a data attribute
                cartItemDiv.dataset.productId = productId;
                cartItemDiv.dataset.selectedVariants = JSON.stringify(item.selectedVariants || []);

                // Generate variant display string (e.g., "Color: Red, Size: M")
                const variantDisplay = item.selectedVariants && item.selectedVariants.length > 0
                    ? ` (${item.selectedVariants.map(v => `${v.name}: ${v.value}`).join(', ')})` // ✅ Use v.name and v.value
                    : '';

                cartItemDiv.innerHTML = `
                    <div class="flex-shrink-0 me-3">
                        <img src="${itemDisplayImage || '/images/placeholder.jpg'}" alt="${productName}" class="rounded cart-item-image">
                    </div>
                    <div class="flex-grow-1">
                        <h5 class="mb-1 text-primary">
                            <a href="product-detail.html?id=${productId}" class="text-decoration-none text-primary">${productName}${variantDisplay}</a>
                        </h5>
                        <p class="text-muted mb-0">Price: EGP${itemDisplayPrice.toFixed(2)} per unit</p>
                        <p class="fw-bold mb-0">Subtotal: EGP${itemTotal.toFixed(2)}</p>
                    </div>
                    <div class="d-flex align-items-center cart-item-actions">
                        <div class="input-group quantity-selector-custom-cart">
                            <button class="btn btn-outline-secondary quantity-btn-cart" type="button" data-action="decrease" data-product-id="${productId}" data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>-</button>
                            <input type="number" value="${item.quantity}" min="1" class="form-control item-quantity-input-cart text-center" data-product-id="${productId}" data-max-stock="${itemMaxStock}" data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>
                            <button class="btn btn-outline-secondary quantity-btn-cart" type="button" data-action="increase" data-product-id="${productId}" data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>+</button>
                        </div>
                        <button class="btn btn-danger btn-sm remove-item-btn ms-3" data-product-id="${productId}" data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>
                            <i class="fas fa-trash-alt"></i> Remove
                        </button>
                    </div>
                `;
                cartItemsContainer.appendChild(cartItemDiv);

                // Attach event listeners for dynamically created elements
                const currentProductId = productId; // Closure
                // Removed currentSelectedVariants from closure as we will read it directly from DOM.

                cartItemDiv.querySelector('.item-quantity-input-cart').addEventListener('change', async (e) => {
                    let newQuantity = parseInt(e.target.value);
                    const maxStock = parseInt(e.target.dataset.maxStock);
                    if (isNaN(newQuantity) || newQuantity < 0) {
                        newQuantity = 0; // Will trigger remove if 0
                    } else if (newQuantity > maxStock) {
                        window.showToast(`Max stock for this product is ${maxStock}.`, 'warning');
                        newQuantity = maxStock;
                    }
                    // ✅ MODIFIED: Parse selectedVariants from the event target's dataset
                    const selectedVariantsFromDom = JSON.parse(e.target.dataset.selectedVariants || '[]');
                    await window.updateCartItemQuantity(currentProductId, newQuantity, selectedVariantsFromDom);
                });

                cartItemDiv.querySelector('.quantity-btn-cart[data-action="decrease"]').addEventListener('click', (e) => {
                    let currentQuantity = parseInt(cartItemDiv.querySelector('.item-quantity-input-cart').value);
                    // ✅ MODIFIED: Parse selectedVariants from the event target's dataset
                    const selectedVariantsFromDom = JSON.parse(e.target.dataset.selectedVariants || '[]');
                    if (currentQuantity > 1) {
                        window.updateCartItemQuantity(currentProductId, currentQuantity - 1, selectedVariantsFromDom);
                    } else {
                        window.showToast('Minimum quantity is 1. Click Remove to delete item.', 'info');
                    }
                });

                cartItemDiv.querySelector('.quantity-btn-cart[data-action="increase"]').addEventListener('click', (e) => {
                    let currentQuantity = parseInt(cartItemDiv.querySelector('.item-quantity-input-cart').value);
                    const maxStock = parseInt(cartItemDiv.querySelector('.item-quantity-input-cart').dataset.maxStock);
                    // ✅ MODIFIED: Parse selectedVariants from the event target's dataset
                    const selectedVariantsFromDom = JSON.parse(e.target.dataset.selectedVariants || '[]');
                    if (currentQuantity < maxStock) {
                        window.updateCartItemQuantity(currentProductId, currentQuantity + 1, selectedVariantsFromDom);
                    } else {
                        window.showToast(`Max stock for this product is ${maxStock}.`, 'warning');
                    }
                });

                cartItemDiv.querySelector('.remove-item-btn').addEventListener('click', (e) => {
                    // ✅ MODIFIED: Parse selectedVariants from the event target's dataset
                    const selectedVariantsFromDom = JSON.parse(e.target.dataset.selectedVariants || '[]');
                    window.removeFromCart(currentProductId, selectedVariantsFromDom);
                });
            }
        });
    }

    // Update total display
    if (cartTotalElement) {
        cartTotalElement.textContent = `EGP${subtotal.toFixed(2)}`;
    }
    // Update the mini-cart count in the navbar (handled by main.js, which calls window.updateCartCount)
    if (cartCountSpan) {
        cartCountSpan.textContent = itemCount;
    }

    // Coupon logic - applied after subtotal calculation
    let totalAfterDiscount = subtotal;
    let discountAmount = 0;
    const appliedCoupon = JSON.parse(localStorage.getItem('appliedCoupon') || 'null');

    if (appliedCoupon && subtotal >= appliedCoupon.minOrderAmount) {
        if (appliedCoupon.discountType === 'percentage') {
            discountAmount = subtotal * (appliedCoupon.discountValue / 100);
            if (appliedCoupon.maxDiscountAmount && discountAmount > appliedCoupon.maxDiscountAmount) {
                discountAmount = appliedCoupon.maxDiscountAmount;
            }
        } else if (appliedCoupon.discountType === 'fixed_amount') {
            discountAmount = appliedCoupon.discountValue;
        }
        
        totalAfterDiscount = subtotal - discountAmount;
        if (totalAfterDiscount < 0) totalAfterDiscount = 0; // Ensure total doesn't go negative

        if (couponCodeInput) couponCodeInput.value = appliedCoupon.code;
        if (couponMessage) {
            couponMessage.textContent = `Coupon "${appliedCoupon.code}" applied: -EGP${discountAmount.toFixed(2)}`;
            couponMessage.classList.remove('alert-danger', 'alert-warning');
            couponMessage.classList.add('alert-success');
            couponMessage.classList.remove('d-none');
        }
        if (discountRow) discountRow.style.display = 'flex';
        if (cartDiscountElement) cartDiscountElement.textContent = `EGP${discountAmount.toFixed(2)}`;
        if (finalTotalRow) finalTotalRow.style.display = 'flex';
        if (cartFinalTotalElement) cartFinalTotalElement.textContent = `EGP${totalAfterDiscount.toFixed(2)}`;

    } else {
        // If coupon is not applied or invalid, clear UI
        if (couponCodeInput) couponCodeInput.value = '';
        if (couponMessage) couponMessage.classList.add('d-none');
        if (discountRow) discountRow.style.display = 'none';
        if (finalTotalRow) finalTotalRow.style.display = 'none';
        localStorage.removeItem('appliedCoupon'); // Clear invalid/expired coupon
    }

    // Attach event listener for apply coupon button
    if (applyCouponBtn) {
        applyCouponBtn.onclick = async () => {
            const couponCode = couponCodeInput.value.trim();
            if (!couponCode) {
                if (couponMessage) {
                    couponMessage.textContent = 'Please enter a coupon code.';
                    couponMessage.classList.remove('alert-success');
                    couponMessage.classList.add('alert-warning');
                    couponMessage.classList.remove('d-none');
                }
                localStorage.removeItem('appliedCoupon');
                updateCartUI(); // Re-render to clear discount
                return;
            }

            try {
                const response = await fetch(`http://localhost:3000/api/coupons/${couponCode}`);
                const data = await response.json();

                if (response.ok) {
                    const coupon = data;
                    if (subtotal < coupon.minOrderAmount) {
                        if (couponMessage) {
                            couponMessage.textContent = `Coupon requires a minimum order of EGP${coupon.minOrderAmount.toFixed(2)}. Your current subtotal is EGP${subtotal.toFixed(2)}.`;
                            couponMessage.classList.remove('alert-success');
                            couponMessage.classList.add('alert-warning');
                            couponMessage.classList.remove('d-none');
                        }
                        localStorage.removeItem('appliedCoupon');
                        updateCartUI(); // Re-render to clear discount
                        return;
                    }
                    localStorage.setItem('appliedCoupon', JSON.stringify(coupon));
                    window.showToast('Coupon applied successfully!', 'success');
                } else {
                    if (couponMessage) {
                        couponMessage.textContent = data.message || 'Invalid coupon code.';
                        couponMessage.classList.remove('alert-success');
                        couponMessage.classList.add('alert-danger');
                        couponMessage.classList.remove('d-none');
                    }
                    localStorage.removeItem('appliedCoupon');
                    window.showToast(data.message || 'Failed to apply coupon.', 'error');
                }
            } catch (error) {
                console.error('Error applying coupon:', error);
                if (couponMessage) {
                    couponMessage.textContent = 'Network error or invalid coupon.';
                    couponMessage.classList.remove('alert-success');
                    couponMessage.classList.add('alert-danger');
                    couponMessage.classList.remove('d-none');
                }
                localStorage.removeItem('appliedCoupon');
                window.showToast('Network error applying coupon.', 'error');
            } finally {
                updateCartUI(); // Always update UI after coupon attempt
            }
        };
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    await window.loadCart();
});