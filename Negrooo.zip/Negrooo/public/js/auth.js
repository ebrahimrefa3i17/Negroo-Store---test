// public/js/auth.js

// No longer parsing JWT from localStorage directly, as it's now in HttpOnly cookie.
// The JWT is verified by the backend. Frontend only needs to know if it exists.
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
}

window.isAuthenticated = false;
window.currentUser = null;

// Helper to get a cookie value by name (for non-HttpOnly cookies, not used for auth token here)
// This function is generally not needed for the HttpOnly token, but kept for general utility.
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

// ✅ MODIFIED: isLoggedIn now pings a protected endpoint to verify session via cookie
window.isLoggedIn = async () => {
    try {
        const response = await fetch('http://localhost:3000/api/users/profile', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' } // Browser automatically sends HTTP-only cookie
        });

        if (response.ok) {
            const userData = await response.json();
            window.isAuthenticated = true;
            window.currentUser = userData; // Store user data fetched from profile
            return true;
        } else {
            // If response is not ok (e.g., 401, 403), means session is invalid or expired
            window.isAuthenticated = false;
            window.currentUser = null;
            // Server should have cleared the cookie if expired/invalid.
            return false;
        }
    } catch (error) {
        console.error('Error checking login status:', error);
        window.isAuthenticated = false;
        window.currentUser = null;
        return false;
    }
};

window.getCurrentUser = () => {
    return window.currentUser; // Will be populated by isLoggedIn
};

// ✅ MODIFIED: logoutUser now calls a backend endpoint to clear the cookie
window.logoutUser = async () => {
    try {
        const response = await fetch('http://localhost:3000/api/auth/logout', { // New backend logout endpoint
            method: 'POST',
            headers: { 'Content-Type': 'application/json' } // No auth header needed, browser sends cookie
        });

        if (response.ok) {
            window.isAuthenticated = false;
            window.currentUser = null;
            // Server should have cleared the cookie.
            if (window.showToast) {
                window.showToast('Logged out successfully!', 'success');
            }
            // Update UI/redirect
            if (window.location.pathname.startsWith('/admin') || window.location.pathname.includes('user-dashboard.html')) {
                window.location.href = '/';
            } else {
                if (window.updateNavbar) {
                    window.updateNavbar();
                }
            }
        } else {
            const errorData = await response.json();
            window.showToast(errorData.message || 'Failed to log out.', 'error');
            console.error('Logout failed:', errorData);
        }
    } catch (error) {
        window.showToast('Network error during logout.', 'error');
        console.error('Network error during logout:', error);
    }
};

// ✅ MODIFIED: getAuthHeaders no longer attempts to read HttpOnly token
window.getAuthHeaders = () => {
    // For HTTP-only cookies, client-side JS cannot read the JWT token.
    // So, we cannot put it in an 'Authorization: Bearer' header from frontend JS.
    // The backend should now rely solely on the HTTP-only cookie for authentication.
    return {
        'Content-Type': 'application/json'
        // 'Authorization': undefined // No longer sending from here, browser handles cookie
    };
};

// ✅ Removed window.isLoggedIn() call here. It's now called by DOMContentLoaded in main.js
// window.isLoggedIn();

window.updateNavbarUI = () => {
    const authLinks = document.getElementById('auth-links');
    const userDropdown = document.getElementById('user-dropdown');
    const cartCountSpan = document.getElementById('cart-item-count');
    const notificationsCountSpan = document.getElementById('notification-count');

    // Call isLoggedIn to ensure status is up-to-date (this promise is awaited in main.js)
    // window.isLoggedIn().then(loggedIn => {
        // We assume isLoggedIn has already been awaited and populated window.isAuthenticated and window.currentUser
        const loggedIn = window.isAuthenticated; // Use the already determined status
        const currentUser = window.currentUser;

        if (authLinks && userDropdown) {
            if (loggedIn) {
                authLinks.classList.add('d-none');
                userDropdown.classList.remove('d-none');
                const userNameElement = document.getElementById('user-name-display');
                if (userNameElement && currentUser) {
                    userNameElement.textContent = currentUser.name || currentUser.email.split('@')[0];
                }
            } else {
                authLinks.classList.remove('d-none');
                userDropdown.classList.add('d-none');
            }
        }

        if (cartCountSpan) {
            // updateCartCount will internally check isLoggedIn
            // This is called by updateNavbar in main.js, no direct call here.
        }
        if (notificationsCountSpan) {
            // updateNotificationCount will internally check isLoggedIn
            // This is called by updateNavbar in main.js, no direct call here.
        }
    // });
};

window.openMiniCart = async () => {
    console.log('openMiniCart: Opening mini cart.');
    const miniCartSidebar = document.getElementById('mini-cart-sidebar');
    const miniCartOverlay = document.getElementById('mini-cart-overlay');

    if (!miniCartSidebar) {
        console.error('Mini cart sidebar element not found when opening.');
        return;
    }

    miniCartSidebar.classList.add('open');
    if (miniCartOverlay) miniCartOverlay.style.display = 'block';
    document.body.style.overflow = 'hidden';

    if (typeof window.updateCartCount === 'function') {
        await window.updateCartCount();
    } else {
        console.warn('updateCartCount is not available for openMiniCart. Cannot update mini cart.');
        if (typeof window.getCartItems === 'function' && typeof window.updateMiniCart === 'function') {
            window.updateMiniCart({ items: window.getCartItems() });
        } else {
            window.updateMiniCart(null);
        }
    }
};

window.closeMiniCart = () => {
    console.log('closeMiniCart: Closing mini cart.');
    const miniCartSidebar = document.getElementById('mini-cart-sidebar');
    const miniCartOverlay = document.getElementById('mini-cart-overlay');
    if (!miniCartSidebar) return;
    miniCartSidebar.classList.remove('open');
    if (miniCartOverlay) miniCartOverlay.style.display = 'none';
    document.body.style.overflow = '';
};

window.updateMiniCart = (cart) => {
    console.log('updateMiniCart: Updating mini cart content.', cart);
    const miniCartItemsContainer = document.getElementById('mini-cart-items-container');
    const miniCartTotalSpan = document.getElementById('mini-cart-total');
    const checkoutButton = document.getElementById('mini-cart-checkout-btn');

    if (!miniCartItemsContainer || !miniCartTotalSpan || !checkoutButton) {
        console.error('Mini cart display elements not found (container, total span, or checkout button) when updating.');
        return;
    }

    miniCartItemsContainer.innerHTML = '';
    let total = 0;

    if (!cart || !cart.items || cart.items.length === 0) {
        miniCartItemsContainer.innerHTML = '<p class="text-center text-muted mini-cart-empty-message">Your cart is empty.</p>';
        miniCartTotalSpan.textContent = 'EGP0.00';
        checkoutButton.classList.add('disabled');
        return;
    }

    cart.items.forEach(item => {
        // Ensure productData is correctly extracted
        // If item.productId is an object (populated), use it. Otherwise, use item itself (for guest cart items).
        const productForDisplay = item.productId && typeof item.productId === 'object' ? item.productId : item;

        // Use the denormalized fields from the cart item, which should include variant adjustments
        const itemProductId = productForDisplay._id || item.productId;
        const itemName = item.name; // Use denormalized name from cart item
        const itemPrice = item.price; // Use denormalized price (variant adjusted) from cart item
        const itemImageUrl = item.imageUrl; // Use denormalized image URL (variant specific) from cart item

        // Get the actual stock for the specific variant combination if applicable
        // This comes from the populated productData, not the denormalized item.
        let itemMaxStock = productForDisplay.stock || 999; // ✅ FIX: Corrected variable name from itemStock to itemMaxStock
        if (productForDisplay.variants && productForDisplay.variants.length > 0 && item.selectedVariants && item.selectedVariants.length > 0) {
            itemMaxStock = Infinity; // Start high to find the minimum across all selected options
            for (const cartItemVar of item.selectedVariants) {
                const group = productForDisplay.variants.find(vg => vg.name === cartItemVar.name);
                if (group) {
                    const option = group.options.find(opt => opt.value === cartItemVar.value);
                    if (option) {
                        itemMaxStock = Math.min(itemMaxStock, option.stock);
                    }
                }
            }
        } else if (productForDisplay.variants && productForDisplay.variants.length > 0 && (!item.selectedVariants || item.selectedVariants.length === 0)) {
            // This case means a product with variants was added without selection (shouldn't happen with proper validation)
            itemMaxStock = 0; // Default to 0 stock to prevent issues
        }


        const itemTotal = itemPrice * item.quantity;
        total += itemTotal;

        // Generate variant display string (e.g., "Color: Red, Size: M")
        // Use v.name and v.value as per Cart.js schema
        const variantDisplay = item.selectedVariants && item.selectedVariants.length > 0
            ? ` (${item.selectedVariants.map(v => `${v.name}: ${v.value}`).join(', ')})`
            : '';

        const itemDiv = document.createElement('div');
        itemDiv.classList.add('mini-cart-item');
        itemDiv.innerHTML = `
            <div class="mini-cart-item-image-wrapper">
                <img src="${itemImageUrl || '/images/placeholder.jpg'}" alt="${itemName}${variantDisplay}" class="mini-cart-item-image">
            </div>
            <div class="mini-cart-item-info">
                <h6 class="mini-cart-item-name">${itemName}${variantDisplay}</h6>
                <div class="mini-cart-item-details">
                    <span class="mini-cart-item-price">EGP${itemPrice.toFixed(2)}</span>
                    <div class="input-group input-group-sm mini-cart-quantity-selector">
                        <button class="btn btn-outline-secondary quantity-btn-mini-cart" type="button" data-action="decrease"
                                data-product-id="${itemProductId}" data-max-stock="${itemMaxStock}"
                                data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>-</button>
                        <input type="number" value="${item.quantity}" min="1"
                               class="form-control item-quantity-input-mini-cart text-center"
                               data-product-id="${itemProductId}" data-max-stock="${itemMaxStock}"
                               data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>
                        <button class="btn btn-outline-secondary quantity-btn-mini-cart" type="button" data-action="increase"
                                data-product-id="${itemProductId}" data-max-stock="${itemMaxStock}"
                                data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>+</button>
                    </div>
                </div>
            </div>
            <div class="mini-cart-item-actions">
                <span class="mini-cart-item-total fw-bold">EGP${itemTotal.toFixed(2)}</span>
                <button class="btn btn-sm btn-danger mini-cart-remove-btn"
                        data-product-id="${itemProductId}" data-selected-variants='${JSON.stringify(item.selectedVariants || [])}'>
                    <i class="fas fa-times"></i></button>
            </div>
        `;
        miniCartItemsContainer.appendChild(itemDiv);
    });
    miniCartTotalSpan.textContent = `EGP${total.toFixed(2)}`;
    checkoutButton.classList.remove('disabled');

    // Removed direct event listeners from here.
    // Event delegation in main.js will handle these.
    // This is the core fix for double increment/decrement and double toasts.
};


// ✅ NEW: updateNotificationCount function (was missing, causing TypeError)
window.updateNotificationCount = async () => {
    const notificationCountSpan = document.getElementById('notification-count');
    if (!notificationCountSpan) return;

    // Use window.isLoggedIn() which now pings backend to ensure status
    const loggedIn = await window.isLoggedIn(); // Await to get the true status

    if (!loggedIn) {
        notificationCountSpan.textContent = '0';
        notificationCountSpan.style.display = 'none';
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/api/notifications?read=false', {
            headers: { 'Content-Type': 'application/json' } // Browser sends cookie automatically
        });

        if (response.ok) {
            const notifications = await response.json();
            const unreadCount = notifications.length;
            notificationCountSpan.textContent = unreadCount;
            notificationCountSpan.style.display = unreadCount > 0 ? 'inline-block' : 'none';
        } else {
            console.error('Failed to fetch notification count:', response.status);
            notificationCountSpan.textContent = '0';
            notificationCountSpan.style.display = 'none';
        }
    } catch (error) {
        console.error('Error fetching notification count:', error);
        notificationCountSpan.textContent = '0';
        notificationCountSpan.style.display = 'none';
    }
};

// Initial call to check login status and update navbar on page load (from main.js)
// document.addEventListener('DOMContentLoaded', () => {
//     window.isLoggedIn().then(() => {
//         window.updateNavbar();
//     });
// });